"use strict";

//let data_graphe = [[1729900817, 368.06, 6.03, 227.43, 32.11, 26.00, 0.00, 368.06, 6.03, 227.43],
//[1729900937, 364.80, 5.94, 225.69, 32.10, 26.00, 0.00, 364.80, 5.94, 225.69],
//[1729901057, 361.80, 5.84, 223.91, 32.09, 26.00, 0.00, 361.80, 5.84, 223.91],
//[1729901178, 362.94, 5.88, 224.58, 32.08, 26.00, 0.00, 362.94, 5.88, 224.58],
//[1729901299, 434.80, 5.94, 226.76, 32.08, 26.00, 0.00, 434.80, 5.94, 226.76],
//[1729901419, 452.63, 5.90, 226.35, 32.07, 26.00, 0.00, 452.63, 5.90, 226.35],
//[1729901540, 452.04, 6.00, 228.24, 32.06, 25.88, 0.00, 452.04, 6.00, 228.24],
//[1729901660, 450.15, 5.98, 227.96, 32.06, 25.88, 0.00, 450.15, 5.98, 227.96],
//[1729901780, 447.77, 5.95, 227.22, 32.06, 25.88, 0.00, 447.77, 5.95, 227.22],
//[1729901901, 450.86, 6.07, 229.54, 32.06, 25.88, 0.00, 450.86, 6.07, 229.54],
//[1729902021, 448.39, 6.02, 228.44, 32.05, 26.00, 0.00, 448.39, 6.02, 228.44],
//[1729902142, 442.39, 5.87, 225.72, 32.04, 26.00, 0.00, 442.39, 5.87, 225.72],
//[1729902262, 443.50, 5.92, 226.65, 32.03, 26.00, 0.00, 443.50, 5.92, 226.65],
//[1729902383, 434.58, 6.12, 230.08, 32.03, 26.00, 0.00, 434.58, 6.12, 230.08],
//[1729902504, 353.07, 6.31, 232.27, 32.03, 26.00, 0.00, 353.07, 6.31, 232.27],
//[1729902624, 327.97, 6.32, 232.00, 32.03, 26.00, 0.00, 327.97, 6.32, 232.00],
//[1729902745, 326.20, 6.28, 231.08, 32.03, 26.00, 0.00, 326.20, 6.28, 231.08],
//[1729902865, 326.66, 6.30, 231.35, 32.03, 26.00, 0.00, 326.66, 6.30, 231.35],
//[1729902985, 324.17, 6.22, 229.90, 32.03, 25.88, 0.00, 324.17, 6.22, 229.90],
//[1729903106, 325.95, 6.25, 230.82, 32.03, 26.00, 0.00, 325.95, 6.25, 230.82],
//[1729903226, 326.78, 6.27, 231.26, 32.03, 26.00, 0.00, 326.78, 6.27, 231.26],
//[1729903347, 322.40, 6.16, 229.14, 32.03, 25.88, 0.00, 322.40, 6.16, 229.14],
//[1729903467, 322.25, 6.16, 229.15, 32.02, 25.88, 0.00, 322.25, 6.16, 229.15],
//[1729903588, 327.97, 6.34, 232.56, 32.03, 25.88, 0.00, 327.97, 6.34, 232.56],
//[1729903708, 322.59, 6.23, 230.43, 32.01, 25.88, 0.00, 322.59, 6.23, 230.43]];

// Graphe variables
var power_line, LineGraph_Power, power_line_length;
var energy_bar, BarGraph_Energy, energy_bar_length;

// Time array
var data_date_formated = new Array();

// For when resize the window
var CurrentPageName;

// To get chart from div that contain canvas. For undo zoom, export, tooltip
var divIdToChart = {};

// ***************************
// Time functions
// ***************************

function newDate(new_time) {
  return ((new_time - 3600) * 1000);
}

// Unix date to jj/mm/yy
function newDateEnergy(new_time) {
  let date = new Date(new_time * 1000);
  var day = date.getDate();
  var month = date.getMonth() + 1;
  var year = date.getFullYear() - 2000;  //   getYear
  if (day < 10) day = "0" + day;
  if (month < 10) month = "0" + month;

  return [day, month, year].join('/');
}

// ***************************
// Plot function
// ***************************

function doClearGraphe(target) {
  if (target ===  "data")
  {
    // date
    data_date_formated.length = 0;
    // Power, Voltage, Temperature
    for (let i = 0; i < power_line_length; i++) {
      power_line.data.datasets[i].data.length = 0;
    }
  }
  else
    if (target === "energy")
    {  // Energy
      energy_bar.data.labels.length = 0;
      for (let i = 0; i < energy_bar_length; i++) {
        energy_bar.data.datasets[i].data.length = 0;
      }
    }
}

function refreshGraph(target) {
  if (target === undefined)
    target = currentChart.target;

  if (target === "data")
  {
    ESP_Request("Update_CSV", ["/data.csv", target]);
  }
  else
    if (target === "energy")
    {
      ESP_Request("Update_CSV", ["/energy.csv", target]);
    }
}

function do_updateGraph(data, target) {
  var i = 0;

  if (target ===  "data")
  {
    // Date
    data_date_formated.push(newDate(data[i++]));
    // Order is voltage, Power, temperature
    for (let j = 0; j < power_line_length; j++) {
      power_line.data.datasets[j].data.push(data[i++]);
    }
  }
  else
    if (target === "energy")
    {
      // Energy
      energy_bar.data.labels.push(newDateEnergy(data[i++]));
      for (let j = 0; j < energy_bar_length; j++) {
        energy_bar.data.datasets[j].data.push(data[i++]);
      }
    }
}

function updateGraph(data, target, append) {
  if (append)
    do_updateGraph(data, target);
  else
    {
      doClearGraphe(target);
      for (let j = 0; j < data.length; j++) {
        do_updateGraph(data[j], target);
      }
    }
  if (target === "data")
  {
    LineGraph_Power.update();
    if (!append)
      LineGraph_Power.resetZoom();
  }
  else
    if (target === "energy")
    {
      BarGraph_Energy.update();
      if (!append)
        BarGraph_Energy.resetZoom();
    }
}

// Parse un fichier csv et renvoie un tableau de nb_var tableaux [[], ..., []]
function parseCSV(raw_string, nb_var) {
  var lines = raw_string.split("\r\n");
  var array = new Array(lines.length);

  var k = 0;
  for (var i = 0; i < lines.length; i++) {
    if (lines[i] != "")
    {
      array[k] = new Array(nb_var);
      var data = lines[i].split("\t");
      var data_size = data.length;
      for (let j = 0; j < nb_var; j++) {
        if (j < data_size)
          array[k][j] = parseFloat(data[j]);
        else
          array[k][j] = 0;
      }
      k++;
    }
  }
  // Suppress empty lines
  if (k != lines.length)
    array.length = k;
  return array;
}

// ***************************
// Export function
// ***************************

/**
* Convert graphe data to csv
* args class params :
* data: the data property of the chart class (Chart.data)
* label: the label text of labels of the chart class
* columnDelimiter: the column delimiter character (default \t)
* lineDelimiter: the line delimiter character (default \r\n)
*/
function convertChartDataToCSV(args) {
  let result, columnDelimiter, lineDelimiter, labels, datas;

  datas = args.data.datasets || null;
  if (datas == null || !datas.length) {
    return null;
  }

  labels = args.data.labels || null;
  if (labels == null || !labels.length) {
    return null;
  }

  columnDelimiter = args.columnDelimiter || '\t';
  lineDelimiter = args.lineDelimiter || '\r\n';

  result = '';

  // Title of the columns
  result += args.label;
  result += columnDelimiter;
  for (var j = 0; j < datas.length; j++) {
    result += datas[j].label;
    result += columnDelimiter;
  }
  result += lineDelimiter;

  // We suppose that every datasets have the same length of labels
  for (var i = 0; i < labels.length; i++) {
    // Convert unix datetime to human readable date
    let dateObject = new Date(labels[i]);
    result += dateObject.toLocaleString();
    result += columnDelimiter;
    for (var j = 0; j < datas.length; j++) {
      result += (datas[j].data[i]).toString().replace(".", ",");
      result += columnDelimiter;
    }
    result += lineDelimiter;
  }

  return result;
}

function exportCSV(can_plot) {
  if (can_plot === undefined)
    can_plot = currentChart.id;
  const theChart = divIdToChart[can_plot];
  let data_csv = convertChartDataToCSV({
      data: theChart.data,
      label: 'Date'
  });

  if (data_csv == null) return;
//  console.log(data_csv);

  var blob = new Blob([data_csv],
          { type: "text/plain; charset=utf-8" });

  // Save the file with FileSaver.js
  saveAs(blob, currentChart.chartName + ".csv");
}

// Export graphic to PNG
function exportPNG(chart, name) {
  const imageLink = document.createElement('a');
  if (chart === undefined) {
    var canvas = divIdToChart[currentChart.id].canvas;
    name = currentChart.chartName;
  }
  else {
    var canvas = document.getElementById(chart);
  }

  imageLink.download = name + ".png";
  imageLink.href = canvas.toDataURL("image/png", 1);
  imageLink.click();
}

// ***************************
// Plot create functions
// https://www.chartjs.org/docs/latest/
// ***************************

const timeFormat = 'HH:mm';  // "HH:mm"; DD T
const dateFormat = 'DD MM YYYY HH:mm:ss';

const dragOptions = {
    borderColor: 'rgba(225,225,225,0.3)',
    borderWidth: 5,
    backgroundColor: 'rgb(225,225,225)',
    animationDuration: 500
};

// List of scales
const axisID = {y: "W", y1: "V", y2: "°C", y3: "A"};
const power_line_scale = {
  x: {
    type: 'time',
    time: {
      tooltipFormat: timeFormat,
      displayFormats: {
        minute: timeFormat,
      },
      round: 'minute',
      unit: 'minute'
    },
    title: {
      display: true,
      text: 'Heure'
    }
  },
  y: { // Power axis
      type: 'linear',
      position: 'left',
      title: {
        display: true,
        text: 'W'
      },
      grid: {
        display: true,
        color: '#888'
      }
  },
  y1: { // Voltage axis
      type: 'linear',
      position: 'right',
      title: {
        display: true,
        text: 'V'
      },
      grid: {
        display: false,
      }
  },
  y2: { // Temp axis
      type: 'linear',
      position: 'right',
      title: {
        display: true,
        text: '°C'
      },
      grid: {
        display: true,
        color: '#ddd'
      }
  },
  y3: { // Current axis
      type: 'linear',
      position: 'right',
      display: false,
      title: {
        display: true,
        text: 'A'
      },
      grid: {
        display: false,
      }
  },
};

const zoomOptions = {
//  limits: {
//    x: {min: -200, max: 200, minRange: 50},
//    y: {min: -200, max: 200, minRange: 50}
//  },
  pan: {
    enabled: true,
    mode: 'x',
  },
  zoom: {
    wheel: {
      enabled: true,
    },
    drag: {
      enabled: true
    },
    pinch: {
      enabled: true
    },
    mode: 'x',
    onZoomComplete({chart}) {
      // This update is needed to display up to date zoom level in the title.
      // Without this, previous zoom level is displayed.
      // The reason is: title uses the same beforeUpdate hook, and is evaluated before zoom.
      chart.update('none');
    }
  }
};

// For background
const plugin = {
  id: 'customCanvasBackgroundColor',
  beforeDraw: (chart, args, options) => {
    const {ctx} = chart;
    ctx.save();
    ctx.globalCompositeOperation = 'destination-over';
    ctx.fillStyle = options.color || '#ffffff';
    ctx.fillRect(0, 0, chart.width, chart.height);
    ctx.restore();
  }
};

// ***************************
// Data Plot line functions
// ***************************

const chartColors = {
  red: 'rgb(255, 0, 0)',
  pink: 'rgb(255, 99, 132)',
  orange: 'rgb(255, 159, 64)',
  yellow: 'rgb(255, 205, 86)',
  green: 'rgb(0, 255, 0)',
  lightgreen: 'rgb(75, 192, 192)',
  blue: 'rgb(0, 0, 255)',
  lightblue: 'rgb(54, 162, 235)',
  purple: 'rgb(153, 102, 255)',
  grey: 'rgb(201, 203, 207)'
};

const chartColors_alpha = {
  red: 'rgba(255, 0, 0, 0.2)',
  pink: 'rgba(255, 99, 132, 0.2)',
  orange: 'rgba(255, 159, 64, 0.2)',
  yellow: 'rgba(255, 205, 86, 0.2)',
  green: 'rgba(0, 255, 0, 0.2)',
  lightgreen: 'rgba(75, 192, 192, 0.2)',
  blue: 'rgba(0, 0, 255, 0.2)',
  lightblue: 'rgba(54, 162, 235, 0.2)',
  purple: 'rgba(153, 102, 255, 0.2)',
  grey: 'rgba(201, 203, 207, 0.2)'
};

const data_line_power = [
    {
      label: 'Puissance',
      backgroundColor: chartColors_alpha.blue,
      borderColor: chartColors.blue,
      fill: true,
      data: new Array(),
      borderWidth: 1,
      yAxisID: 'y', // power-axis
      pointRadius: 2
    }, {
      label: 'Tension',
      backgroundColor: chartColors.green,
      borderColor: chartColors.green,
      fill: false,
      data: new Array(),
      borderWidth: 2,
      yAxisID: 'y1', // voltage-axis
      pointRadius: 2
    }, {
      label: 'Temp Cirrus',
      backgroundColor: chartColors.red,
      borderColor: chartColors.red,
      fill: false,
      data: new Array(),
      borderWidth: 2,
      yAxisID: 'y2',
      pointRadius: 2
    }, {
      label: 'Temp interne',
      backgroundColor: chartColors.yellow,
      borderColor: chartColors.yellow,
      fill: false,
      data: new Array(),
      borderWidth: 2,
      yAxisID: 'y2',
      pointRadius: 2
    }, {
      label: 'Temp externe',
      backgroundColor: chartColors.pink,
      borderColor: chartColors.pink,
      fill: false,
      data: new Array(),
      borderWidth: 2,
      yAxisID: 'y2',
      pointRadius: 2
    }
];

const data_bar_energy = {
  labels: ['1'],
  datasets: [{
      label: 'E Conso',
      borderWidth: 2,
      backgroundColor: chartColors_alpha.blue,
      borderColor: chartColors.blue,
      data: [1]
  }, {
      label: 'E Surplus',
      borderWidth: 2,
      backgroundColor: chartColors_alpha.red,
      borderColor: chartColors.red,
      data: [1]
  }]
};

const onTooltipButtonClick = (evt) => {
  const interaction_mode = ['index', 'nearest', 'x', 'point']; //, 'dataset'
//  chart.options.plugins.tooltip.enabled = !chart.options.plugins.tooltip.enabled;

  if (evt === undefined) {
    var chart = divIdToChart[currentChart.id];
  }
  else {
    var chart = divIdToChart[evt.currentTarget.id.substring(3)];
  }

  let mode = chart.options.interaction.mode;
  let id = interaction_mode.indexOf(mode);
  if (id != interaction_mode.length - 1)
    id += 1;
  else
    id = 0;
  chart.options.interaction.mode = interaction_mode[id];
  chart.update();
}

const onResizeTooltipButton = (context) => {
  // Give an id to the button build with the id of the chart canvas
  let id_Btn = 'id_' + context.ctx.canvas.id;
  let tooltipButton = document.getElementById(id_Btn);
  if (!tooltipButton) {
    tooltipButton = document.createElement('BUTTON');
    const buttonText = document.createTextNode('T');
    tooltipButton.id = id_Btn;
    tooltipButton.classList.add('myButton');
    tooltipButton.title = "Change le mode d'affichage du tooltip";
    tooltipButton.style.position = 'relative';
    tooltipButton.appendChild(buttonText);
    context.canvas.parentNode.appendChild(tooltipButton);
    tooltipButton.addEventListener('click', (e) => {
      onTooltipButtonClick(e);
    });
  };
  const xPos = (context.width - 40) / -2;
  const yPos = (context.height - 20) * -1;
  tooltipButton.style.left = xPos + 'px';
  tooltipButton.style.top = yPos + 'px';
}

function create_Line(data_label, data_line, opt_title, opt_scale) {
  return [{
    type: 'line',
    data: {
      // data_label.slice() si on veut individualiser les dates
      labels: data_label,
      datasets: data_line
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      normalized: true,
      animation: false,

      parsing: {
        parsing: false,
      },

      plugins: {
        zoom: zoomOptions,
        title: {
          display: true,
          text: opt_title
        },
        legend: {
          position: 'top',
          onClick: function (event, legendItem) {
            let dataset = event.chart.data.datasets[legendItem.datasetIndex];
            let scaleAxis = event.chart.options.scales[dataset.yAxisID];
            scaleAxis.display = !scaleAxis.display;
            dataset.hidden = !dataset.hidden;
            event.chart.update();
          }
        },
        tooltip: {
          titleColor: '#000',
          bodyColor: '#000',
          backgroundColor: 'rgba(255, 249, 196, 0.92)',
          borderColor: 'rgb(0, 0, 255)',
          borderWidth: 1,
          position: 'nearest',
          callbacks: {
            afterTitle: function(context) {
              return "-----------";
            },
            label: function(context) {
              // console.log(context);
              let scaleID = context.dataset.yAxisID;
              return '  ' + context.dataset.label + ': ' + context.raw + ' ' + axisID[scaleID];
            }
          }
        },
        customCanvasBackgroundColor: {
          color: 'white',
        },
      },
      interaction: {
 //       axis: 'x',
        mode: 'index',  // index nearest  point dataset x
        intersect: false
      },
      scales: opt_scale,

//      onResize: onResizeTooltipButton,
    },
    plugins: [plugin],
  },
  data_line.length];
}

function create_Bar_Energy(data_bar, opt_title, opt_unit) {
  return {
    type: 'bar',
    data: data_bar,
    options: {
      elements: {
        rectangle: {
          borderWidth: 2
        }
      },
      responsive: true,
      maintainAspectRatio: false,
      normalized: true,
      animation: true,

      plugins: {
        zoom: zoomOptions,
        title: {
          display: true,
          text: opt_title
        },
        legend: {
          display: true,
          position: 'top'
        },
        tooltip: {
          titleColor: '#000',
          bodyColor: '#000',
          backgroundColor: 'rgba(255, 249, 196, 0.92)',
          borderColor: 'rgb(0, 0, 255)',
          borderWidth: 1,
          position: 'nearest',
          callbacks: {
            label: function(context) {
              // console.log(context);
                return '  ' + context.dataset.label + ': ' + Math.round(context.raw/10)/100.0 + ' kWh';
            }
          }
        },
        customCanvasBackgroundColor: {
          color: 'white',
        },
      },
      interaction: {
 //       axis: 'x',
        mode: 'index',  // index nearest  point dataset x
        intersect: false
      },
      scales: {
        x: {
          display: true,
          title: {
            display: true,
            text: opt_unit
          },
          ticks: {
            min: 0
          }
        },
        y: {
          display: true,
          title: {
            display: true,
            text: 'Wh'
          },
          ticks: {
            min: 0
          }
        }
      },

//      onResize: onResizeTooltipButton,
    },
    plugins: [plugin],
  };
}

// ***************************
// resize gestion
// ***************************

function getSize() {
  return {
    "width": window.innerWidth,
    "height": window.innerHeight
  };
}

function setGrapheHeight(PageName) {

  function setDivGrapheHeight(wh, div) {
    let h = wh - div.offsetTop - 10;
    div.style.height = '' + h + 'px';
  }

  if (PageName !== undefined) {
    CurrentPageName = PageName;
  }
  let wh = getSize().height;

  if (CurrentPageName.id === 'm_Graphe') {
    setDivGrapheHeight(wh, document.getElementById('divPower'));
  }
  else
    if (CurrentPageName.id === 'm_Energy') {
      setDivGrapheHeight(wh, document.getElementById('divEnergy'));
    }
}

// ***************************
// Undo zoom
// ***************************

function undoZoom(can_plot) {
  if (can_plot === undefined)
    can_plot = currentChart.id;
  divIdToChart[can_plot].resetZoom();
}

function ondblClick(evt) {
//  console.log(evt);
  let can = evt.target;
  undoZoom(can.id);
}

// ***************************
// Context menu for the chart
// ***************************

// The chart menu defined in document
const chartMenu = document.getElementById('chartMenu');
// The current chart where we have clicked
// This object is used in selected action
var currentChart;
// Hide the context menu when we click elsewhere on the document
document.onclick = hideChartMenu;

function hideChartMenu() {
  chartMenu.style.display = 'none';
  currentChart = null;
}

function onRightClick(e) {
  e.preventDefault();
  hideChartMenu();
  chartMenu.style.display = 'block';
  chartMenu.style.left = `${e.pageX}px`;
  chartMenu.style.top = `${e.pageY}px`;
  currentChart = e.target;
}

function appendChartMenuStyle() {
  const style = document.createElement("style");
  style.textContent = '.context-menu { \
    position: absolute; \
    text-align: center; \
    background: #eee; \
    border: solid 2px rgba(165, 11, 192, 1); \
    border-radius: 5px; \
  } \
   \
  .context-menu ul { \
    padding: 0; \
    margin: 0; \
    min-width: 150px; \
    list-style: none; \
  } \
   \
  .context-menu ul li { \
    padding: 2px 0; \
    border: solid 1px rgba(165, 11, 192, 1); \
  } \
   \
  .context-menu ul li:hover { \
    background: rgba(165, 11, 192, 0.2); \
    cursor: pointer; \
  }';
  document.head.appendChild(style);
}

// ***************************
// Initialization
// ***************************

Chart.defaults.font.size = 14;
Chart.defaults.font.family = "'Times New Roman', Times, serif";  // "'Arial', sans-serif"
//Chart.defaults.font.weight = 400;

Chart.defaults.backgroundColor = '#9BD0F5';
Chart.defaults.borderColor = '#aaa'; // #36A2EB
Chart.defaults.color = '#000';

Chart.defaults.plugins.title.font.size = 20;

function initializeGraphe() {
  // Power, Voltage, Temp
  [power_line, power_line_length] = create_Line(data_date_formated, data_line_power, 'Tension, puissance et température', power_line_scale);
  let ctx = document.getElementById('can_mean_power');
  LineGraph_Power = new Chart(ctx, power_line);
  ctx.ondblclick = ondblClick;
  ctx.oncontextmenu = onRightClick;
  ctx['chartName'] = 'Puissance';
  ctx['target'] = 'data';
  divIdToChart['can_mean_power'] = LineGraph_Power;

  energy_bar = create_Bar_Energy(data_bar_energy, 'Energie', 'Jour');
  ctx = document.getElementById('can_histo_energy');
  BarGraph_Energy = new Chart(ctx, energy_bar);
  energy_bar_length = energy_bar.data.datasets.length;
  ctx.ondblclick = ondblClick;
  ctx.oncontextmenu = onRightClick;
  ctx['chartName'] = 'Energie';
  ctx['target'] = 'energy';
  divIdToChart['can_histo_energy'] = BarGraph_Energy;

  // Append the style for the context menu
  appendChartMenuStyle();

  // For test
//  updateGraph(data_graphe, 'data', false);

  window.addEventListener("resize", e => {
    setGrapheHeight();
  });
}

