"use strict";

// True pour le Cirrus CS5480
var FCS5480 = false;
var FCS5484 = false;

const PAGE0 = 0;
const PAGE16 = 16;
const PAGE17 = 17;
const PAGE18 = 18;

const SOFT_RESET = 0x01;
const STANDBY = 0x02;
const WAKEUP = 0x03;
const SINGLE_CONV = 0x14;
const CONT_CONV = 0x15;
const HALT_CONV = 0x18;

var Cirrus_request_busy = false;
var current_register = null;
var V1_SCALE = 242.0;
var I1_SCALE = 53.55;
var V2_SCALE = 242.0;
var I2_SCALE = 53.55;
var SCALE = [242.0, 53.55, 242.0, 53.55];
var ResponseTag = -1;
var ResponseTag2 = -1;

var wait_timeout = true;

var action_calib = [];
var action_mesure = [];
var action_pulse = [];
var action_config = [];
var action_Allcalib = [];
var current_action = {"status": "none", "action": null, "id": -1};

var CS_Config = "";
var CS_Config_log = "";
var CS_Dump = "";

// ***************************
// Configuration
// ***************************

function fill_OptionList(option, list) {
  // on supprime tout
  if (option.options.length > 0)
    while (option.options.length-- > 1)
    {
      ;
    }
  
  for (var i=0; i < list.length; i++)
  {
    let newOption = new Option(list[i], i);
    option.add(newOption,undefined);
  }  
}

// Initialisation de l'IHM en fonction du Cirrus présent
// et des différents tableaux
function initializeCirrus(is_CS5480) {
  FCS5480 = is_CS5480;
  FCS5484 = false;
  if (!FCS5480)
    document.getElementsByName("gbChannel2")[0].style.visibility = "hidden";

  document.getElementsByName("edU2_Calib")[0].disabled = ! FCS5480;
  document.getElementsByName("edI2_MAX")[0].disabled = ! FCS5480;

  // Calibration
  document.getElementsByName("edV2ACGain")[0].disabled = ! FCS5480;
  document.getElementsByName("edI2ACGain")[0].disabled = ! FCS5480;
  document.getElementsByName("edI2ACOff")[0].disabled = ! FCS5480;
  document.getElementsByName("edP2Off")[0].disabled = ! FCS5480;
  document.getElementsByName("edQ2Off")[0].disabled = ! FCS5480;

  // Filter
  document.getElementsByName("cbV2Filter")[0].disabled = ! FCS5480;
  document.getElementsByName("cbV2Filter")[0].selectedIndex = 0;
  document.getElementsByName("cbI2Filter")[0].disabled = ! FCS5480;
  document.getElementsByName("cbI2Filter")[0].selectedIndex = 0;

  // Rogowsky
//  document.getElementsByName("cbRogCh2")[0].disabled = ! FCS5480;
//  document.getElementsByName("cbRogCh2")[0].checked = false;

  // Pulse
  let domode = CS_config.DOMODE;  
  fill_OptionList(document.getElementsByName("cbDo1_MODE")[0], domode);
  fill_OptionList(document.getElementsByName("cbDo2_MODE")[0], domode);
  fill_OptionList(document.getElementsByName("cbDo3_MODE")[0], domode);

  document.getElementsByName("cbDo1_MODE")[0].selectedIndex = 14;
  document.getElementsByName("cbDo2_MODE")[0].selectedIndex = 14;
  document.getElementsByName("cbDo3_MODE")[0].selectedIndex = 14;
  
  let epg = CS_config.EPG;
  fill_OptionList(document.getElementsByName("cbEPG1")[0], epg);
  fill_OptionList(document.getElementsByName("cbEPG2")[0], epg);
  fill_OptionList(document.getElementsByName("cbEPG3")[0], epg);
  
  document.getElementsByName("cbEPG1")[0].selectedIndex = 0;
  document.getElementsByName("cbEPG2")[0].selectedIndex = 0;
  document.getElementsByName("cbEPG3")[0].selectedIndex = 0;

  document.getElementsByName("cbEPG2_Block")[0].disabled = ! FCS5480;
  document.getElementsByName("cbEPG2_Block")[0].selectedIndex = 0;
  document.getElementsByName("cbEPG3_Block")[0].disabled = ! FCS5480;
  document.getElementsByName("cbEPG3_Block")[0].selectedIndex = 0;
  document.getElementsByName("cbDo2_DO")[0].disabled = ! FCS5480;
  document.getElementsByName("cbDo2_DO")[0].selectedIndex = 0;
  document.getElementsByName("cbDo3_DO")[0].disabled = ! FCS5480;
  document.getElementsByName("cbDo3_DO")[0].selectedIndex = 0;
  document.getElementsByName("cbDo2_MODE")[0].disabled = ! FCS5480;
  document.getElementsByName("cbDo3_MODE")[0].disabled = ! FCS5480;
  document.getElementsByName("cbEPG2")[0].disabled = ! FCS5480;
  document.getElementsByName("cbEPG3")[0].disabled = ! FCS5480;

  // Config 0
  document.getElementsByName("cbI2PGA")[0].disabled = ! FCS5480;
  document.getElementsByName("cbI2PGA")[0].selectedIndex = 0;
  document.getElementsByName("cbIZX")[0].disabled = ! FCS5480;
  document.getElementsByName("cbIZX")[0].selectedIndex = 0;

  // Config 2
  document.getElementsByName("gbConfig2_CS5480")[0].disabled = ! FCS5480;
  if (!FCS5480)
    document.getElementsByName("gbConfig2_CS5480")[0].style.visibility = "hidden";
  document.getElementsByName("cbIHOLD")[0].selectedIndex = 0;
  
  // Create list action
  action_calib = makeCalibAction();
  action_mesure = makeMesureAction();
  action_pulse = makePulseAction();
  action_config = makeConfigAction();
  action_Allcalib = makeAllCalibAction();
    
  // Fill first register page for Cirrus
  select_page();
  
  // Get the scale
  bScaleClick(0);
}

function doIsCS5484() {
  FCS5484 = document.getElementsByName("IsCS5484")[0].checked;
  if (FCS5484)
  {
    document.getElementsByName("gbConfig2_CS5480")[0].style.visibility = "hidden";
    document.getElementsByName("gbConfig0_CS5484")[0].style.visibility = "visible";
    GetPageRegister(0, 0).Default = '0x 40 0000'; // Config 0
    GetPageRegister(16, 0).Default = '0x 06 0200'; // Config 2
  }
  else
  {
    document.getElementsByName("gbConfig2_CS5480")[0].style.visibility = "visible";
    document.getElementsByName("gbConfig0_CS5484")[0].style.visibility = "hidden";
    GetPageRegister(0, 0).Default = '0x C0 2000'; // Config 0
    GetPageRegister(16, 0).Default = '0x 00 0200'; // Config 2
  }
  select_register();
}

function makeCalibAction() {
  let action_array = [];
  
  action_array.push({"function": HexRegister, "page": PAGE16, "registre": 35, "params": {"tag": null, "edit": document.getElementsByName("edV1ACGain")[0]}});
  
  action_array.push({"function": HexRegister, "page": PAGE16, "registre": 33, "params": {"tag": null, "edit": document.getElementsByName("edI1ACGain")[0]}});
  
  action_array.push({"function": HexRegister, "page": PAGE16, "registre": 37, "params": {"tag": null, "edit": document.getElementsByName("edI1ACOff")[0]}});

  action_array.push({"function": HexRegister, "page": PAGE16, "registre": 36, "params": {"tag": null, "edit": document.getElementsByName("edP1Off")[0]}});

  action_array.push({"function": HexRegister, "page": PAGE16, "registre": 38, "params": {"tag": null, "edit": document.getElementsByName("edQ1Off")[0]}});

  if (FCS5480) {
    action_array.push({"function": HexRegister, "page": PAGE16, "registre": 42, "params": {"tag": null, "edit": document.getElementsByName("edV2ACGain")[0]}});

    action_array.push({"function": HexRegister, "page": PAGE16, "registre": 40, "params": {"tag": null, "edit": document.getElementsByName("edI2ACGain")[0]}});

    action_array.push({"function": HexRegister, "page": PAGE16, "registre": 44, "params": {"tag": null, "edit": document.getElementsByName("edI2ACOff")[0]}});

    action_array.push({"function": HexRegister, "page": PAGE16, "registre": 43, "params": {"tag": null, "edit": document.getElementsByName("edP2Off")[0]}});

    action_array.push({"function": HexRegister, "page": PAGE16, "registre": 45, "params": {"tag": null, "edit": document.getElementsByName("edQ2Off")[0]}});
  }
  return action_array;
}

function makeMesureAction() {
  let action_array = [];
  
  action_array.push({"function": GetSpecialMesure, "page": PAGE16, "registre": 7, "params": {"edit": document.getElementsByName("edCh1Vrms")[0]}}); // Urms
  
  action_array.push({"function": GetSpecialMesure, "page": PAGE16, "registre": 6, "params": {"edit": document.getElementsByName("edCh1Irms")[0]}}); // Irms
  
  action_array.push({"function": GetSpecialMesure, "page": PAGE16, "registre": 5, "params": {"edit": document.getElementsByName("edCh1PwrActive")[0]}}); // Active Power
  
  action_array.push({"function": GetSpecialMesure, "page": PAGE16, "registre": 20, "params": {"edit": document.getElementsByName("edCh1PwrApparent")[0]}}); // Apparent Power  
  
  action_array.push({"function": GetSpecialMesure, "page": PAGE16, "registre": 14, "params": {"edit": document.getElementsByName("edCh1PwrReactive")[0]}}); // Reactive Power
  
  action_array.push({"function": GetSpecialMesure, "page": PAGE16, "registre": 21, "params": {"edit": document.getElementsByName("edCh1PF")[0]}}); // Power Factor
  
  action_array.push({"function": GetSpecialMesure, "page": PAGE0, "registre": 36, "params": {"edit": document.getElementsByName("edCh1VPeak")[0]}}); // VPeak
  
  action_array.push({"function": GetSpecialMesure, "page": PAGE0, "registre": 37, "params": {"edit": document.getElementsByName("edCh1IPeak")[0]}}); // IPeak
  
  action_array.push({"function": GetSpecialMesure, "page": PAGE16, "registre": 49, "params": {"edit": document.getElementsByName("edFrequency")[0]}}); // Frequency

  // Channel 2
  if (FCS5480) {
  
    action_array.push({"function": GetSpecialMesure, "page": PAGE16, "registre": 13, "params": {"edit": document.getElementsByName("edCh2Vrms")[0]}});  // Urms

    action_array.push({"function": GetSpecialMesure, "page": PAGE16, "registre": 12, "params": {"edit": document.getElementsByName("edCh2Irms")[0]}});  // Irms

    action_array.push({"function": GetSpecialMesure, "page": PAGE16, "registre": 11, "params": {"edit": document.getElementsByName("edCh2PwrActive")[0]}});  // Active Power

    action_array.push({"function": GetSpecialMesure, "page": PAGE16, "registre": 24, "params": {"edit": document.getElementsByName("edCh2PwrApparent")[0]}});  // Apparent Power

    action_array.push({"function": GetSpecialMesure, "page": PAGE16, "registre": 16, "params": {"edit": document.getElementsByName("edCh2PwrReactive")[0]}});  // Reactive Power

    action_array.push({"function": GetSpecialMesure, "page": PAGE16, "registre": 25, "params": {"edit": document.getElementsByName("edCh2PF")[0]}});  // Power Factor

    action_array.push({"function": GetSpecialMesure, "page": PAGE0, "registre": 38, "params": {"edit": document.getElementsByName("edCh2VPeak")[0]}});  // VPeak

    action_array.push({"function": GetSpecialMesure, "page": PAGE0, "registre": 39, "params": {"edit": document.getElementsByName("edCh2IPeak")[0]}});  // IPeak
  }
  return action_array;
}

function makePulseAction() {
  let action_array = [];
  
  action_array.push({"function": HexRegister, "page": PAGE0, "registre": 8, "params": {"tag": 1, "edit": document.getElementsByName("edPulseWidthHEX")[0]}});
  
  action_array.push({"function": HexRegister, "page": PAGE18, "registre": 28, "params": {"tag": 1, "edit": document.getElementsByName("edPulseRateHEX")[0]}});
  
  action_array.push({"function": HexRegister, "page": PAGE0, "registre": 9, "params": {"tag": 1, "edit": document.getElementsByName("edPulseControlHEX")[0]}});
  return action_array;
}

function makeConfigAction() {
  let action_array = [];
  
  action_array.push({"function": AddConfig, "page": PAGE0, "registre": 0, "params": {"text": 'Config0', "edit": document.getElementsByName("edConfig0")[0], "conf": true, "log": 'Config register'}});
  
  action_array.push({"function": AddConfig, "page": PAGE0, "registre": 1, "params": {"text": 'Config1', "edit": document.getElementsByName("edConfig1")[0], "conf": true, "log": ''}});
  
  action_array.push({"function": AddConfig, "page": PAGE16, "registre": 0, "params": {"text": 'Config2', "edit": document.getElementsByName("edConfig2")[0], "conf": true, "log": ''}});
  
  action_array.push({"function": AddConfig, "page": PAGE0, "registre": 8, "params": {"text": 'Pulse Width', "edit": document.getElementsByName("edPulseWidthHEX")[0], "conf": true, "log": 'Pulse register'}});
  
  action_array.push({"function": AddConfig, "page": PAGE18, "registre": 28, "params": {"text": 'Pulse Rate', "edit": document.getElementsByName("edPulseRateHEX")[0], "conf": true, "log": ''}});
  
  action_array.push({"function": AddConfig, "page": PAGE0, "registre": 9, "params": {"text": 'Pulse Control', "edit": document.getElementsByName("edPulseControlHEX")[0], "conf": true, "log": ''}});  
 
  return action_array;
}

function makeAllCalibAction() {
  let action_array = [];
  
  action_array.push({"function": getScaleAction});  
  
  action_array.push({"function": AddConfig, "page": PAGE16, "registre": 35, "params": {"text": 'VGAIN', "edit": document.getElementsByName("edV1ACGain")[0], "conf": true, "log": 'Gain AC Channel 1'}});
  
  action_array.push({"function": AddConfig, "page": PAGE16, "registre": 33, "params": {"text": 'IGAIN', "edit": document.getElementsByName("edI1ACGain")[0], "conf": true, "log": ''}});
  
  action_array.push({"function": AddConfig, "page": PAGE16, "registre": 37, "params": {"text": 'IACOFF', "edit": document.getElementsByName("edI1ACOff")[0], "conf": true, "log": 'AC Offset Channel 1'}});
  
  action_array.push({"function": AddConfig, "page": PAGE16, "registre": 34, "params": {"text": 'VDCOFF', "edit": null, "conf": false, "log": 'DC Offset Channel 1'}});
  
  action_array.push({"function": AddConfig, "page": PAGE16, "registre": 32, "params": {"text": 'IDCOFF', "edit": null, "conf": false, "log": ''}});
  
  action_array.push({"function": AddConfig, "page": PAGE16, "registre": 36, "params": {"text": 'POFF', "edit": document.getElementsByName("edP1Off")[0], "conf": true, "log": 'No Load Offset Channel 1'}});  

  action_array.push({"function": AddConfig, "page": PAGE16, "registre": 38, "params": {"text": 'QOFF', "edit": document.getElementsByName("edQ1Off")[0], "conf": true, "log": ''}});
   
  // Deuxième channel
  if (FCS5480) {
    action_array.push({"function": getScaleChannel2Action}); 
    
    action_array.push({"function": AddConfig, "page": PAGE16, "registre": 42, "params": {"text": 'V2GAIN', "edit": document.getElementsByName("edV2ACGain")[0], "conf": true, "log": 'Gain AC Channel 2'}});

    action_array.push({"function": AddConfig, "page": PAGE16, "registre": 40, "params": {"text": 'I2GAIN', "edit": document.getElementsByName("edI2ACGain")[0], "conf": true, "log": ''}});

    action_array.push({"function": AddConfig, "page": PAGE16, "registre": 44, "params": {"text": 'I2ACOFF', "edit": document.getElementsByName("edI2ACOff")[0], "conf": true, "log": 'AC Offset Channel 2'}});

    action_array.push({"function": AddConfig, "page": PAGE16, "registre": 41, "params": {"text": 'V2DCOFF', "edit": null, "conf": false, "log": 'DC Offset Channel 2'}});

    action_array.push({"function": AddConfig, "page": PAGE16, "registre": 39, "params": {"text": 'I2DCOFF', "edit": null, "conf": false, "log": ''}});

    action_array.push({"function": AddConfig, "page": PAGE16, "registre": 43, "params": {"text": 'P2OFF', "edit": document.getElementsByName("edP2Off")[0], "conf": true, "log": 'No Load Offset Channel 2'}});  

    action_array.push({"function": AddConfig, "page": PAGE16, "registre": 45, "params": {"text": 'Q2OFF', "edit": document.getElementsByName("edQ2Off")[0], "conf": true, "log": ''}});  
  }
  
  action_array.push({"function": AddConfig, "page": PAGE16, "registre": 1, "params": {"text": 'RegChk', "edit": null, "conf": false, "log": 'Register Checksum'}});  
  
  return action_array;
}

// ***************************
// Fonction générale
// ***************************

function changeLed(color, ledID) {
  if (ledID === undefined)
    ledID = "led_" + CurrentPage.id;
  var led = document.getElementById(ledID);
  
  if (led !== null) {
    led.className = led.className.replace(/green|yellow|red/gi, function(matched){
      return color;
    });
  }  
}

function Format_Hex(value) {
  return  ("0x" + ('000000' + value.toString(16).toUpperCase()).slice(-6));
}

function get_LSB(lValue) {
  return lValue & 0x0000FF;
}

function get_MSB(lValue) {
  return (lValue >> 8) & 0x00FF;
}

function get_HSB(lValue) {
  return (lValue >> 16);
}

function set_Int24(LSB, MSB, HSB) {
  return (LSB + (MSB << 8) + (HSB << 16));
}

function convertToInt(hex_text) {
  if (current_register == null)
    return "0";
  
  var val = Number(hex_text);
  var result = 1;
  
  if (current_register.Signe)
  {
    if ((val & 0x800000) != 0)
    {
      result = -result;
      val = val & 0x7F0000;
    }
  }  
  result = result * val;
  
  return result.toString();
}

function convertToFloat(hex_text, use_scale = true, prec = 2) { 
  if (current_register == null)
    return "0.0";
  
  var val = Number(hex_text);
//  var ValPower2 = Math.pow(2, current_register.Power2);
  var ValPower2 = 2 << (current_register.Power2 - 1);
  var result = 1.0/(ValPower2 - 1.0);
  
  if (current_register.Signe)
  {
    if ((val & 0x800000) != 0)
    {
      result = - result;
      val = val & 0x7F0000;
    }
  }
  result = result * val;

  if (use_scale)
  {
    switch (current_register.Scale)
    {
      case "NULL" : break;
      case "V1_SCALE" : result = result * SCALE[0] / 0.6; break;
      case "I1_SCALE" : result = result * SCALE[1] / 0.6; break;
      case "P1_SCALE" : result = result * SCALE[0] * SCALE[1] / 0.36; break;  
      case "V2_SCALE" : result = result * SCALE[2] / 0.6; break;
      case "I2_SCALE" : result = result * SCALE[3] / 0.6; break;
      case "P2_SCALE" : result = result * SCALE[2] * SCALE[3] / 0.36; break; 
      case "FREQ_SCALE" : result = result * 4000; break;
      default : break;
    }
  }

  return result.toFixed(prec);
}

// Create the command to get register(page, register)
function makeGetCommand(aPage, aRegister) {
  var lCommand = aPage;
  lCommand = (lCommand << 8) + aRegister;
  lCommand = (lCommand << 8) + 0x01;    // Read   
  return lCommand.toString();
}

// return an object with all properties of the register
function GetPageRegister(aPage, aRegister) {
  var json_page = null;
  
  if (aPage === 0)
    json_page = page0;
  else if (aPage === 16)
    json_page = page16;
  else if (aPage === 17)
    json_page = page17;
  else if (aPage === 18)
    json_page = page18; 
  
  if (json_page != null)
  {
    for (var i=0; i < json_page.length; i++)
    {
      if (json_page[i].Address == aRegister)
      {    
        var Register_object = json_page[i];
        var type = Register_object.Type;
        if (type === "conf")
        {
          Register_object["TypeOp"] = 0;
        }
        else
          if (type.indexOf("int") == 0)
          {
            Register_object["TypeOp"] = 1;
            var expo = parseInt(type.substr(3));
            Register_object["Signe"] = (expo < 0);
            Register_object["Power2"] = Math.abs(expo);
//            Register_object["ValPower2"] = Math.pow(2,Math.abs(expo));
          }
          else
            if (type.indexOf("float") == 0)
            {
              Register_object["TypeOp"] = 2;
              var expo = parseInt(type.substr(5));
              Register_object["Signe"] = (expo < 0);
              Register_object["Power2"] = Math.abs(expo);
//              Register_object["ValPower2"] = Math.pow(2,Math.abs(expo));
            }
            else
              Register_object["TypeOp"] = -1;
          
        return Register_object;
      }    
    }      
  }
  return null;
}

// Request to get a register.
// Request is send immediatly
// Response in handle_getRegister callback if no Params
// current_register must be defined
function GetRegister(aPage, aRegister, aParams = null) {
  if (Cirrus_request_busy)
    return;
  
  var cirrus_request = "REG=" + makeGetCommand(aPage, aRegister); 
  
  changeLed("yellow");
  
  // Send request directly asynchronous 
  if (aParams === null)
  {
    xmlHttp.open("PUT","/getCirrus",true);
    xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlHttp.onreadystatechange = handle_getRegister;
//    xmlHttp.ontimeout = function() {
//      alert("Cirrus request timeout");
//    }
//    xmlHttp.timeout = 2000;    
    xmlHttp.send(cirrus_request); 
    Cirrus_request_busy = true;
  }
  else // synchronous 
  {
//    xmlHttp.ontimeout = null;
    xmlHttp.Params = aParams;
    xmlHttp.open("PUT","/getCirrus",true);
    xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded"); 
//    xmlHttp.ontimeout = function() {
//      wait_timeout = false;
//    }
//    xmlHttp.timeout = 1000;     
    xmlHttp.onreadystatechange = function() {
      // Traitement de la réponse 
      if (requestIsOK(xmlHttp)) 
      {
        var xmlResponse = xmlHttp.responseText;

        Cirrus_request_busy = false; 
        if ((xmlResponse === null) || (current_register === null)) 
        {
          delete xmlHttp.Params;
          changeLed("red");
          return;
        }
        
        changeLed("green");

        // Traitement affichage
        if (xmlHttp.Params.edit != null) {
          if (('format' in xmlHttp.Params) && (xmlHttp.Params.format))
            xmlHttp.Params.edit.value = convertToFloat(xmlResponse);
          else
            xmlHttp.Params.edit.value = xmlResponse;
        }
        
        // Traitement extraction
        if ('text' in xmlHttp.Params) {
          if (xmlHttp.Params.conf) {            
            if (xmlHttp.Params.text === "Config0")
              CS_Config = CS_Config + xmlResponse;
            else
              CS_Config = CS_Config + ", " + xmlResponse;
          }
          let the_action = current_action.action[current_action.id];
          if (xmlHttp.Params.log !== '')
            CS_Config_log = CS_Config_log + xmlHttp.Params.log + "\r\n";
          CS_Config_log = CS_Config_log + xmlHttp.Params.text + " - Page: " + the_action.page + "; Registre: " + the_action.registre + "; Value: " + xmlResponse + "\r\n";
        }
                
        delete xmlHttp.Params;
                       
        // Do the next action
        if (current_action.status !== "none")
        {
          current_action.id++;
          // Dans le cas de mesure, on boucle sur les actions
          if ((current_action.id == current_action.action.length) && (current_action.status === "mesure"))
          {
            // back to first action
            current_action.id = 0;            
          }
          if (current_action.id < current_action.action.length)
          {
            let the_action = current_action.action[current_action.id];
            the_action.function(the_action.page, the_action.registre, the_action.params); 
          }
          else
            {
              if (current_action.status == "config") {
                CS_Config = CS_Config + '};';
                alert(CS_Config)
                alert(CS_Config_log);
              }
                
              current_action.status = "none";
            }            
        }
      }      
    }    
    xmlHttp.send(cirrus_request);
    Cirrus_request_busy = true;
  }
//  alert(cirrus_request);
}

// Function to handle the response
// The flag ResponseTag is used to dispatch the response
// The response is in hex over 6 digits in uppercase : 0xABCDEF
function handle_getRegister()  {
  if (requestIsOK(xmlHttp)) 
  {
    var xmlResponse = xmlHttp.responseText;
    request_busy = false;
    
    if ((xmlResponse === null) || (current_register === null)) return;
    
    Cirrus_request_busy = false;
    if (xmlResponse == "#REG_ERROR")
    {
      alert("Read register error.");
      changeLed("red");
      return;
    }
    else changeLed("green");
        
    switch (ResponseTag)
    {
      case 0: bGetRegisterResponse(xmlResponse); break;
      case 1: bSampleCycleTimeResponse(xmlResponse); break;
      case 2: bConfig0ClickResponse(xmlResponse); break;
      case 3: bConfig2ClickResponse(xmlResponse); break; 
      case 4: bPulseClickResponse(xmlResponse); break;
      case 5: bConfig1ClickResponse(xmlResponse); break;
      case 6: bBaudRateClickResponse(xmlResponse); break;  
    }    
  }
}

// Request to set a register.
// Request is send immediatly
// aValue in hex
// current_register must be defined
function SetRegister(aPage, aRegister, aValue) {
  if (Cirrus_request_busy)
    return;
  
  var lCommand = aValue;
  lCommand = (lCommand * 256) + aPage;
  lCommand = (lCommand * 256) + aRegister;
  lCommand = lCommand * 256 + 0x00;    // Write;
  // Equivaut à la commande ci-dessous qui ne marche pas car limité à 32 bits
  // lCommand * 256 équivaut à (lCommand << 8)
  
  var cirrus_request = "REG=" + lCommand.toString();
  changeLed("yellow");
  
  // Send request directly
  xmlHttp.open("PUT","/getCirrus",true);
  xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xmlHttp.onreadystatechange = function() {
    if (requestIsOK(xmlHttp)) 
    {
      var xmlResponse = xmlHttp.responseText;
      request_busy = false;

      if ((xmlResponse === null) || (current_register === null)) return;

      if (xmlResponse != "#REG_OK") {
        changeLed("red");
        alert("Write register error.");
      }
      else changeLed("green");
      Cirrus_request_busy = false;

      // Do the next action
      if (current_action.status !== "none")
      {
        current_action.id++;
        if (current_action.id < current_action.action.length)
        {
          let the_action = current_action.action[current_action.id];
          the_action.function(the_action.page, the_action.registre, the_action.params); 
        }
        else
          current_action.status = "none";
      }
    }    
  }
  xmlHttp.send(cirrus_request);
  Cirrus_request_busy = true;
//  alert(cirrus_request);    
}

// Send a command
function SendCommand(aCommand) {
  if (Cirrus_request_busy)
    return;
  
  var lCommand = 1; // On utilise PAGE1 qui n'existe pas
  lCommand = (lCommand << 8) + aCommand;
  lCommand = (lCommand << 8) + 0x00;    // Write
  
  var cirrus_request = "REG=" + lCommand.toString(); 
  changeLed("yellow");
  
  // Send request directly
  xmlHttp.open("PUT","/getCirrus",true);
  xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xmlHttp.onreadystatechange = function() {
    // Traitement de la réponse 
    if (requestIsOK(xmlHttp)) 
    {
      var xmlResponse = xmlHttp.responseText;

      if ((xmlResponse === null) || (current_register === null)) return; 
      
      if (xmlResponse != "#REG_OK") {
        changeLed("red");
        alert("Write register error.");
      }        
      else changeLed("green");
      Cirrus_request_busy = false;
    }
  }
  xmlHttp.send(cirrus_request);
  Cirrus_request_busy = true;
}

// Get/set integer register
function IntegerRegister(aGetter, aPage, aRegister, aMin, aValue) {
  current_register = GetPageRegister(aPage, aRegister);
  if (current_register != null) {
    if (aGetter === 0) {
      GetRegister(aPage, aRegister);
    }
    else
    {
      let lValue = aValue;
      let ValPower2 = Math.pow(2, current_register.Power2);
      if (lValue > ValPower2) lValue = ValPower2;
      if (lValue < aMin) lValue = aMin;
      SetRegister(aPage, aRegister, lValue);    
    }
  }  
}

function FloatRegister(aGetter, aPage, aRegister, aMin, aValue) {
  current_register = GetPageRegister(aPage, aRegister);
  if (current_register != null) 
  {
    if (aGetter === 0) {
      GetRegister(aPage, aRegister);
    }
    else
    {
      let ValPower2 = Math.pow(2, current_register.Power2); 
      var lValue = Math.round(Math.abs(aValue) * ValPower2);
      if (aValue < 0)
        lValue = lValue | 0x800000;

      SetRegister(aPage, aRegister, lValue);
      return lValue;
    }
  }
}

function HexRegister(aPage, aRegister, aParams) {
  current_register = GetPageRegister(aPage, aRegister);
  if (current_register != null)
  {
    if (aParams.tag === 0) {
      GetRegister(aPage, aRegister, {"edit": aParams.edit});
    }
    else
    {
      let aValue = aParams.edit.value;
      aValue.trim();
      if (aValue != "")
      {
        let lValue = Number(aValue);
        SetRegister(aPage, aRegister, lValue);
      }
      else alert("Une valeur est nulle : " + aParams.edit.name.substring(2));
    }
  }
}

function GetSpecialMesure(aPage, aRegister, aParams) {
  current_register = GetPageRegister(aPage, aRegister);
  if (current_register != null)
  {
    var raw = document.getElementsByName("cbRawData")[0].checked;
    GetRegister(aPage, aRegister, {"edit": aParams.edit, "format": (!raw)});
  }
}

function AddConfig(aPage, aRegister, aParams) {
  current_register = GetPageRegister(aPage, aRegister);
  if (current_register != null)
  {
    GetRegister(aPage, aRegister, aParams);
  }
}

function ClearDataReady() {
//  ClearBitMask(PAGE0, $17, 23);
  // ou 0xFFFFFF  ou 0xC00000 ou 0x800000
  SetRegister(PAGE0, 0x17, 0x800000);
}

function SetTimeSettle(aTime_ms) {
  IntegerRegister(1, PAGE16, 0x39, 0, Math.round(aTime_ms));
}

function SetSampleCount(aN_Sample) {
  IntegerRegister(1, PAGE16, 0x33, 100, aN_Sample);
}

// ***************************
// Traitement page register
// ***************************

// Option list page change
function select_page() {
  var select_page = document.getElementById('cirrus_page');  
  var id = select_page.selectedIndex;
  var page = select_page.options[id].value;
  var json = null;

  if (page === "0")
    json = page0;
  else if (page === "16")
    json = page16;
  else if (page === "17")
    json = page17;
  else if (page === "18")
    json = page18;  
  
  var register = document.getElementById('cirrus_register'); 
  
  // on supprime tout
  if (register.options.length > 0)
    while (register.options.length-- > 1)
    {
      ;
    }
  
  for ( var i=0; i < json.length; i++ )
  {
    if (json[i].Description.trim() !== "Reserved")
    {    
      let newOption = new Option(json[i].Name + " (" + json[i].Description + ")", json[i].Address);
      register.add(newOption,undefined);
    }
  }
  select_register();
}

// Option list register change
function select_register() {
  var select_page = document.getElementById('cirrus_page');  
  var id = select_page.selectedIndex;
  var page = select_page.options[id].value;
  
  var select_register = document.getElementById('cirrus_register');
  id = select_register.selectedIndex;
  var register = select_register.options[id].value;
  
  current_register = GetPageRegister(parseInt(page), parseInt(register));
  
  if (current_register != null)
  {
    document.getElementById("comment_register").innerHTML = "Comment : " + current_register.Description; 
    document.getElementById("default_register").innerHTML = "Default : " + current_register.Default;
    document.getElementById("protect_register").innerHTML = "Protect : " + current_register.Protect;
    document.getElementById("result_register").innerHTML = "Result : ";
  }
}

// Get register : ResponseTag = 0
function bGetRegisterClick() {
  var select_page = document.getElementById('cirrus_page');  
  var id = select_page.selectedIndex;
  var page = select_page.options[id].value; 
  var select_register = document.getElementById('cirrus_register');
  id = select_register.selectedIndex;
  var register = select_register.options[id].value;
  
  ResponseTag = 0;
  current_register = GetPageRegister(parseInt(page), parseInt(register));
  GetRegister(parseInt(page), parseInt(register));
}

function bGetRegisterResponse(xmlResponse) {    
  var text = xmlResponse;  

  switch (current_register.TypeOp)
  {
    case 0: break;
    case 1: text = text + " soit Int = " + convertToInt(xmlResponse); break;
    case 2: text = text + " soit Float : " + convertToFloat(xmlResponse, true, 4); break; 
    default : ;  
  }

  document.getElementById("result_register").innerHTML = "Result : " +text;  
  ResponseTag = -1;
}

// Get/set scale
function bScaleClick(tag) {
  if (tag == 0)
  {
    let cirrus_request = "SCALE="; 
    xmlHttp.open("PUT","/getCirrus",true);
    xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlHttp.onreadystatechange = bScaleResponse;
    xmlHttp.send(cirrus_request);    
  }
  else
    {
      SCALE[0] = "0" + document.getElementsByName("edU1_Calib")[0].value;
      SCALE[1] = "0" + document.getElementsByName("edI1_MAX")[0].value;
      SCALE[2] = "0" + document.getElementsByName("edU2_Calib")[0].value;
      SCALE[3] = "0" + document.getElementsByName("edI2_MAX")[0].value;
      // NE PAS UTILISER le ; comme séparateur !!!
      let cirrus_request = "SCALE=" + SCALE.join("#");
      xmlHttp.open("PUT","/getCirrus",true);
      xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
      xmlHttp.onreadystatechange = null;
      xmlHttp.send(cirrus_request); 
//      alert(cirrus_request);
    }
}

function bScaleResponse() { 
  if (requestIsOK(xmlHttp)) 
  {
    var xmlResponse = xmlHttp.responseText;
    request_busy = false;
    
    if ((xmlResponse === null) || (current_register === null)) return false;
      
    SCALE = xmlResponse.split(';');
    document.getElementsByName("edU1_Calib")[0].value = SCALE[0];
    document.getElementsByName("edI1_MAX")[0].value = SCALE[1];
    document.getElementsByName("edU2_Calib")[0].value = SCALE[2];
    document.getElementsByName("edI2_MAX")[0].value = SCALE[3];
    return true;
  }
  else 
    return false;
}

function ChangeBaud(aBaud) {
  let cirrus_request = "BAUD=" + aBaud;
  changeLed("yellow");
  xmlHttp.open("PUT","/getCirrus",true);
  xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xmlHttp.onreadystatechange = function() {
    if (requestIsOK(xmlHttp)) 
    {
      var xmlResponse = xmlHttp.responseText;

      Cirrus_request_busy = false; 
      if ((xmlResponse === null) || (xmlResponse !== "BAUD_OK")) 
      {
        changeLed("red");
        alert("Change baud failed. Restart cirrus.")
        return;
      }
      else
        changeLed("green");
    }
  }
  xmlHttp.send(cirrus_request);
}

function GetItemBaud(aBaud) {
  aBaud = aBaud - 10;
  
  let baud = document.getElementsByName("cbBaudRate")[0];
  for (var i = 0; i< baud.length; i++)
  {
    if (Number(baud.options[i].text) >= aBaud)
    {
      return i;
    }
  }
  return 0;
}

function bBaudRateClick(tag) {
  if (tag == 0)
  {
    ResponseTag = 6;
    GetRegister(PAGE0, 0x07);  // P0_SerialCtrl
  }
  else
  {
    if (window.confirm("Etes-vous sûr de vouloir changer la vitesse ?"))
    {
      let baud = document.getElementsByName("cbBaudRate")[0];
      if (baud.selectedIndex == -1) 
        alert("Sélectionner une vitesse.");
      else
      {
        ChangeBaud(baud.options[baud.selectedIndex].text);          
      }
    }
  }
}

function bBaudRateClickResponse(xmlResponse) {
  var baud = Number(xmlResponse);
  
  baud = baud & 0xFFFF;
  baud = Math.floor(((baud + 1) * 4096000) / 524288);
  document.getElementsByName("cbBaudRate")[0].selectedIndex = GetItemBaud(baud); 
  ResponseTag = -1;
}

function getDumpAction(aPage, aRegister) {
  var json_page = null;
  
  if (aPage === 0)
    json_page = page0;
  else if (aPage === 16)
    json_page = page16;
  else if (aPage === 17)
    json_page = page17;
  else if (aPage === 18)
    json_page = page18; 
  
  if (json_page != null)
  {
    while ((aRegister < json_page.length) && (json_page[aRegister].Name.trim() === ""))
      aRegister++;
  }
  else return;
  
  if (aRegister < json_page.length)
  {
    var cirrus_request = "REG=" + makeGetCommand(aPage, aRegister); 

    changeLed("yellow");
    
    xmlHttp.Params = {"page": aPage, "register": aRegister, "name": json_page[aRegister].Name};
    xmlHttp.open("PUT","/getCirrus",true);
    xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlHttp.onreadystatechange = function() {
      if (requestIsOK(xmlHttp)) 
      {
        var xmlResponse = xmlHttp.responseText;

        Cirrus_request_busy = false; 
        if ((xmlResponse === null) || (current_register === null)) 
        {
          delete xmlHttp.Params;
          changeLed("red");
          return;
        }
        
        changeLed("green");
        
        CS_Dump = CS_Dump + "Page: " + xmlHttp.Params.page + "; Registre: " + xmlHttp.Params.register + "; Value: " + xmlResponse + " (" + xmlHttp.Params.name + ")\r\n";
        
        // Do the next action
        if (current_action.status !== "none")
        {
          getDumpAction(xmlHttp.Params.page, xmlHttp.Params.register + 1);       
        }
      }
    }
    xmlHttp.send(cirrus_request);
    Cirrus_request_busy = true;
  }
  else {
    if (aPage === PAGE0) {
      CS_Dump = CS_Dump + "PAGE16\r\n";
      getDumpAction(PAGE16, 0);
      return;
    }
    if (aPage === PAGE16) {
      CS_Dump = CS_Dump + "PAGE17\r\n";
      getDumpAction(PAGE17, 0);
      return;
    }
    if (aPage === PAGE17) {
      CS_Dump = CS_Dump + "PAGE18\r\n";
      getDumpAction(PAGE18, 0);
      return;
    }
    current_action.status = "none";
    delete xmlHttp.Params;
    alert(CS_Dump);
  }
}

function bDumpClick() {
  current_action.status = "dump";
  CS_Dump = "PAGE0\r\n";
  getDumpAction(PAGE0, 0);
}

function bSoft_ResetClick() {
  if (window.confirm("Attention, réinitialisation des registres du Cirrus. La vitesse sera de 600 bauds. On continue ?"))
  {
    // Send soft reset command
    SendCommand(SOFT_RESET);
    document.getElementsByName("bStartContinuous")[0].textContent = 'Start Continuous';
  }
}

function bConversionClick(tag) {
  let bStart = document.getElementsByName("bStartContinuous")[0];
  switch (tag) {
    case 0: {  // Start Continuous
        if (bStart.textContent.trim() == 'Start Continuous')
        {
          SendCommand(CONT_CONV);
          bStart.textContent = 'Stop Continuous';
        }
        else
        {
          SendCommand(HALT_CONV);
          bStart.textContent = 'Start Continuous';
        }
      break;
    }
    case 1: {  // Single Conversion
      SendCommand(SINGLE_CONV);
      bStart.textContent = 'Start Continuous';
      break;
    }
    case 2: {  // Stop Conversion
      SendCommand(HALT_CONV);
      bStart.textContent = 'Start Continuous';
      break;
    }
  }
}

function bSampleCountClick(tag) {
  var ValInt = document.getElementsByName("edSampleCount")[0].value;
  ResponseTag = 1;
  ResponseTag2 = 0;
  IntegerRegister(tag, 16, 0x33, 100, ValInt);
}

function bCycleCountClick(tag) {
  var ValInt = document.getElementsByName("edCycleCount")[0].value;
  ResponseTag = 1;
  ResponseTag2 = 1;
  IntegerRegister(tag, 18, 0x3E, 1, ValInt);
}

function bTimeSettleClick(tag) {
  var ValInt = document.getElementsByName("edTimeSettle")[0].value * 4;
  ResponseTag = 1;
  ResponseTag2 = 2;
  IntegerRegister(tag, 16, 0x39, 0, ValInt);
}

function bSampleCycleTimeResponse(xmlResponse) {
  var result = convertToInt(xmlResponse);
  switch (ResponseTag2) {
    case 0: document.getElementsByName("edSampleCount")[0].value = result; break;
    case 1: document.getElementsByName("edCycleCount")[0].value = result; break;
    case 2: document.getElementsByName("edTimeSettle")[0].value = result / 4; break;  
  }
  ResponseTag = -1;
}

function bCalibClick(tag) {
  // On pointe sur le tableau calib
  current_action.action = action_calib;
  current_action.id = 0;
  current_action.status = "calib";
  
  // Update tag
  for (var i=0; i<current_action.action.length; i++)
    current_action.action[i].params.tag = tag;
  
  // Do the first action
  var the_action = current_action.action[0];
  the_action.function(the_action.page, the_action.registre, the_action.params);
}

function getScaleAction() {
  let cirrus_request = "SCALE="; 
  xmlHttp.open("PUT","/getCirrus",true);
  xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xmlHttp.onreadystatechange = function () {
    
    if (bScaleResponse()) {    
      CS_Config = "CS_Calib = {";
      CS_Config_log = "AC SCALE Channel 1\r\n";

      var U1_Calib = document.getElementsByName("edU1_Calib")[0].value;
      var I1_MAX = document.getElementsByName("edI1_MAX")[0].value;

      CS_Config = CS_Config + U1_Calib + ', ' + I1_MAX;
      CS_Config_log = CS_Config_log + 'U1_Calib: ' + U1_Calib + '\r\nI1_MAX: ' + I1_MAX + '\r\n';

      current_action.id++;
      if (current_action.id < current_action.action.length)
      {
        let the_action = current_action.action[current_action.id];
        the_action.function(the_action.page, the_action.registre, the_action.params); 
      }
    }
  }
  xmlHttp.send(cirrus_request);    
}

function getScaleChannel2Action() {
  var U2_Calib = document.getElementsByName("edU2_Calib")[0].value;
  var I2_MAX = document.getElementsByName("edI2_MAX")[0].value;

  CS_Config = CS_Config + ', ' + U2_Calib + ', ' + I2_MAX;
  CS_Config_log = CS_Config_log + "------ Channel 2 ------\r\n";
  CS_Config_log = CS_Config_log + "AC SCALE Channel 2\r\n";
  CS_Config_log = CS_Config_log + 'U2_Calib: ' + U2_Calib + '\r\nI2_MAX: ' + I2_MAX + '\r\n';  
  
  current_action.id++;
  if (current_action.id < current_action.action.length)
  {
    let the_action = current_action.action[current_action.id];
    the_action.function(the_action.page, the_action.registre, the_action.params); 
  }  
}

function bAllCoeffClick() {
  // On pointe sur le tableau calib
  current_action.action = action_Allcalib;
  current_action.id = 0;
  current_action.status = "config";
  
  // Do the first action : get scale, no parameter
  var the_action = current_action.action[0];
  the_action.function(); // the_action.page, the_action.registre, the_action.params
}

function CheckLocked() {
  var sw = document.getElementById("Toggle_IHM");
  if (!sw.checked) {
    return window.confirm("IHM pas lockée, on continue ?");
  }
  return true;
}

function bCal_IACOff_Click() {
  if (!CheckLocked())
    return;

  if (window.confirm("AC nominal et aucune charge présente ? On continue ?"))
  {
    let cirrus_request = "IACOFF=";
    changeLed("yellow", "led_m_CS_Calibration");
    xmlHttp.open("PUT","/getCirrus",true);
    xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlHttp.onreadystatechange = function() {
      if (requestIsOK(xmlHttp)) 
      {
        var xmlResponse = xmlHttp.responseText;

        Cirrus_request_busy = false; 
        if ((xmlResponse === null) || (xmlResponse !== "IACOffset_OK")) 
        {
          changeLed("red", "led_m_CS_Calibration");
          alert("IAC offset calibration failed. Restart cirrus.")
          return;
        }
        else
          changeLed("green", "led_m_CS_Calibration");
      }
    }
    document.getElementsByName("bStartContinuous")[0].textContent = 'Stop Continuous';
    xmlHttp.send(cirrus_request);
  }
}

function bCal_PQOff_Click() {
  if (!CheckLocked())
    return;

  if (window.confirm("AC nominal et aucune charge présente ? On continue ?"))
  {
    let cirrus_request = "PQOFF=";
    changeLed("yellow", "led_m_CS_Calibration");
    xmlHttp.open("PUT","/getCirrus",true);
    xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlHttp.onreadystatechange = function() {
      if (requestIsOK(xmlHttp)) 
      {
        var xmlResponse = xmlHttp.responseText;

        Cirrus_request_busy = false; 
        if ((xmlResponse === null) || (xmlResponse !== "PQOffset_OK")) 
        {
          changeLed("red", "led_m_CS_Calibration");
          alert("P and Q offset calibration failed. Restart cirrus.")
          return;
        }
        else
          changeLed("green", "led_m_CS_Calibration");
      }
    }
    document.getElementsByName("bStartContinuous")[0].textContent = 'Stop Continuous';
    xmlHttp.send(cirrus_request);
  }
}

function bGainClick() {
  if (!CheckLocked())
    return;

  if (window.confirm("La charge est en marche ? On continue ?"))
  {
    let cirrus_request = "GAIN=";
    if (document.getElementById('radio_case2').checked == 1) {
      let IRef = document.getElementsByName("edIRef2")[0].value;
      let Spire = document.getElementsByName("edSpire2")[0].value;
      cirrus_request += IRef + "#" + Spire; 
    }
    else
    if (document.getElementById('radio_case3').checked == 1) {
      let URef = document.getElementsByName("edURef3")[0].value;
      let IRef = document.getElementsByName("edIRef3")[0].value;
      let Spire = document.getElementsByName("edSpire3")[0].value;
      cirrus_request += URef + "#" + IRef + "#" + Spire; 
    }

    changeLed("yellow", "led_m_CS_Calibration");
    xmlHttp.open("PUT","/getCirrus",true);
    xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlHttp.onreadystatechange = function() {
      if (requestIsOK(xmlHttp)) 
      {
        var xmlResponse = xmlHttp.responseText;

        Cirrus_request_busy = false; 
        if ((xmlResponse === null) || (xmlResponse !== "GAIN_OK")) 
        {
          changeLed("red", "led_m_CS_Calibration");
          alert("Gain calibration failed. Restart cirrus.")
          return;
        }
        else
          changeLed("green", "led_m_CS_Calibration");
      }
    }
    document.getElementsByName("bStartContinuous")[0].textContent = 'Stop Continuous';
    xmlHttp.send(cirrus_request);
  }
}

// ***************************
// Traitement page mesure
// ***************************

function DoStartConversion() {
  // On pointe sur le tableau mesure
  current_action.action = action_mesure;
  current_action.id = 0;
  
  // Do the first action
  var the_action = current_action.action[0];
  the_action.function(the_action.page, the_action.registre, the_action.params);
}

function bStartMesureClick() {
  if (current_action.status !== "mesure")
  {
    current_action.status = "mesure";
    document.getElementsByName("bStartMesure")[0].textContent = "Stop Mesure";
    DoStartConversion();
  }
  else 
    {
      current_action.status = "none";
      document.getElementsByName("bStartMesure")[0].textContent = "Start Mesure";
    }
}

function bStartSingleClick() {
  current_action.status = "single";
  DoStartConversion();
}

// ***************************
// Traitement page config 0 & 2
// ***************************

function bConfig0Click(tag) {
  current_register = GetPageRegister(PAGE0, 0);
  if (current_register != null) {
  
    switch (tag) {
      case 0: {
        ResponseTag = 2;
        GetRegister(PAGE0, 0);
        break;
      }

      case 1: {
        if (! window.confirm("Mise à jour de Config0 ?")) return;
        let lValue = 0xC02000;
        if (FCS5484)
          lValue = 0x400000;
        let HSB = get_HSB(lValue);
        let MSB = get_MSB(lValue) + document.getElementsByName("cbInt_POL")[0].selectedIndex;
        let LSB = get_LSB(lValue) + (document.getElementsByName("cbOSC")[0].selectedIndex << 2);
        LSB = LSB + (document.getElementsByName("cbI1PGA")[0].selectedIndex << 5);
        if (FCS5480) {
          LSB = LSB + (document.getElementsByName("cbI2PGA")[0].selectedIndex << 7);
          LSB = LSB + (document.getElementsByName("cbIZX")[0].selectedIndex << 1);
        }
        if (FCS5484) {
          HSB = HSB + (document.getElementsByName("cbTSEL")[0].selectedIndex << 7);
          HSB = HSB + (document.getElementsByName("cbCPUCLK")[0].selectedIndex << 5);
          HSB = HSB + (document.getElementsByName("cbCUCLK")[0].selectedIndex << 4);
          MSB = MSB + (document.getElementsByName("cbV2CAP")[0].selectedIndex << 5);
          LSB = LSB + document.getElementsByName("cbVZX")[0].selectedIndex;
        }
        lValue = set_Int24(LSB, MSB, HSB);
        SetRegister(PAGE0, 0, lValue);
        document.getElementsByName("edConfig0")[0].value = Format_Hex(lValue);
        break;
      }

      case 2: {
        if (! window.confirm("Mise à jour de Config0 ?")) return;
        let lValue = Number(document.getElementsByName("edConfig0")[0].value);
        if (lValue != 0)
        {
          SetRegister(PAGE0, 0, lValue);
        }
        else
          alert("Config 0 non renseigné");
      }
    }
  }
}

function bConfig0ClickResponse(xmlResponse) {
  var lValue = Number(xmlResponse);
  var MSB = get_MSB(lValue);
  var LSB = get_LSB(lValue);
  
  document.getElementsByName("cbInt_POL")[0].selectedIndex = (MSB & 0x01);
  document.getElementsByName("cbI1PGA")[0].selectedIndex = ((LSB & 0x30) >> 5);
  document.getElementsByName("cbI2PGA")[0].selectedIndex = ((LSB & 0xC0) >> 7);
  
  if (FCS5480) {
    document.getElementsByName("cbOSC")[0].selectedIndex = ((LSB & 0x04) >> 2);
    document.getElementsByName("cbIZX")[0].selectedIndex = ((LSB & 0x02) >> 1);
  }
  
  if (FCS5484) {
    document.getElementsByName("cbTSEL")[0].selectedIndex = ((HSB & 0x80) >> 7);
    document.getElementsByName("cbCPUCLK")[0].selectedIndex = ((HSB & 0x20) >> 5);
    document.getElementsByName("cbCUCLK")[0].selectedIndex = ((HSB & 0x10) >> 4);
    document.getElementsByName("cbV2CAP")[0].selectedIndex = ((MSB & 0x60) >> 5);
    document.getElementsByName("cbVZX")[0].selectedIndex = (LSB & 0x01);
  }

  document.getElementsByName("edConfig0")[0].value = xmlResponse;
  ResponseTag = -1;
}

function bConfig2Click(tag) {
  var lValue = 0;
  
  current_register = GetPageRegister(PAGE16, 0);
  if (current_register != null) {
  
    switch (tag) {
      case 0: {
        ResponseTag = 3;
        GetRegister(PAGE16, 0);
        break;
      }
        
      case 1: {
        if (! window.confirm("Mise à jour de Config2 ?")) return;
        if (FCS5480) lValue = 0x000000;
        else
          if (FCS5484) lValue = 0x060000;
          else lValue = 0x100000; // CS5490
        
        let LSB = get_LSB(lValue);
        let MSB = get_MSB(lValue);
        let HSB = get_HSB(lValue);
        
        if (FCS5480 && !FCS5484) {
          HSB = HSB + (document.getElementsByName("cbVFIX")[0].selectedIndex << 7);
          HSB = HSB + (document.getElementsByName("cbICHAN")[0].selectedIndex << 5);
          HSB = HSB + (document.getElementsByName("cbIHOLD")[0].selectedIndex << 4);
          HSB = HSB + (document.getElementsByName("cbIVSP")[0].selectedIndex << 3);
          HSB = HSB + (document.getElementsByName("cbMCFG")[0].selectedIndex << 1);
        }

        HSB = HSB + (document.getElementsByName("cbPOS")[0].selectedIndex << 6);

        MSB = MSB + (document.getElementsByName("cbAPCM")[0].selectedIndex << 6);
        MSB = MSB + (document.getElementsByName("cbZX_LPF")[0].selectedIndex << 4);
        MSB = MSB + (document.getElementsByName("cbAVG_MODE")[0].selectedIndex << 3);
        MSB = MSB + (document.getElementsByName("cbREG_SUM")[0].selectedIndex << 2);
        MSB = MSB + (document.getElementsByName("cbAFC")[0].selectedIndex << 1);

        LSB = LSB + (document.getElementsByName("cbV1Filter")[0].selectedIndex << 1);
        LSB = LSB + (document.getElementsByName("cbI1Filter")[0].selectedIndex << 3);

        if (FCS5480) { // and CS5484
          LSB = LSB + (document.getElementsByName("cbV2Filter")[0].selectedIndex << 5);
          switch (document.getElementsByName("cbI2Filter")[0].selectedIndex) {
            case 0: break;
            case 1: LSB = LSB + 0x80; break;
            case 2: MSB = MSB + 0x01; break;
            case 3: LSB = LSB + 0x80; MSB = MSB + 0x01; break;
          }
        }

        LSB = LSB + document.getElementsByName("cbIIR")[0].selectedIndex;
        
        lValue = set_Int24(LSB, MSB, HSB);
        SetRegister(PAGE16, 0, lValue);
        document.getElementsByName("edConfig2")[0].value = Format_Hex(lValue);        
        break;
      }
        
      case 2: {
        if (! window.confirm("Mise à jour de Config2 ?")) return;
        let lValue = Number(document.getElementsByName("edConfig2")[0].value);
        if (lValue != 0)
        {
          SetRegister(PAGE16, 0, lValue);
        }
        else
          alert("Config 2 non renseigné");       
        break;
      }
    }
  }
}

function bConfig2ClickResponse(xmlResponse) {
  var lValue = Number(xmlResponse);
  var LSB = get_LSB(lValue);
  var MSB = get_MSB(lValue);
  var HSB = get_HSB(lValue);
  
  document.getElementsByName("cbPOS")[0].selectedIndex = ((HSB & 0x40) >> 6);
  if (FCS5480 && !FCS5484) {
    document.getElementsByName("cbVFIX")[0].selectedIndex = ((HSB & 0x80) >> 7);
    document.getElementsByName("cbICHAN")[0].selectedIndex = ((HSB & 0x20) >> 5);
    document.getElementsByName("cbIHOLD")[0].selectedIndex = ((HSB & 0x10) >> 4);
    document.getElementsByName("cbIVSP")[0].selectedIndex = ((HSB & 0x08) >> 3);
    document.getElementsByName("cbMCFG")[0].selectedIndex = ((HSB & 0x06) >> 1);
  }
  document.getElementsByName("cbAPCM")[0].selectedIndex = ((MSB & 0x40) >> 6);
  document.getElementsByName("cbZX_LPF")[0].selectedIndex = ((MSB & 0x10) >> 4);
  document.getElementsByName("cbAVG_MODE")[0].selectedIndex = ((MSB & 0x08) >> 3);
  document.getElementsByName("cbREG_SUM")[0].selectedIndex = ((MSB & 0x04) >> 2);
  document.getElementsByName("cbAFC")[0].selectedIndex = ((MSB & 0x02) >> 1);  
  
  document.getElementsByName("cbV1Filter")[0].selectedIndex = ((LSB & 0x06) >> 1);
  document.getElementsByName("cbI1Filter")[0].selectedIndex = ((LSB & 0x18) >> 3);
  if (FCS5480) {
    document.getElementsByName("cbV2Filter")[0].selectedIndex = ((LSB & 0x60) >> 5);
    let filter = ((MSB << 8) + LSB);
    document.getElementsByName("cbI2Filter")[0].selectedIndex = ((filter & 0x180) >> 7);
  }
  
  document.getElementsByName("cbIIR")[0].selectedIndex = (MSB & 0x01);   
  
  document.getElementsByName("edConfig2")[0].value = xmlResponse;  
  
  ResponseTag = -1;
}

function bConfigCoeffClick() {
  CS_Config = "CS_Config = {";
  CS_Config_log = "";
  
  // On pointe sur le tableau config
  current_action.action = action_config;
  current_action.id = 0;
  current_action.status = "config";
  
  // Do the first action
  var the_action = current_action.action[0];
  the_action.function(the_action.page, the_action.registre, the_action.params);
}

function bFLASH_DATAClick() {
  if (window.confirm("Sauvegarde dans la FLASH. Attention, les anciennes données seront perdues.")) {
    let cirrus_request = "FLASH=";
    xmlHttp.open("PUT","/getCirrus",true);
    xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlHttp.onreadystatechange = null;
    xmlHttp.send(cirrus_request);
  }
}

// ***************************
// Traitement page config 1
// ***************************

function FlashRate() {
  return ((Number(document.getElementsByName("edU1_Calib")[0].value) *
           Number(document.getElementsByName("edI1_MAX")[0].value)) *
          (Number(document.getElementsByName("edFlash")[0].value) / 1000.0) / 3600 / 0.36);
}

function bFlashClick() {
  var FreqFlashRange = [2000, 1000, 500, 250, 125, 62.5, 31.25, 15.625, 7.8125, 3.90625];
  var lRate = FlashRate();
  var mess = "";
  if (lRate == 0) 
    mess = "Frequency = 0 Hz, check U1_Calib and I1_MAX.";
  else
    mess = "Pulse Frequency = " + lRate.toString() + " Hz";
  alert(mess);
  
  var freq = document.getElementsByName("cbPulseFreq")[0];
  freq.selectedIndex = FreqFlashRange.length - 1;
  for (var i = 0; i<FreqFlashRange.length; i++)
  {
    if (FreqFlashRange[i] < lRate) {
      freq.selectedIndex = i - 1;
      return ;
    }
  }
}

function bPulseClick(tag) {
  var lValue = 0x0;

  switch (tag) {
    case 0: ;
    case 1: {  // Pulse width
      current_register = GetPageRegister(PAGE0, 8);
      if (current_register != null) 
      {
        if (tag == 0)
        {
          ResponseTag = 4;
          ResponseTag2 = 0;
          GetRegister(PAGE0, 8);
        }
        else
        {
          lWidthDbl = Number(document.getElementsByName("edPulseWidth")[0].value);
          lWidthDbl = Math.round(lWidthDbl * 64 - 16);
          if (lWidthDbl > 0xFFFF)
          {
            alert("Pulse width too long. Should be < 1024 ms.");
            lValue = 0xFFFF;
          }
          else 
            if (lWidthDbl <= 0)
              lValue = 1;
            else
              lValue = lWidthDbl;

          lValue = lValue + (document.getElementsByName("cbPulseFreq")[0].selectedIndex << 16); // HSB of lValue
          SetRegister(PAGE0, 8, lValue);
          document.getElementsByName("edPulseWidthHEX")[0].value = Format_Hex(lValue); 
        }
      }
      break;
    }

    case 2:
    case 3: { // Pulse rate
      current_register = GetPageRegister(PAGE18, 28);
      if (current_register != null) 
      {
        if (tag == 2)
        {
          ResponseTag = 4;
          ResponseTag2 = 1;
          GetRegister(PAGE18, 28);
        }
        else
        {
          let lRate = FlashRate();
          if (lRate == 0)
          {
            alert("Frequency = 0 Hz, check U1_Calib and I1_MAX.");
            return;
          }

          lRate = (lRate * Math.pow(2, document.getElementsByName("cbPulseFreq")[0].selectedIndex)) / 2000.0;          
          if (lRate >= 1)
          {
            alert("Pulse rate > 1. Frequency is too low.");
            return ;
          }
          document.getElementsByName("edPulseRate")[0].value = lRate.toFixed(6);
          let lReg = FloatRegister(1,PAGE18, 28, 0, lRate);
          document.getElementsByName("edPulseRateHEX")[0].value = Format_Hex(lReg);
        }
      }
      break;
    }

    case 4:
    case 5: {  // Pulse control
      current_register = GetPageRegister(PAGE0, 9);
      if (current_register != null) 
      {
        if (tag == 4)
        {
          ResponseTag = 4;
          ResponseTag2 = 2;
          GetRegister(PAGE0, 9);
        }
        else
        {
          let EPG1 = document.getElementsByName("cbEPG1")[0];
          let EPG2 = document.getElementsByName("cbEPG2")[0];
          let EPG3 = document.getElementsByName("cbEPG3")[0];
          if ((EPG1.options[EPG1.selectedIndex].text == "--------") ||
              (EPG2.options[EPG2.selectedIndex].text == "--------") ||
              (EPG3.options[EPG3.selectedIndex].text == "--------"))
          {
            alert("Choix EPG incorrect.");
            return ;
          }

          let LSB = 0;
          let MSB = 0;
          let HSB = 0; 
          if (FCS5480)
          {
            MSB = EPG3.selectedIndex;
            LSB = (EPG2.selectedIndex >> 4) + EPG1.selectedIndex;
          }
          else LSB = EPG1.selectedIndex;
          lValue = set_Int24(LSB, MSB, HSB);
          SetRegister(PAGE0, 9, lValue);
          document.getElementsByName("edPulseControlHEX")[0].value = Format_Hex(lValue);
        }
      }
      break;
    }

    case 6: {
      let pulse1 = document.getElementsByName("edPulseWidthHEX")[0];
      let pulse2 = document.getElementsByName("edPulseRateHEX")[0];
      let pulse3 = document.getElementsByName("edPulseControlHEX")[0];
      if ((pulse1.value.trim() == "") || (pulse2.value.trim() == "") || (pulse3.value.trim() == ""))
         alert("Valeur de pulse non renseignée");
      else
      {
        // On pointe sur le tableau pulse
        current_action.action = action_pulse;
        current_action.id = 0;
        current_action.status = "pulse";

        // Do the first action
        var the_action = current_action.action[0];
        the_action.function(the_action.page, the_action.registre, the_action.params); 
      }
      break;
    }
  }
}

function bPulseClickResponse(xmlResponse) {
  var lValue = Number(xmlResponse);
  var LSB = get_LSB(lValue);
  var MSB = get_MSB(lValue);
  var HSB = get_HSB(lValue);
  
  switch (ResponseTag2) {
    case 0:
      document.getElementsByName("cbPulseFreq")[0].selectedIndex = HSB & 0x0F;
      let lWidth = lValue & 0xFFFF;
      document.getElementsByName("edPulseWidth")[0].value = (0.250 + lWidth/64).toFixed(4);
      document.getElementsByName("edPulseWidthHEX")[0].value = xmlResponse;
      break;
      
    case 1:
      document.getElementsByName("edPulseRate")[0].value = convertToFloat(xmlResponse, false, 6);
      document.getElementsByName("edPulseRateHEX")[0].value = xmlResponse;
      break;
      
    case 2:
      document.getElementsByName("cbEPG1")[0].selectedIndex = LSB & 0x0F;
      document.getElementsByName("cbEPG2")[0].selectedIndex = (LSB & 0xF0) >> 4;
      document.getElementsByName("cbEPG3")[0].selectedIndex = MSB & 0x0F;
      document.getElementsByName("edPulseControlHEX")[0].value = xmlResponse;
      break;      
  }
  ResponseTag = -1;
}

function bConfig1Click(tag) {
  var lValue = 0x0;

  current_register = GetPageRegister(PAGE0, 1);
  if (current_register != null) 
  {
    switch (tag) {
      case 0: {
        ResponseTag = 5;
        GetRegister(PAGE0, 1);
        break;
      }

      case 1: {
        if (! window.confirm("Mise à jour de Config1 ?")) return;
        let Do1 = document.getElementsByName("cbDo1_MODE")[0];
        let Do2 = document.getElementsByName("cbDo2_MODE")[0];
        let Do3 = document.getElementsByName("cbDo3_MODE")[0];
        if ((Do1.options[Do1.selectedIndex].text == "--------") ||
            (Do2.options[Do2.selectedIndex].text == "--------") ||
            (Do3.options[Do3.selectedIndex].text == "--------"))
        {
          alert("Choix DO MODE incorrect.");
          return ;
        }

        let lByte = document.getElementsByName("cbEPG3_Block")[0].selectedIndex;
        lByte = (lByte << 1) + document.getElementsByName("cbEPG2_Block")[0].selectedIndex;
        lByte = (lByte << 1) + document.getElementsByName("cbEPG1_Block")[0].selectedIndex;
        lByte = (lByte << 2) + document.getElementsByName("cbDo3_DO")[0].selectedIndex;
        lByte = (lByte << 1) + document.getElementsByName("cbDo2_DO")[0].selectedIndex;
        lByte = (lByte << 1) + document.getElementsByName("cbDo1_DO")[0].selectedIndex;
        let HSB = lByte;
        let MSB = 0xEE;
        let LSB = 0xEE;
//        lValue = set_Int24(LSB, MSB, HSB);
//        SetRegister(PAGE0, 1, lValue);
//        Sleep(100);  // Attendre 0.1 s

        if (FCS5480) 
        {
          MSB = 0xE0 + Do3.selectedIndex;
          LSB = (Do2.selectedIndex << 4) + Do1.selectedIndex;
        }
        else
        {
          MSB = 0xEE;
          LSB = 0xE0 + Do1.selectedIndex;
        }
        lValue = set_Int24(LSB, MSB, HSB);
        SetRegister(PAGE0, 1, lValue);
        document.getElementsByName("edConfig1")[0].value = Format_Hex(lValue);
        break;
      }

      case 2: {
        if (! window.confirm("Mise à jour de Config1 ?")) return;
        let lValue = Number(document.getElementsByName("edConfig1")[0].value);
        if (lValue != 0)
        {
          SetRegister(PAGE0, 1, lValue);
        }
        else
          alert("Config 1 non renseigné");       
        break;
      }
    }
  }
}

function bConfig1ClickResponse(xmlResponse) {
  var lValue = Number(xmlResponse);
  var LSB = get_LSB(lValue);
  var MSB = get_MSB(lValue);
  var HSB = get_HSB(lValue);
  
  document.getElementsByName("cbEPG1_Block")[0].selectedIndex = ((HSB & 0x10) == 0x10);
  document.getElementsByName("cbEPG2_Block")[0].selectedIndex = ((HSB & 0x20) == 0x20);
  document.getElementsByName("cbEPG3_Block")[0].selectedIndex = ((HSB & 0x40) == 0x40);
  
  document.getElementsByName("cbDo1_DO")[0].selectedIndex = ((HSB & 0x01) == 0x01);
  document.getElementsByName("cbDo2_DO")[0].selectedIndex = ((HSB & 0x02) == 0x02);
  document.getElementsByName("cbDo3_DO")[0].selectedIndex = ((HSB & 0x04) == 0x04);
  
  document.getElementsByName("cbDo1_MODE")[0].selectedIndex = LSB & 0x0F;
  document.getElementsByName("cbDo2_MODE")[0].selectedIndex = (LSB & 0xF0) >> 4;
  document.getElementsByName("cbDo3_MODE")[0].selectedIndex = MSB & 0x0F;
    
  document.getElementsByName("edConfig1")[0].value = xmlResponse;
  ResponseTag = -1;
}

// ***************************
// Traitement Lock et select cirrus
// ***************************

function toggleIHM() {
  var sw = document.getElementById("Toggle_IHM");
  var cirrus_request;
  if (sw.checked) {
    cirrus_request = "LOCK=1";
  }
  else {
    cirrus_request = "LOCK=0";
  }  
  xmlHttp.open("PUT","/getCirrus",true);
  xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xmlHttp.onreadystatechange = null;
  xmlHttp.send(cirrus_request);
}

function toggleCirrus() {
  var sw = document.getElementById("Toggle_CS");
  var cirrus_request;
  if (sw.checked) {
    cirrus_request = "CS=1";
  }
  else {
    cirrus_request = "CS=2";
  }   
  xmlHttp.open("PUT","/getCirrus",true);
  xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xmlHttp.onreadystatechange = null;
  xmlHttp.send(cirrus_request);
}
