"use strict";

//let data_graphe = [[1729900817, 368.06, 6.03, 227.43, 32.11, 26.00, 0.00, 368.06, 6.03, 227.43],
//[1729900937, 364.80, 5.94, 225.69, 32.10, 26.00, 0.00, 364.80, 5.94, 225.69],
//[1729901057, 361.80, 5.84, 223.91, 32.09, 26.00, 0.00, 361.80, 5.84, 223.91],
//[1729901178, 362.94, 5.88, 224.58, 32.08, 26.00, 0.00, 362.94, 5.88, 224.58],
//[1729901299, 434.80, 5.94, 226.76, 32.08, 26.00, 0.00, 434.80, 5.94, 226.76],
//[1729901419, 452.63, 5.90, 226.35, 32.07, 26.00, 0.00, 452.63, 5.90, 226.35],
//[1729901540, 452.04, 6.00, 228.24, 32.06, 25.88, 0.00, 452.04, 6.00, 228.24],
//[1729901660, 450.15, 5.98, 227.96, 32.06, 25.88, 0.00, 450.15, 5.98, 227.96],
//[1729901780, 447.77, 5.95, 227.22, 32.06, 25.88, 0.00, 447.77, 5.95, 227.22],
//[1729901901, 450.86, 6.07, 229.54, 32.06, 25.88, 0.00, 450.86, 6.07, 229.54],
//[1729902021, 448.39, 6.02, 228.44, 32.05, 26.00, 0.00, 448.39, 6.02, 228.44],
//[1729902142, 442.39, 5.87, 225.72, 32.04, 26.00, 0.00, 442.39, 5.87, 225.72],
//[1729902262, 443.50, 5.92, 226.65, 32.03, 26.00, 0.00, 443.50, 5.92, 226.65],
//[1729902383, 434.58, 6.12, 230.08, 32.03, 26.00, 0.00, 434.58, 6.12, 230.08],
//[1729902504, 353.07, 6.31, 232.27, 32.03, 26.00, 0.00, 353.07, 6.31, 232.27],
//[1729902624, 327.97, 6.32, 232.00, 32.03, 26.00, 0.00, 327.97, 6.32, 232.00],
//[1729902745, 326.20, 6.28, 231.08, 32.03, 26.00, 0.00, 326.20, 6.28, 231.08],
//[1729902865, 326.66, 6.30, 231.35, 32.03, 26.00, 0.00, 326.66, 6.30, 231.35],
//[1729902985, 324.17, 6.22, 229.90, 32.03, 25.88, 0.00, 324.17, 6.22, 229.90],
//[1729903106, 325.95, 6.25, 230.82, 32.03, 26.00, 0.00, 325.95, 6.25, 230.82],
//[1729903226, 326.78, 6.27, 231.26, 32.03, 26.00, 0.00, 326.78, 6.27, 231.26],
//[1729903347, 322.40, 6.16, 229.14, 32.03, 25.88, 0.00, 322.40, 6.16, 229.14],
//[1729903467, 322.25, 6.16, 229.15, 32.02, 25.88, 0.00, 322.25, 6.16, 229.15],
//[1729903588, 327.97, 6.34, 232.56, 32.03, 25.88, 0.00, 327.97, 6.34, 232.56],
//[1729903708, 322.59, 6.23, 230.43, 32.01, 25.88, 0.00, 322.59, 6.23, 230.43]];

// Graphe variables
var power_line, temperature_line, energy_line;
var energy_bar;
var BarGraph_Power, BarGraph_Energy;
var LineGraph_Power, LineGraph_Temperature, LineGraph_Energy;

var power_line_length, temperature_line_length, energy_line_length;
var data_length;

// le id de la série P théorique
var theoric_line_id = 3;

// Time array
var data_date_formated = new Array();

// Energy
var energy_bar_source = ['conso', 'surplus', 'prod', 'talema'];
var energy_count = energy_bar_source.length; // Number of energy graph
var energy_array = [];
var energy_max = [];

var energy_request = false; // Update energie bar
var energy_data = false; // Les données sont disponibles
var energy_month = ''; // Le mois affiché
var energy_year = ''; // L'année affichée

// Name of months
const month_str = new Array(
  'Janvier',
  'Février',
  'Mars',
  'Avril',
  'Mai',
  'Juin',
  'Juillet',
  'Août',
  'Septembre',
  'Octobre',
  'Novembre',
  'Décembre'
);

// For when resize the window
var CurrentPageName;

// To get chart from div that contain canvas. For undo zoom, export, tooltip
var divIdToChart = {};

// ***************************
// Time functions
// ***************************

function newDate(new_time) {
  return ((new_time - 3600) * 1000);
}

// ***************************
// IHM functions
// ***************************

// ***************************
// Export function
// ***************************

/**
* Convert graphe data to csv
* args class params :
* data: the data property of the chart class (Chart.data)
* label: the label text of labels of the chart class
* columnDelimiter: the column delimiter character (default \t)
* lineDelimiter: the line delimiter character (default \r\n)
*/
function convertChartDataToCSV(args) {
  let result, columnDelimiter, lineDelimiter, labels, datas;

  datas = args.data.datasets || null;
  if (datas == null || !datas.length) {
    return null;
  }

  labels = args.data.labels || null;
  if (labels == null || !labels.length) {
    return null;
  }

  columnDelimiter = args.columnDelimiter || '\t';
  lineDelimiter = args.lineDelimiter || '\r\n';

  result = '';

  // Title of the columns
  result += args.label;
  result += columnDelimiter;
  for (var j = 0; j < datas.length; j++) {
    result += datas[j].label;
    result += columnDelimiter;
  }
  result += lineDelimiter;

  // We suppose that every datasets have the same length of labels
  for (var i = 0; i < labels.length; i++) {
    // Convert unix datetime to human readable date
    let dateObject = new Date(labels[i]);
    result += dateObject.toLocaleString();
    result += columnDelimiter;
    for (var j = 0; j < datas.length; j++) {
      if (datas[j].data[i] !== undefined)
        result += (datas[j].data[i]).toString().replace(".", ",");
      else
        result += '';
      result += columnDelimiter;
    }
    result += lineDelimiter;
  }

  return result;
}

function exportCSV(can_plot) {
  if (can_plot === undefined)
    can_plot = currentChart.id;
  const theChart = divIdToChart[can_plot];
  let data_csv = convertChartDataToCSV({
      data: theChart.data,
      label: 'Date'
  });

  if (data_csv == null) return;
//  console.log(data_csv);

  var blob = new Blob([data_csv],
          { type: "text/plain; charset=utf-8" });

  // Save the file with FileSaver.js
  saveAs(blob, currentChart.chartName + ".csv");
}

// Export graphic to PNG
function exportPNG(chart, name) {
  const imageLink = document.createElement('a');
  if (chart === undefined) {
    var canvas = divIdToChart[currentChart.id].canvas;
    name = currentChart.chartName;
  }
  else {
    var canvas = document.getElementById(chart);
  }

  imageLink.download = name + ".png";
  imageLink.href = canvas.toDataURL("image/png", 1);
  imageLink.click();
}

// ***************************
// Power, voltage, temp graphe function
// ***************************

function doClearGraphe() {
  // date
  data_date_formated.length = 0;
  // Power, Voltage
  for (var i = 0; i < power_line_length; i++) {
    power_line.data.datasets[i].data.length = 0;
  }
  // Temperature
  for (var i = 0; i < temperature_line_length; i++) {
    temperature_line.data.datasets[i].data.length = 0;
  }
  // Energy
  for (var i = 0; i < energy_line_length; i++) {
    energy_line.data.datasets[i].data.length = 0;
  }
}

// Refresh the graphe for a specific date
function refreshGraph() {
    doClearGraphe();
    if (document.getElementsByName("cbdateGraph")[0].checked)
    {
      let d = document.getElementById("dtPicker").value;
      d = "/" + d.substr(2) + ".csv";
      ESP_Request("Update_CSV", [d, 'data']);
    }
    else
      ESP_Request("Update_CSV", ["/data.csv", 'data']);
}

function do_updateGraph(data) {
  var i = 0;
  // Date
  data_date_formated.push(newDate(data[i]));
  i++;
  // Order is Power, voltage, temperature, Energy
  // Power, voltage
  for (let j = 0; j < power_line_length; j++) {
    power_line.data.datasets[j].data.push(data[i++]);
  }
  // Temperature
  for (let j = 0; j < temperature_line_length; j++) {
    temperature_line.data.datasets[j].data.push(data[i++]);
  }
  // Energy
  for (let j = 0; j < energy_line_length; j++) {
    energy_line.data.datasets[j].data.push(data[i++]);
  }
}

function updateGraph(data, append) {
  if (append) {
    do_updateGraph(data);
  }
  else {
    doClearGraphe();
    for (let j = 0; j < data.length; j++) {
      do_updateGraph(data[j]);
    }
  }
  LineGraph_Power.update();
  LineGraph_Temperature.update();
  LineGraph_Energy.update();
  if (!append)
  {
    LineGraph_Power.resetZoom();
    LineGraph_Temperature.resetZoom();
    LineGraph_Energy.resetZoom();
  }
}

// ***************************
// Energy function
// ***************************

function update_energy(raw_data) {
  // Format data received
  if (typeof raw_data != 'undefined')
  {
    var year = energy_year;
    energy_array[year] = new Array('01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12');
    energy_max[year] = new Array(12);

    var first_mois = '';
    var lines = raw_data.split("\r\n");
    // Skip first line of title
    for (var i = 1; i < lines.length; i++) {
      if (lines[i] != "")
      {
        var values = lines[i].split('\t');

        // Le premier est la date au format dd/mm
        var mm = values[0].substring(3);
        var m = parseInt(mm) - 1;
        var jj = parseInt(values[0].substring(0,2)) - 1;

        // On crée un tableau de 31 jours pour le mois
        if (mm !== first_mois)
        {
          energy_array[year][mm] = new Array(31);
          energy_max[year][m] = new Array(energy_count).fill(0.0); // [0.0, 0.0, 0.0];
          first_mois = mm;
        }
        // Nouveau tableau pour ce jour
        energy_array[year][mm][jj] = new Array();
        for (var j=1; j<energy_count+1; j++)
        {
          if (j < values.length)
          {
            energy_array[year][mm][jj].push(parseFloat(values[j]));
            energy_max[year][m][j-1] += parseFloat(values[j]);
          }
          else
            energy_array[year][mm][jj].push(0);
        }
      }
    }
  }

  // Update graphe
  var parray;
  var e_kwh;
  // First, empty the existing data
  energy_bar.data.labels.length = 0;
  for (var i=0; i<energy_bar.data.datasets.length; i++)
    energy_bar.data.datasets[i].data.length = 0;

  if (energy_month == 'all')
  {
    parray = energy_max[energy_year];
    for (var j=0; j<12; j++)
    {
      if (Array.isArray(parray[j]))
      {
        energy_bar.data.labels.push(month_str[j]);
        for (var k=0; k<parray[j].length; k++)
        {
          e_kwh = Math.round(parray[j][k]/10)/100.0;
          energy_bar.data.datasets[k].data.push(e_kwh);
        }
      }
    }
    energy_bar.options.scales.x.title.text = 'Mois';
    energy_bar.options.scales.y.title.text = 'kWh';
  }
  else
  {
    parray = energy_array[energy_year][energy_month];

    if (typeof parray != 'undefined') {
      // On parcourt les jours du mois
      for (var j=0; j<31; j++)
      {
        // Si on a des données pour ce jour
        if (Array.isArray(parray[j]))
        {
          energy_bar.data.labels.push(j+1);
          for (var k=0; k<parray[j].length; k++)
          {
            energy_bar.data.datasets[k].data.push(parray[j][k]);
          }
        }
      }
    }
    else alert("Pas de données pour ce mois");
    energy_bar.options.scales.x.title.text = 'Jour';
    energy_bar.options.scales.y.title.text = 'Wh';
  }

  BarGraph_Energy.update();
  BarGraph_Energy.resetZoom();
}

// Determine the month and year requested
function getEnergy() {
  var select = document.getElementById('mois');
  var id = select.selectedIndex;
  var month = select.options[id].value;

  select = document.getElementById('annee');
  id = select.selectedIndex;
  var year = select.options[id].value;

  if (typeof energy_array[year] == 'undefined')
  {
    energy_month = month;
    energy_year = year;
    // Flag to request the data of the year in the process() function
    energy_request = true;
  }
  else
  {
    if ((month !== energy_month) || (year !== energy_year))
    {
      energy_month = month;
      energy_year = year;
      update_energy();
    }
  }
}

// ***************************
// Parse CSV function
// ***************************

// Parse un fichier csv et renvoie un tableau de nb_var tableaux [[], ..., []]
function parseCSV(raw_string, nb_var) {
  var lines = raw_string.split("\r\n");
  var array = new Array(lines.length);

  var k = 0;
  for (var i = 0; i < lines.length; i++) {
    if (lines[i] != "")
    {
      array[k] = new Array(nb_var);
      var data = lines[i].split("\t");

      // For old data (P and E Talema missing)
      if (nb_var != data.length + 1)
      {
        data.splice(3, 0, '0'); // P at index 3
        data.push('0'); // E at the end
      }

      // Add P theoric
      data.splice(4, 0, '0'); // P th at index 4
      var data_size = data.length; // Normalement = nb_var

      for (let j = 0; j < nb_var; j++) {
        if (j < data_size)
          array[k][j] = parseFloat(data[j]);
        else
          array[k][j] = 0;
      }

      k++;
    }
  }
  // Suppress empty lines
  if (k != lines.length)
    array.length = k;
  return array;
}

function parseCSVandUpdateGraph(raw_string, nb_var) {
  doClearGraphe();
  var lines = raw_string.split("\r\n");

  for (var i = 0; i < lines.length; i++) {
    if (lines[i] != "")
    {
      let array = new Array(nb_var);
      let data = lines[i].split("\t");

      // For old data (P and E Talema missing)
      if (nb_var != data.length + 1)
      {
        data.splice(3, 0, '0'); // P at index 3
        data.push('0'); // E at the end
      }

      // Add P theoric
      data.splice(4, 0, '0'); // P th at index 4
      let data_size = data.length; // Normalement = nb_var

      for (let j = 0; j < nb_var; j++) {
        if (j < data_size)
          array[j] = parseFloat(data[j]);
        else
          array[j] = 0;
      }

      do_updateGraph(array);
    }
  }
  LineGraph_Power.update();
  LineGraph_Temperature.update();
  LineGraph_Energy.update();
  LineGraph_Power.resetZoom();
  LineGraph_Temperature.resetZoom();
  LineGraph_Energy.resetZoom();
}

function fillTheoricGraph(raw_string) {
  power_line.data.datasets[theoric_line_id].data.length = 0;

  let data = raw_string.split("\t");
  for (let j = 0; j < data.length; j++) {
    power_line.data.datasets[theoric_line_id].data.push(parseFloat(data[j]));
  }
  LineGraph_Power.update();
}

function getTheoricRange() {
  let size = power_line.data.datasets[theoric_line_id].data.length;
  let dt = data_date_formated[size-1];
  let date = new Date(dt);
  let dt_minute = date.getHours() * 60 + date.getMinutes();
  return [size, dt_minute];
}

// ***************************
// Plot create functions
// https://www.chartjs.org/docs/latest/
// ***************************

const timeFormat = 'HH:mm';  // "HH:mm"; DD T
const dateFormat = 'DD MM YYYY HH:mm:ss';

const dragOptions = {
    borderColor: 'rgba(225,225,225,0.3)',
    borderWidth: 5,
    backgroundColor: 'rgb(225,225,225)',
    animationDuration: 500
};

// List of scales
const axisID = {y: "W", y1: "V", y2: "°C", y3: "Wh"};
const power_line_scale = {
  x: {
    type: 'time',
    time: {
      tooltipFormat: timeFormat,
      displayFormats: {
        minute: timeFormat,
      },
      round: 'minute',
      unit: 'minute'
    },
    title: {
      display: true,
      text: 'Heure'
    }
  },
  y: { // Power axis
      type: 'linear',
      position: 'left',
      title: {
        display: true,
        text: 'W'
      },
      grid: {
        display: true,
        color: '#888'
      }
  },
  y1: { // Voltage axis
      type: 'linear',
      position: 'right',
      title: {
        display: true,
        text: 'V'
      },
      grid: {
        display: false,
      }
  },
};

const temperature_line_scale = {
  x: {
    type: 'time',
    time: {
      tooltipFormat: timeFormat,
      displayFormats: {
        minute: timeFormat,
      },
      round: 'minute',
      unit: 'minute'
    },
    title: {
      display: true,
      text: 'Heure'
    }
  },
  y2: { // Temp axis
      type: 'linear',
      position: 'left',
      title: {
        display: true,
        text: '°C'
      },
      grid: {
        display: true,
        color: '#ddd'
      }
  },
};

const energy_line_scale = {
  x: {
    type: 'time',
    time: {
      tooltipFormat: timeFormat,
      displayFormats: {
        minute: timeFormat,
      },
      round: 'minute',
      unit: 'minute'
    },
    title: {
      display: true,
      text: 'Heure'
    }
  },
  y3: {
      type: 'linear',
      position: 'left',
      title: {
        display: true,
        text: 'Wh'
      }
    }
};

const zoomOptions = {
//  limits: {
//    x: {min: -200, max: 200, minRange: 50},
//    y: {min: -200, max: 200, minRange: 50}
//  },
  pan: {
    enabled: true,
    mode: 'x',
  },
  zoom: {
    wheel: {
      enabled: true,
    },
    drag: {
      enabled: true
    },
    pinch: {
      enabled: true
    },
    mode: 'x',
    onZoomComplete({chart}) {
      // This update is needed to display up to date zoom level in the title.
      // Without this, previous zoom level is displayed.
      // The reason is: title uses the same beforeUpdate hook, and is evaluated before zoom.
      chart.update('none');
    }
  }
};

// For background
const plugin = {
  id: 'customCanvasBackgroundColor',
  beforeDraw: (chart, args, options) => {
    const {ctx} = chart;
    ctx.save();
    ctx.globalCompositeOperation = 'destination-over';
    ctx.fillStyle = options.color || '#ffffff';
    ctx.fillRect(0, 0, chart.width, chart.height);
    ctx.restore();
  }
};

// ***************************
// Data Plot line functions
// ***************************

const chartColors = {
  red: 'rgb(255, 0, 0)',
  pink: 'rgb(255, 99, 132)',
  orange: 'rgb(255, 159, 64)',
  yellow: 'rgb(255, 205, 86)',
  green: 'rgb(0, 255, 0)',
  lightgreen: 'rgb(75, 192, 192)',
  blue: 'rgb(0, 0, 255)',
  lightblue: 'rgb(54, 162, 235)',
  purple: 'rgb(153, 102, 255)',
  grey: 'rgb(201, 203, 207)'
};

const chartColors_alpha = {
  red: 'rgba(255, 0, 0, 0.2)',
  pink: 'rgba(255, 99, 132, 0.2)',
  orange: 'rgba(255, 159, 64, 0.2)',
  yellow: 'rgba(255, 205, 86, 0.2)',
  green: 'rgba(0, 255, 0, 0.2)',
  lightgreen: 'rgba(75, 192, 192, 0.2)',
  blue: 'rgba(0, 0, 255, 0.2)',
  lightblue: 'rgba(54, 162, 235, 0.2)',
  purple: 'rgba(153, 102, 255, 0.2)',
  grey: 'rgba(201, 203, 207, 0.2)'
};

const data_line_power = [
    {
      label: 'P Conso',
      backgroundColor: chartColors_alpha.blue,
      borderColor: chartColors.blue,
      fill: true,
      data: new Array(),
      borderWidth: 1,
      yAxisID: 'y', // power-axis
      pointRadius: 2
    }, {
      label: 'P Prod',
      backgroundColor: chartColors_alpha.orange,
      borderColor: chartColors.orange,
      fill: true,
      data: new Array(),
      borderWidth: 1,
      yAxisID: 'y',
      pointRadius: 2
    }, {
      label: 'P Talema',
      backgroundColor: chartColors_alpha.green,
      borderColor: chartColors.green,
      fill: true,
      data: new Array(),
      borderWidth: 1,
      yAxisID: 'y',
      pointRadius: 2
    }, {
      label: 'P Théorique',
      backgroundColor: chartColors_alpha.red,
      borderColor: chartColors.red,
      fill: true,
      data: new Array(),
      borderWidth: 1,
      yAxisID: 'y',
      pointRadius: 2
    }, {
      label: 'Tension',
      backgroundColor: chartColors.yellow,
      borderColor: chartColors.yellow,
      fill: false,
      data: new Array(),
      borderWidth: 2,
      yAxisID: 'y1', // voltage-axis
      pointRadius: 2
    }
];

const data_line_temperature = [
  {
      label: 'Temp Cirrus',
      backgroundColor: chartColors.red,
      borderColor: chartColors.red,
      fill: false,
      data: new Array(),
      borderWidth: 2,
      yAxisID: 'y2', // temp-axis
      pointRadius: 2
    }, {
      label: 'Temp interne',
      backgroundColor: chartColors.green,
      borderColor: chartColors.green,
      fill: false,
      data: new Array(),
      borderWidth: 2,
      yAxisID: 'y2',
      pointRadius: 2
    }, {
      label: 'Temp externe',
      backgroundColor: chartColors.blue,
      borderColor: chartColors.blue,
      fill: false,
      data: new Array(),
      borderWidth: 2,
      yAxisID: 'y2',
      pointRadius: 2
    }
];

const data_line_energy = [
    {
      label: 'E Conso',
      backgroundColor: chartColors.blue,
      borderColor: chartColors.blue,
      fill: false,
      data: new Array(),
      borderWidth: 2,
      yAxisID: 'y3', // energy-axis
      pointRadius: 0
    }, {
      label: 'E Surplus',
      backgroundColor: chartColors.red,
      borderColor: chartColors.red,
      fill: false,
      data: new Array(),
      borderWidth: 2,
      yAxisID: 'y3', // energy-axis
      pointRadius: 0
    }, {
      label: 'E Prod',
      backgroundColor: chartColors.orange,
      borderColor: chartColors.orange,
      fill: false,
      data: new Array(),
      borderWidth: 2,
      yAxisID: 'y3', // energy-axis
      pointRadius: 0
    }, {
      label: 'E Talema',
      backgroundColor: chartColors.green,
      borderColor: chartColors.green,
      fill: false,
      data: new Array(),
      borderWidth: 2,
      yAxisID: 'y3', // energy-axis
      pointRadius: 0
    }
];

const data_bar_energy = {
  labels: ['1'],
  datasets: [{
      label: 'E Conso',
      borderWidth: 2,
      backgroundColor: chartColors_alpha.blue,
      borderColor: chartColors.blue,
      data: [1]
  }, {
      label: 'E Surplus',
      borderWidth: 2,
      backgroundColor: chartColors_alpha.red,
      borderColor: chartColors.red,
      data: [1]
  }, {
      label: 'E Prod',
      borderWidth: 2,
      backgroundColor: chartColors_alpha.orange,
      borderColor: chartColors.orange,
      data: [1]
  }, {
      label: 'E Talema',
      borderWidth: 2,
      backgroundColor: chartColors_alpha.green,
      borderColor: chartColors.green,
      data: [1]
  }]
};

const onTooltipButtonClick = (evt) => {
  const interaction_mode = ['index', 'nearest', 'x', 'point']; //, 'dataset'
//  chart.options.plugins.tooltip.enabled = !chart.options.plugins.tooltip.enabled;

  if (evt === undefined) {
    var chart = divIdToChart[currentChart.id];
  }
  else {
    var chart = divIdToChart[evt.currentTarget.id.substring(3)];
  }

  let mode = chart.options.interaction.mode;
  let id = interaction_mode.indexOf(mode);
  if (id != interaction_mode.length - 1)
    id += 1;
  else
    id = 0;
  chart.options.interaction.mode = interaction_mode[id];
  chart.update();
}

const onResizeTooltipButton = (context) => {
  // Give an id to the button build with the id of the chart canvas
  let id_Btn = 'id_' + context.ctx.canvas.id;
  let tooltipButton = document.getElementById(id_Btn);
  if (!tooltipButton) {
    tooltipButton = document.createElement('BUTTON');
    const buttonText = document.createTextNode('T');
    tooltipButton.id = id_Btn;
    tooltipButton.classList.add('myButton');
    tooltipButton.title = "Change le mode d'affichage du tooltip";
    tooltipButton.style.position = 'relative';
    tooltipButton.appendChild(buttonText);
    context.canvas.parentNode.appendChild(tooltipButton);
    tooltipButton.addEventListener('click', (e) => {
      onTooltipButtonClick(e);
    });
  };
  const xPos = (context.width - 40) / -2;
  const yPos = (context.height - 20) * -1;
  tooltipButton.style.left = xPos + 'px';
  tooltipButton.style.top = yPos + 'px';
}

function create_Line(data_label, data_line, opt_title, opt_scale) {
  return [{
    type: 'line',
    data: {
      // data_label.slice() si on veut individualiser les dates
      labels: data_label,
      datasets: data_line
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      normalized: true,
      animation: false,

      parsing: {
        parsing: false,
      },

      plugins: {
        zoom: zoomOptions,
        title: {
          display: true,
          text: opt_title
        },
        legend: {
          position: 'top'
        },
        tooltip: {
          titleColor: '#000',
          bodyColor: '#000',
          backgroundColor: 'rgba(255, 249, 196, 0.92)',
          borderColor: 'rgb(0, 0, 255)',
          borderWidth: 1,
          position: 'nearest',
          callbacks: {
            afterTitle: function(context) {
              return "-----------";
            },
            label: function(context) {
              // console.log(context);
              let scaleID = context.dataset.yAxisID;
              return '  ' + context.dataset.label + ': ' + context.raw + ' ' + axisID[scaleID];
            }
          }
        },
        customCanvasBackgroundColor: {
          color: 'white',
        },
      },
      interaction: {
 //       axis: 'x',
        mode: 'index',  // index nearest  point dataset x
        intersect: false
      },
      scales: opt_scale,

//      onResize: onResizeTooltipButton,
    },
    plugins: [plugin],
  },
  data_line.length];
}

function create_Bar_Energy(data_bar, opt_title, opt_unit) {
  return {
    type: 'bar',
    data: data_bar,
    options: {
      elements: {
        rectangle: {
          borderWidth: 2
        }
      },
      responsive: true,
      maintainAspectRatio: false,
      normalized: true,
      animation: true,

      plugins: {
        zoom: zoomOptions,
        title: {
          display: true,
          text: opt_title
        },
        legend: {
          display: true,
          position: 'top'
        },
        tooltip: {
          titleColor: '#000',
          bodyColor: '#000',
          backgroundColor: 'rgba(255, 249, 196, 0.92)',
          borderColor: 'rgb(0, 0, 255)',
          borderWidth: 1,
          position: 'nearest',
          callbacks: {
            label: function(context) {
              // console.log(context);
              if (energy_month == 'all')
                return '  ' + context.dataset.label + ': ' + context.raw + ' kWh';
              else
                return '  ' + context.dataset.label + ': ' + Math.round(context.raw/10)/100.0 + ' kWh';
            }
          }
        },
        customCanvasBackgroundColor: {
          color: 'white',
        },
      },
      interaction: {
 //       axis: 'x',
        mode: 'index',  // index nearest  point dataset x
        intersect: false
      },
      scales: {
        x: {
          display: true,
          title: {
            display: true,
            text: opt_unit
          },
          ticks: {
            min: 0
          }
        },
        y: {
          display: true,
          title: {
            display: true,
            text: 'Wh'
          },
          ticks: {
            min: 0
          }
        }
      },

//      onResize: onResizeTooltipButton,
    },
    plugins: [plugin],
  };
}

// ***************************
// Splitter, resize gestion
// ***************************
// From Barguast in https://stackoverflow.com/questions/12194469/best-way-to-do-a-split-pane-in-html
function manageResize(event, sizeProp, posProp) {
  var r = event.target;

  var prev = r.previousElementSibling;
  var next = r.nextElementSibling;
  if (!prev || !next) {
    return;
  }

  // Used to avoid cursor's flickering
  const html = document.querySelector('html');

  if (posProp === 'pageX') {
    r.style.cursor = 'col-resize';
    html.style.cursor = 'col-resize';
  } else {
    r.style.cursor = 'row-resize';
    html.style.cursor = 'row-resize';
  }

  event.preventDefault();

  var prevSize = prev[sizeProp];
  var nextSize = next[sizeProp];
  var sumSize = prevSize + nextSize;
  var prevGrow = Number(prev.style.flexGrow);
  var nextGrow = Number(next.style.flexGrow);
  var sumGrow = prevGrow + nextGrow;
  var lastPos = event[posProp];

  function onMouseMove(mm_event) {
    var pos = mm_event[posProp];
    var d = pos - lastPos;
    prevSize += d;
    nextSize -= d;
    if (prevSize < 0) {
      nextSize += prevSize;
      pos -= prevSize;
      prevSize = 0;
    }
    if (nextSize < 0) {
      prevSize += nextSize;
      pos += nextSize;
      nextSize = 0;
    }

    var prevGrowNew = sumGrow * (prevSize / sumSize);
    var nextGrowNew = sumGrow * (nextSize / sumSize);

    prev.style.flexGrow = prevGrowNew;
    next.style.flexGrow = nextGrowNew;

    lastPos = pos;

    // If we want to do something special
    if (typeof onFlexCallback === 'function') {
      onFlexCallback(posProp, prev, next);
    }
  }

  function onMouseUp(mu_event) {
    // Change cursor to signal a state's change: stop resizing.
    html.style.cursor = 'default';

    if (posProp === 'pageX') {
      r.style.cursor = 'ew-resize';
    } else {
      r.style.cursor = 'ns-resize';
    }

    window.removeEventListener("mousemove", onMouseMove);
    window.removeEventListener("mouseup", onMouseUp);
  }

  window.addEventListener("mousemove", onMouseMove);
  window.addEventListener("mouseup", onMouseUp);
}

function setupResizerEvents() {
  document.body.addEventListener("mousedown", function (event) {

    let target = event.target;
    if (target.nodeType !== 1 || target.tagName !== "FLEX-RESIZER") {
      return;
    }

    let parent = target.parentNode;
    let h = parent.classList.contains("h");
    let v = parent.classList.contains("v");
    if (h && v) {
      return;
    } else if (h) {
      // use offsetWidth versus scrollWidth (and clientWidth) to avoid splitter's jump on resize when a flex-item content overflow (overflow: auto).
      manageResize(event, "offsetWidth", "pageX");

    } else if (v) {
      manageResize(event, "offsetHeight", "pageY");
    };
  });
}

function getSize() {
  return {
    "width": window.innerWidth,
    "height": window.innerHeight
  };
}

function onFlexCallback(direction, prev, next) {
  let divCanvas = prev.firstElementChild;
  divCanvas.style.height = '' + prev.offsetHeight + 'px';

  divCanvas = next.firstElementChild;
  divCanvas.style.height = '' + next.offsetHeight + 'px';
}

function setGrapheHeight(PageName) {

  function setDivGrapheHeight(wh, div) {
    let h = wh - div.offsetTop;
    div.style.height = '' + h + 'px';
  }

  if (PageName !== undefined) {
    CurrentPageName = PageName;
  }
  let wh = getSize().height;

  if (CurrentPageName.id === 'm_Graphe') {
    setDivGrapheHeight(wh, document.getElementById('divPower'));
  }
  else
    if (CurrentPageName.id === 'm_Temperature') {
      setDivGrapheHeight(wh, document.getElementById('divTemperature'));
    }
    else
      if (CurrentPageName.id === 'm_Energy') {
        let h = wh - 20;
        setDivGrapheHeight(h, document.getElementById('flex-container'));
        onFlexCallback('', document.getElementById('flex_up'), document.getElementById('flex_down'));
      }
}

// ***************************
// Undo zoom
// ***************************

function undoZoom(can_plot) {
  if (can_plot === undefined)
    can_plot = currentChart.id;
  divIdToChart[can_plot].resetZoom();
}

function ondblClick(evt) {
//  console.log(evt);
  let can = evt.target;
  undoZoom(can.id);
}

// ***************************
// Context menu for the chart
// ***************************

// The chart menu defined in document
const chartMenu = document.getElementById('chartMenu');
// The current chart where we have clicked
// This object is used in selected action
var currentChart;
// Hide the context menu when we click elsewhere on the document
document.onclick = hideChartMenu;

function hideChartMenu() {
  chartMenu.style.display = 'none';
  currentChart = null;
}

function onRightClick(e) {
  e.preventDefault();
  hideChartMenu();
  chartMenu.style.display = 'block';
  chartMenu.style.left = `${e.pageX}px`;
  chartMenu.style.top = `${e.pageY}px`;
  currentChart = e.target;
}

function appendChartMenuStyle() {
  const style = document.createElement("style");
  style.textContent = '.context-menu { \
    position: absolute; \
    text-align: center; \
    background: #eee; \
    border: solid 2px rgba(165, 11, 192, 1); \
    border-radius: 5px; \
  } \
   \
  .context-menu ul { \
    padding: 0; \
    margin: 0; \
    min-width: 150px; \
    list-style: none; \
  } \
   \
  .context-menu ul li { \
    padding: 2px 0; \
    border: solid 1px rgba(165, 11, 192, 1); \
  } \
   \
  .context-menu ul li:hover { \
    background: rgba(165, 11, 192, 0.2); \
    cursor: pointer; \
  }';
  document.head.appendChild(style);
}

// ***************************
// Initialization
// ***************************

Chart.defaults.font.size = 14;
Chart.defaults.font.family = "'Times New Roman', Times, serif";  // "'Arial', sans-serif"
//Chart.defaults.font.weight = 400;

Chart.defaults.backgroundColor = '#9BD0F5';
Chart.defaults.borderColor = '#aaa'; // #36A2EB
Chart.defaults.color = '#000';

Chart.defaults.plugins.title.font.size = 20;

function initializeGraphe() {
  var ctx;

  // Power, Voltage
  [power_line, power_line_length] = create_Line(data_date_formated, data_line_power, 'Puissance, Tension', power_line_scale);
  ctx = document.getElementById('can_mean_power');
  LineGraph_Power = new Chart(ctx, power_line);
  ctx.ondblclick = ondblClick;
  ctx.oncontextmenu = onRightClick;
  ctx['chartName'] = 'Puissance';
  divIdToChart['can_mean_power'] = LineGraph_Power;

  // Temperature
  [temperature_line, temperature_line_length] = create_Line(data_date_formated, data_line_temperature, 'Température', temperature_line_scale);
  ctx = document.getElementById('can_mean_temperature');
  LineGraph_Temperature = new Chart(ctx, temperature_line);
  ctx.ondblclick = ondblClick;
  ctx.oncontextmenu = onRightClick;
  ctx['chartName'] = 'Température';
  divIdToChart['can_mean_temperature'] = LineGraph_Temperature;

  // Energy
  [energy_line, energy_line_length] = create_Line(data_date_formated, data_line_energy, 'Energie du jour', energy_line_scale);
  ctx = document.getElementById('can_mean_energy');
  LineGraph_Energy = new Chart(ctx, energy_line);
  ctx.ondblclick = ondblClick;
  ctx.oncontextmenu = onRightClick;
  ctx['chartName'] = 'Energie_jour';
  divIdToChart['can_mean_energy'] = LineGraph_Energy;

  energy_bar = create_Bar_Energy(data_bar_energy, 'Energie', 'Jour');
  ctx = document.getElementById('can_histo_energy');
  BarGraph_Energy = new Chart(ctx, energy_bar);
  ctx.ondblclick = ondblClick;
  ctx.oncontextmenu = onRightClick;
  ctx['chartName'] = 'Energie';
  divIdToChart['can_histo_energy'] = BarGraph_Energy;

  data_length = power_line_length + temperature_line_length + energy_line_length + 1;

    // Select the current month
  let date = new Date();
  document.getElementById("mois").options[date.getMonth()].selected = 'selected';

  // Select the current year
  let start_year = 2023;
  var option_annee = document.getElementById("annee");
  for (let i = start_year; i <= date.getFullYear(); i++){
    var opt = document.createElement('option');
    opt.value = i;
    opt.innerHTML = i;
    option_annee.appendChild(opt);
  }
  document.getElementById("annee").options[date.getFullYear()-start_year].selected = 'selected';

  // Création des tableaux energie
  for (let i = start_year; i <= date.getFullYear(); i++){
    energy_array.push(i.toString());
    energy_max.push(i.toString());
  }

  // Init splitter
  setupResizerEvents();

  // Append the style for the context menu
  appendChartMenuStyle();

  // For test
//  updateGraph(data_graphe, false);

  window.addEventListener("resize", e => {
    setGrapheHeight();
  });
}

