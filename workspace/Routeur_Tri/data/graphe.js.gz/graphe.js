"use strict";

//let data_graphe = [[1729900817, 368.06, 6.03, 227.43, 32.11, 26.00, 0.00, 368.06, 6.03, 227.43],
//[1729900937, 364.80, 5.94, 225.69, 32.10, 26.00, 0.00, 364.80, 5.94, 225.69],
//[1729901057, 361.80, 5.84, 223.91, 32.09, 26.00, 0.00, 361.80, 5.84, 223.91],
//[1729901178, 362.94, 5.88, 224.58, 32.08, 26.00, 0.00, 362.94, 5.88, 224.58],
//[1729901299, 434.80, 5.94, 226.76, 32.08, 26.00, 0.00, 434.80, 5.94, 226.76],
//[1729901419, 452.63, 5.90, 226.35, 32.07, 26.00, 0.00, 452.63, 5.90, 226.35],
//[1729901540, 452.04, 6.00, 228.24, 32.06, 25.88, 0.00, 452.04, 6.00, 228.24],
//[1729901660, 450.15, 5.98, 227.96, 32.06, 25.88, 0.00, 450.15, 5.98, 227.96],
//[1729901780, 447.77, 5.95, 227.22, 32.06, 25.88, 0.00, 447.77, 5.95, 227.22],
//[1729901901, 450.86, 6.07, 229.54, 32.06, 25.88, 0.00, 450.86, 6.07, 229.54],
//[1729902021, 448.39, 6.02, 228.44, 32.05, 26.00, 0.00, 448.39, 6.02, 228.44],
//[1729902142, 442.39, 5.87, 225.72, 32.04, 26.00, 0.00, 442.39, 5.87, 225.72],
//[1729902262, 443.50, 5.92, 226.65, 32.03, 26.00, 0.00, 443.50, 5.92, 226.65],
//[1729902383, 434.58, 6.12, 230.08, 32.03, 26.00, 0.00, 434.58, 6.12, 230.08],
//[1729902504, 353.07, 6.31, 232.27, 32.03, 26.00, 0.00, 353.07, 6.31, 232.27],
//[1729902624, 327.97, 6.32, 232.00, 32.03, 26.00, 0.00, 327.97, 6.32, 232.00],
//[1729902745, 326.20, 6.28, 231.08, 32.03, 26.00, 0.00, 326.20, 6.28, 231.08],
//[1729902865, 326.66, 6.30, 231.35, 32.03, 26.00, 0.00, 326.66, 6.30, 231.35],
//[1729902985, 324.17, 6.22, 229.90, 32.03, 25.88, 0.00, 324.17, 6.22, 229.90],
//[1729903106, 325.95, 6.25, 230.82, 32.03, 26.00, 0.00, 325.95, 6.25, 230.82],
//[1729903226, 326.78, 6.27, 231.26, 32.03, 26.00, 0.00, 326.78, 6.27, 231.26],
//[1729903347, 322.40, 6.16, 229.14, 32.03, 25.88, 0.00, 322.40, 6.16, 229.14],
//[1729903467, 322.25, 6.16, 229.15, 32.02, 25.88, 0.00, 322.25, 6.16, 229.15],
//[1729903588, 327.97, 6.34, 232.56, 32.03, 25.88, 0.00, 327.97, 6.34, 232.56],
//[1729903708, 322.59, 6.23, 230.43, 32.01, 25.88, 0.00, 322.59, 6.23, 230.43]];

// Graphe variables
var power_line, voltage_line, energy_line;
var energy_bar;
var BarGraph_Power, BarGraph_Energy;
var LineGraph_Power, LineGraph_Voltage, LineGraph_Energy;

var power_line_length, voltage_line_length, energy_line_length;
var data_length;

// Time array
var data_date_formated = new Array();

// Energy 
var energy_bar_source = ['conso', 'surplus', 'prod'];
var energy_count = energy_bar_source.length; // Number of energy graph
var energy_array = [];
var energy_max = [];

var energy_request = false; // Update energie bar 
var energy_data = false; // Les données sont disponibles
var energy_month = ''; // Le mois affiché
var energy_year = ''; // L'année affichée

// Name of months
var month_str = new Array(
  'Janvier', 
  'Février',
  'Mars',
  'Avril',
  'Mai',
  'Juin',
  'Juillet',
  'Août',
  'Septembre',
  'Octobre',
  'Novembre',
  'Décembre'
);

// For when resize the window
var CurrentdivSplitter = null;
var Graph_Up, Graph_Down;

// To get chart from div. For undo zoom, export
var div_plot = {};

// ***************************
// Time functions
// ***************************

function newDate(new_time) {
  return ((new_time - 3600) * 1000);
}

// ***************************
// IHM functions
// ***************************

// ***************************
// Export function
// ***************************

/**
* Convert graphe data to csv
* args class params :
* data: the data property of the chart class (Chart.data)
* label: the label text of labels of the chart class
* columnDelimiter: the column delimiter character (default \t)
* lineDelimiter: the line delimiter character (default \r\n)
*/
function convertChartDataToCSV(args) {
  let result, columnDelimiter, lineDelimiter, labels, datas;

  datas = args.data.datasets || null;
  if (datas == null || !datas.length) {
    return null;
  }

  labels = args.data.labels || null;
  if (labels == null || !labels.length) {
    return null;
  }

  columnDelimiter = args.columnDelimiter || '\t';
  lineDelimiter = args.lineDelimiter || '\r\n';

  result = '';
  
  // Title of the columns
  result += args.label;
  result += columnDelimiter;
  for (var j = 0; j < datas.length; j++) {
    result += datas[j].label;
    result += columnDelimiter;
  }
  result += lineDelimiter;
  
  // We suppose that every datasets have the same length of labels
  for (var i = 0; i < labels.length; i++) {
    // Convert unix datetime to human readable date
    let dateObject = new Date(labels[i]);
    result += dateObject.toLocaleString();
    result += columnDelimiter;
    for (var j = 0; j < datas.length; j++) {
      result += (datas[j].data[i]).toString().replace(".", ",");
      result += columnDelimiter;
    }
    result += lineDelimiter;
  }

  return result;
}

function exportCSV(can_plot) {
  var theChart = div_plot[can_plot];
  var data_csv = convertChartDataToCSV({
      data: theChart.data,
      label: 'Date'
  });
  
  if (data_csv == null) return;
//  console.log(data_csv);
  
  var blob = new Blob([data_csv],
          { type: "text/plain; charset=utf-8" });

  // Save the file with FileSaver.js
  saveAs(blob, "graphe.csv");
}

// Export graphic to PNG
function exportPNG(chart, name) {
  const imageLink = document.createElement('a');
  const canvas = document.getElementById(chart);
  imageLink.download = name;
  imageLink.href = canvas.toDataURL("image/png", 1);
  imageLink.click();
}

// ***************************
// Power, voltage, temp graphe function
// ***************************

function doClearGraphe() {
  // date
  data_date_formated.length = 0;
  // Power
  for (var i = 0; i < power_line_length; i++) {
    power_line.data.datasets[i].data.length = 0;
  }
  // Voltage, temperature
  for (var i = 0; i < voltage_line_length; i++) {
    voltage_line.data.datasets[i].data.length = 0;
  }
  // Energy
  for (var i = 0; i < energy_line_length; i++) {
    energy_line.data.datasets[i].data.length = 0;
  }
}

// Refresh the graphe for a specific date
function refreshGraph() {
    doClearGraphe();
    if (document.getElementsByName("cbdateGraph")[0].checked)
    {
      let d = document.getElementById("dtPicker").value;
      d = "/" + d.substr(2) + ".csv";
      ESP_Request("Update_CSV", [d, 'data']);
    }
    else
      ESP_Request("Update_CSV", ["/data.csv", 'data']);
}

function do_updateGraph(data) {
  var i = 0;
  // Date
  data_date_formated.push(newDate(data[i]));
  i++;
  // Order is U_Ph1, P_Ph1, 2, 3, P_Prod, Temp
  // Phase 1, 2, 3
  var j = 0;
  var pTotal = 0.0;
  for (; j < 3; j++)
  {
    voltage_line.data.datasets[j].data.push(data[i]);
    i++;
    power_line.data.datasets[j].data.push(data[i]);
    pTotal += parseFloat(data[i]);
    i++;
  }
  // P total
  pTotal = Math.round(pTotal * 100) / 100;
  power_line.data.datasets[j].data.push(pTotal);
  // P Prod
  power_line.data.datasets[j+1].data.push(data[i]);
  i++;
  // Voltage, Temperature
  for (; j < voltage_line_length; j++) {
    voltage_line.data.datasets[j].data.push(data[i]);
    i++;
  }
  // Energy
  for (let j = 0; j < energy_line_length; j++) {
    energy_line.data.datasets[j].data.push(data[i++]);
  }
}

function updateGraph(data, append) {
  if (append) {
    do_updateGraph(data);
  }
  else
    {
      doClearGraphe();
      for (let j = 0; j < data.length; j++) {
        do_updateGraph(data[j]);
      }
    }
  LineGraph_Power.update();
  LineGraph_Voltage.update();
  LineGraph_Energy.update();
  if (!append)
  {
    LineGraph_Power.resetZoom();
    LineGraph_Voltage.resetZoom();
    LineGraph_Energy.resetZoom();
  }
}

// ***************************
// Energy function
// ***************************

function update_energy(raw_data) {
  // Format data received
  if (typeof raw_data != 'undefined')
  {
    var year = energy_year;
    energy_array[year] = new Array('01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12');
    energy_max[year] = new Array(12);

    var first_mois = '';
    var lines = raw_data.split("\r\n");
    // Skip first line of title
    for (var i = 1; i < lines.length; i++) {
      if (lines[i] != "")
      {
        var values = lines[i].split('\t');

        // Le premier est la date au format dd/mm
        var mm = values[0].substring(3);
        var m = parseInt(mm) - 1;       
        var jj = parseInt(values[0].substring(0,2)) - 1;

        // On crée un tableau de 31 jours pour le mois
        if (mm !== first_mois)
        {
          energy_array[year][mm] = new Array(31);
          energy_max[year][m] = new Array(energy_count).fill(0.0); // [0.0, 0.0, 0.0];
          first_mois = mm;
        }
        // Nouveau tableau pour ce jour
        energy_array[year][mm][jj] = new Array();
        for (var j=1; j<values.length; j++)
        {  
          energy_array[year][mm][jj].push(values[j]);
          energy_max[year][m][j-1] += parseFloat(values[j]);
        }
      }
    }
  }

  // Update graphe
  var parray;
  var e_kwh;
  // First, empty the existing data
  energy_bar.data.labels.length = 0;
  for (var i=0; i<energy_bar.data.datasets.length; i++)
    energy_bar.data.datasets[i].data.length = 0;
  
  if (energy_month == 'all')
  {
    parray = energy_max[energy_year];
    for (var j=0; j<12; j++)
    {
      if (Array.isArray(parray[j]))
      {      
        energy_bar.data.labels.push(month_str[j]);
        for (var k=0; k<parray[j].length; k++)
        {
          e_kwh = Math.round(parray[j][k]/10)/100.0;
          energy_bar.data.datasets[k].data.push(e_kwh);
        }            
      }        
    }
    energy_bar.options.scales.x.title.text = 'Mois';
    energy_bar.options.scales.y.title.text = 'kWh';
  }
  else
  {
    parray = energy_array[energy_year][energy_month];

    if (typeof parray != 'undefined') {
      // On parcourt les jours du mois
      for (var j=0; j<31; j++)
      {
        // Si on a des données pour ce jour
        if (Array.isArray(parray[j]))
        {
          energy_bar.data.labels.push(j+1);
          for (var k=0; k<parray[j].length; k++)
          {
            energy_bar.data.datasets[k].data.push(parray[j][k]);
          }          
        }
      }
    }
    else alert("Pas de données pour ce mois");  
    energy_bar.options.scales.x.title.text = 'Jour';
    energy_bar.options.scales.y.title.text = 'Wh';
  }

  BarGraph_Energy.update();
  BarGraph_Energy.resetZoom();
}

// Determine the month and year requested
function getEnergy() {
  var select = document.getElementById('mois');  
  var id = select.selectedIndex;
  var month = select.options[id].value;  
  
  select = document.getElementById('annee');  
  id = select.selectedIndex;
  var year = select.options[id].value;    
  
  if (typeof energy_array[year] == 'undefined')
  {
    energy_month = month;
    energy_year = year;
    // Flag to request the data of the year in the process() function
    energy_request = true;
  }
  else
  {
    if ((month !== energy_month) || (year !== energy_year))
    {
      energy_month = month;
      energy_year = year;
      update_energy();
    }
  }
}

// ***************************
// Parse CSV function
// ***************************

// Parse un fichier csv et renvoie un tableau de nb_var tableaux [[], ..., []]
function parseCSV(raw_string, nb_var) {
  var lines = raw_string.split("\r\n");
  var array = new Array(lines.length);

  var k = 0;
  for (var i = 0; i < lines.length; i++) {
    if (lines[i] != "")
    {
      array[k] = new Array(nb_var);
      var data = lines[i].split("\t");
      var data_size = data.length; // Normalement = nb_var
      
      for (let j = 0; j < nb_var; j++) {
        if (j < data_size)
          array[k][j] = parseFloat(data[j]);
        else
          array[k][j] = 0;
      }

      k++;
    }
  }
  // Suppress empty lines
  if (k != lines.length)
    array.length = k;
  return array;
}

function parseCSVandUpdateGraph(raw_string, nb_var) {
  doClearGraphe();
  var lines = raw_string.split("\r\n");

  for (var i = 0; i < lines.length; i++) {
    if (lines[i] != "")
    {
      var data = lines[i].split("\t");
      var data_size = data.length; // Normalement = nb_var
      if (data_size != nb_var)
      {
        let array = new Array(nb_var);
        for (let j = 0; j < nb_var; j++) {
          if (j < data_size)
            array[j] = parseFloat(data[j]);
          else
            array[j] = 0;
        }
        do_updateGraph(array);
      }
      else
        do_updateGraph(data);
    }
  }
  LineGraph_Power.update();
  LineGraph_Voltage.update();
  LineGraph_Energy.update();
  LineGraph_Power.resetZoom();
  LineGraph_Voltage.resetZoom();
  LineGraph_Energy.resetZoom();
}

// ***************************
// Plot create functions
// https://www.chartjs.org/docs/latest/
// ***************************

var timeFormat = 'HH:mm';  // "HH:mm"; DD T
var dateFormat = 'DD MM YYYY HH:mm:ss';

var dragOptions = {
    borderColor: 'rgba(225,225,225,0.3)',
    borderWidth: 5,
    backgroundColor: 'rgb(225,225,225)',
    animationDuration: 500  
};

const axisID = {y: "W", y1: "V", y2: "°C", y3: "Wh"};

var power_line_scale = {
  x: {
    type: 'time',
    time: {
      tooltipFormat: timeFormat,
      displayFormats: {
        minute: timeFormat,
      },
      round: 'minute',
      unit: 'minute'
    },
    title: {
      display: true,
      text: 'Heure'
    }
  },
  y: { // Power axis
      type: 'linear',
      position: 'left',
      title: {
        display: true,
        text: 'W'
      },
      grid: {
        display: true,
        color: '#888'
      }
  },
};

var voltage_line_scale = {
  x: {
    type: 'time',
    time: {
      tooltipFormat: timeFormat,
      displayFormats: {
        minute: timeFormat,
      },
      round: 'minute',
      unit: 'minute'
    },
    title: {
      display: true,
      text: 'Heure'
    }
  },
  y1: { // Voltage axis
      type: 'linear',
      position: 'left',
      title: {
        display: true,
        text: 'V'
      },
      grid: {
        display: false,
      }
  },  
  y2: { // Temp axis
      type: 'linear',
      position: 'right',
      title: {
        display: true,
        text: '°C'
      },
      grid: {
        display: true,
        color: '#ddd'
      }
  },
};

var energy_line_scale = {
  x: {
    type: 'time',
    time: {
      tooltipFormat: timeFormat,
      displayFormats: {
        minute: timeFormat,
      },
      round: 'minute',
      unit: 'minute'
    },
    title: {
      display: true,
      text: 'Heure'
    }
  },
  y3: {
      type: 'linear',
      position: 'left',
      title: {
        display: true,
        text: 'Wh'
      }
    }
};

function chartClickEvent(event, array) {
  this.chart.resetZoom();
}

const zoomOptions = {
//  limits: {
//    x: {min: -200, max: 200, minRange: 50},
//    y: {min: -200, max: 200, minRange: 50}
//  },
  pan: {
    enabled: true,
    mode: 'x',
  },
  zoom: {
    wheel: {
      enabled: true,
    },
    drag: {
      enabled: true
    },
    pinch: {
      enabled: true
    },
    mode: 'x',
    onZoomComplete({chart}) {
      // This update is needed to display up to date zoom level in the title.
      // Without this, previous zoom level is displayed.
      // The reason is: title uses the same beforeUpdate hook, and is evaluated before zoom.
      chart.update('none');
    }
  }
};

// For background
const plugin = {
  id: 'customCanvasBackgroundColor',
  beforeDraw: (chart, args, options) => {
    const {ctx} = chart;
    ctx.save();
    ctx.globalCompositeOperation = 'destination-over';
    ctx.fillStyle = options.color || '#ffffff';
    ctx.fillRect(0, 0, chart.width, chart.height);
    ctx.restore();
  }
};

function create_Line(data_label, data_line, opt_title, opt_scale) {
  return {
    type: 'line',
    data: {
      // data_label.slice() si on veut individualiser les dates
      labels: data_label,
      datasets: data_line
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      normalized: true,
      animation: false,
      
      parsing: {
        parsing: false,
      },

      plugins: {
        zoom: zoomOptions,
        title: {
          display: true,
          text: opt_title
        },
        legend: {
          position: 'top'
        },
        tooltip: {
          titleColor: '#000',
          bodyColor: '#000',
          backgroundColor: 'rgba(255, 249, 196, 0.92)',
          borderColor: 'rgb(0, 0, 255)',
          borderWidth: 1,
          position: 'nearest',
          callbacks: {
            afterTitle: function(context) {
              return "-----------";
            },
            label: function(context) {
              // console.log(context);
              let scaleID = context.dataset.yAxisID;
              return '  ' + context.dataset.label + ': ' + context.raw + ' ' + axisID[scaleID];
            }
          }
        },
        customCanvasBackgroundColor: {
          color: 'white',
        },
      },
      interaction: {
 //       axis: 'x',
        mode: 'index',  // index nearest  point dataset x
        intersect: false
      },
      scales: opt_scale,

//      onClick: (event, array) => { LineGraph_Power.resetZoom();}    //chartClickEvent
    },
    plugins: [plugin],
  };
}

function create_Bar_Energy(data_bar, opt_title, opt_unit) {
  return {
    type: 'bar',
    data: data_bar,
    options: {
      elements: {
        rectangle: {
          borderWidth: 2
        }
      },
      responsive: true,
      maintainAspectRatio: false,
      normalized: true,
      animation: true,
      
      plugins: {
        zoom: zoomOptions,
        title: {
          display: true,
          text: opt_title
        },
        legend: {
          display: true,
          position: 'right'
        },
        tooltip: {
          titleColor: '#000',
          bodyColor: '#000',
          backgroundColor: 'rgba(255, 249, 196, 0.92)',
          borderColor: 'rgb(0, 0, 255)',
          borderWidth: 1,
          position: 'nearest',
          callbacks: {
            label: function(context) {
              // console.log(context);
              if (energy_month == 'all')
                return '  ' + context.dataset.label + ': ' + context.raw + ' kWh';
              else
                return '  ' + context.dataset.label + ': ' + Math.round(context.raw/10)/100.0 + ' kWh';
            }
          }
        },
        customCanvasBackgroundColor: {
          color: 'white',
        },
      },
      interaction: {
 //       axis: 'x',
        mode: 'index',  // index nearest  point dataset x
        intersect: false
      },
      scales: {
        x: {
          display: true,
          title: {
            display: true,
            text: opt_unit
          },
          ticks: {
            min: 0
          }
        },
        y: {
          display: true,
          title: {
            display: true,
            text: 'Wh'
          },
          ticks: {
            min: 0
          }          
        }
      },
      
 //     onClick: (event, array) => { LineGraph_Energy.resetZoom();} 
    },
    plugins: [plugin],
  };
}

// ***************************
// Data Plot line functions
// ***************************

var chartColors = {
  red: 'rgb(255, 0, 0)',
  pink: 'rgb(255, 99, 132)',
  orange: 'rgb(255, 159, 64)',
  yellow: 'rgb(255, 205, 86)',
  green: 'rgb(0, 255, 0)',
  lightgreen: 'rgb(75, 192, 192)',
  blue: 'rgb(0, 0, 255)',
  lightblue: 'rgb(54, 162, 235)',
  purple: 'rgb(153, 102, 255)',
  grey: 'rgb(201, 203, 207)'
};

var chartColors_alpha = {
  red: 'rgba(255, 0, 0, 0.2)',
  pink: 'rgba(255, 99, 132, 0.2)',
  orange: 'rgba(255, 159, 64, 0.2)',
  yellow: 'rgba(255, 205, 86, 0.2)',
  green: 'rgba(0, 255, 0, 0.2)',
  lightgreen: 'rgba(75, 192, 192, 0.2)',
  blue: 'rgba(0, 0, 255, 0.2)',
  lightblue: 'rgba(54, 162, 235, 0.2)',
  purple: 'rgba(153, 102, 255, 0.2)',
  grey: 'rgba(201, 203, 207, 0.2)'
};

var data_line_power = [
    {
      label: 'Puissance Ph1',
      backgroundColor: chartColors_alpha.blue,
      borderColor: chartColors.blue,
      fill: true,
      data: new Array(),
      borderWidth: 1,
      yAxisID: 'y', // power-axis
      pointRadius: 2
    }, {
      label: 'Puissance Ph2',
      backgroundColor: chartColors_alpha.green,
      borderColor: chartColors.green,
      fill: true,
      data: new Array(),
      borderWidth: 1,
      yAxisID: 'y',
      pointRadius: 2
    }, {
      label: 'Puissance Ph3',
      backgroundColor: chartColors_alpha.red,
      borderColor: chartColors.red,
      fill: true,
      data: new Array(),
      borderWidth: 1,
      yAxisID: 'y',
      pointRadius: 2
    }, {
      label: 'Puissance total',
      backgroundColor: chartColors_alpha.purple,
      borderColor: chartColors.purple,
      fill: true,
      data: new Array(),
      borderWidth: 1,
      yAxisID: 'y',
      pointRadius: 2
    }, {
      label: 'Puissance Prod',
      backgroundColor: chartColors_alpha.orange,
      borderColor: chartColors.orange,
      fill: true,
      data: new Array(),
      borderWidth: 1,
      yAxisID: 'y',
      pointRadius: 2
    }
];

var data_line_voltage = [
    {
      label: 'Tension Ph1',
      backgroundColor: chartColors.blue,
      borderColor: chartColors.blue,
      fill: false,
      data: new Array(),
      borderWidth: 1,
      yAxisID: 'y1', // voltage-axis
      pointRadius: 2
    }, {
      label: 'Tension Ph2',
      backgroundColor: chartColors.green,
      borderColor: chartColors.green,
      fill: false,
      data: new Array(),
      borderWidth: 1,
      yAxisID: 'y1', // voltage-axis
      pointRadius: 2
    }, {
      label: 'Tension Ph3',
      backgroundColor: chartColors.red,
      borderColor: chartColors.red,
      fill: false,
      data: new Array(),
      borderWidth: 1,
      yAxisID: 'y1', // voltage-axis
      pointRadius: 2
    }, {
      label: 'Temp Cirrus',
      backgroundColor: chartColors.pink,
      borderColor: chartColors.pink,
      fill: false,
      data: new Array(),
      borderWidth: 1,
      yAxisID: 'y2', // temp-axis
      pointRadius: 2
    }, {
      label: 'Temp interne',
      backgroundColor: chartColors.yellow,
      borderColor: chartColors.yellow,
      fill: false,
      data: new Array(),
      borderWidth: 1,
      yAxisID: 'y2',
      pointRadius: 2
    }, {
      label: 'Temp externe',
      backgroundColor: chartColors.lightblue,
      borderColor: chartColors.lightblue,
      fill: false,
      data: new Array(),
      borderWidth: 1,
      yAxisID: 'y2',
      pointRadius: 2
    }
];

var data_line_energy = [
    {
      label: 'E Conso',
      backgroundColor: chartColors.blue,
      borderColor: chartColors.blue,
      fill: false,
      data: new Array(),
      borderWidth: 2,
      yAxisID: 'y3', // energy-axis
      pointRadius: 0
    }, {
      label: 'E Surplus',
      backgroundColor: chartColors.red,
      borderColor: chartColors.red,
      fill: false,
      data: new Array(),
      borderWidth: 2,
      yAxisID: 'y3', // energy-axis
      pointRadius: 0
    }, {
      label: 'E Prod',
      backgroundColor: chartColors.orange,
      borderColor: chartColors.orange,
      fill: false,
      data: new Array(),
      borderWidth: 2,
      yAxisID: 'y3', // energy-axis
      pointRadius: 0
    }
];

var data_bar_energy = {
  labels: ['1'],  
  datasets: [{
      label: 'E Conso',
      borderWidth: 2,
      backgroundColor: chartColors_alpha.blue,
      borderColor: chartColors.blue,
      data: [1]
  }, {
      label: 'E Surplus',
      borderWidth: 2,
      backgroundColor: chartColors_alpha.red,
      borderColor: chartColors.red,
      data: [1]
  }, {
      label: 'E Prod',
      borderWidth: 2,
      backgroundColor: chartColors_alpha.orange,
      borderColor: chartColors.orange,
      data: [1]
  }]  
};

// ***************************
// Splitter gestion
// ***************************
// Minimum height for divUp
const divUpminHeight = 80;
var divUpmaxHeight;

// Add events to splitter version IE, Firefox, Opera
function initSplitter(splitter) {
  let divUp = splitter.parentElement.querySelector('.divUp');
  // Test if we have already initialized the splitter
  if (divUp.style.height !== "") return;
  
  splitter.onpointerdown = function(e) {  
    // Turn on split capture for resizing
    e.target.onpointermove = mouseMoveSplitter;
    e.target.setPointerCapture(e.pointerId);

  };
  splitter.onpointerup = function(e) {
    // Turn off dragging by removing envent     
    e.target.onpointermove = null;
    e.target.releasePointerCapture(e.pointerId);
  };
  // Initialize the height of divUp
  divUp.style.height = 2*divUpminHeight + 'px'; 
}    

function mouseMoveSplitter(e) {
  // The div container of the splitter
  let divSplitter = e.target.parentElement; // same as e.target.closest('.divSplitter')
  let divUp = divSplitter.querySelector('.divUp');
  let divDown = divSplitter.querySelector('.divDown');

  // Get y-coordinate of pointer relative to container
  let pointerRelativeYpos = e.clientY - divSplitter.offsetTop;

  let new_height = (Math.max(divUpminHeight, pointerRelativeYpos));
  new_height = (Math.min(divUpmaxHeight, new_height));

  // Set new height for divUp, divDown automaticaly resize with flex property 
  divUp.style.height = new_height + 'px';
  divDown.style.height = (divSplitter.clientHeight - new_height - e.target.clientHeight) + 'px';

  // Callback to do other staff
  resizedSplitterDiv_callback(divSplitter, new_height, divDown.clientHeight);
}; 

function resizedSplitterDiv_callback(divSplitter, divUpHeight, divDownHeight) {
  if (Graph_Up !== null)
  {  
    let h = divUpHeight + 20 ; // padding de divUp
    if ((Graph_Up.legend.position === 'top') || (Graph_Up.legend.position === 'bottom'))
      h = h - Graph_Up.legend.height;
    Graph_Up.canvas.parentNode.style.height = h + 'px';
    Graph_Up.resize();
  }

  if (Graph_Down !== null)
  {
    let h = divDownHeight - 20; // padding de divDown + chouia ascenseur
    if ((Graph_Down.legend.position === 'top') || (Graph_Down.legend.position === 'bottom'))
      h = h - Graph_Down.legend.height;      
    Graph_Down.canvas.parentNode.style.height = h + 'px';
    Graph_Down.resize();
  }
}

function resizedivSplitter() {
  if (CurrentdivSplitter === null) return;
  let height = window.innerHeight - CurrentdivSplitter.offsetTop;
  CurrentdivSplitter.style.height = height + "px";
  divUpmaxHeight = height - divUpminHeight;

  let hUp = 0, hDown = 0;
  let divUp = CurrentdivSplitter.querySelector('.divUp');
  if (divUp !== null) hUp = divUp.clientHeight;
  let divDown = CurrentdivSplitter.querySelector('.divDown');
  if (divDown !== null) hDown = divDown.clientHeight;  
  resizedSplitterDiv_callback(CurrentdivSplitter, hUp, hDown);
}

  // Gestion splitter
function DoSplitterAction(CurrentPageName) {
  let splitter = null;
  
  if (CurrentPageName === 'm_Graphe')
  {
    CurrentdivSplitter = document.getElementById('m_Graphe').lastElementChild;    
    Graph_Up = null;
    Graph_Down = LineGraph_Power;
  }
  else
  if (CurrentPageName === 'm_VoltageTemp')
  {
    CurrentdivSplitter = document.getElementById('m_VoltageTemp').lastElementChild;    
    Graph_Up = null;
    Graph_Down = LineGraph_Voltage;
  }
  else
  if (CurrentPageName === 'm_Energy')
  {
    splitter = document.getElementById('splitterEnergy');
    CurrentdivSplitter = splitter.parentElement; // Same as splitter.closest('.divSplitter')
    Graph_Up = LineGraph_Energy;
    Graph_Down = BarGraph_Energy;
  } 
  else CurrentdivSplitter = null;
  
  if (CurrentdivSplitter !== null)
  {
    if (splitter !== null)
      initSplitter(splitter);
    resizedivSplitter(); 
  }
}

// ***************************
// Undo zoom
// ***************************

function undoZoom(can_plot) {
  div_plot[can_plot].resetZoom();
}

function ondblClick(evt) {
//  console.log(evt);
  let can = evt.target;
  undoZoom(can.id);
}

// ***************************
// Initialization
// ***************************

Chart.defaults.font.size = 14;
Chart.defaults.font.family = "'Times New Roman', Times, serif";  // "'Arial', sans-serif"
//Chart.defaults.font.weight = 400;

Chart.defaults.backgroundColor = '#9BD0F5';
Chart.defaults.borderColor = '#aaa'; // #36A2EB
Chart.defaults.color = '#000';

Chart.defaults.plugins.title.font.size = 20;

function initializeGraphe() {

  var ctx;

  // Power
  power_line = create_Line(data_date_formated, data_line_power, 'Puissance', power_line_scale);
  ctx = document.getElementById('can_mean_power');
  LineGraph_Power = new Chart(ctx, power_line);
  power_line_length = power_line.data.datasets.length;
  ctx.ondblclick = ondblClick;
  div_plot['can_mean_power'] = LineGraph_Power;

  // Voltage, temp
  voltage_line = create_Line(data_date_formated, data_line_voltage, 'Tension et Température', voltage_line_scale);
  ctx = document.getElementById('can_mean_voltage');
  LineGraph_Voltage = new Chart(ctx, voltage_line);
  voltage_line_length = voltage_line.data.datasets.length;
  ctx.ondblclick = ondblClick;
  div_plot['can_mean_voltage'] = LineGraph_Voltage;

  // Energy
  energy_line = create_Line(data_date_formated, data_line_energy, 'Energie du jour', energy_line_scale);
  energy_bar = create_Bar_Energy(data_bar_energy, 'Energie', 'Jour');

  ctx = document.getElementById('can_mean_energy');
  LineGraph_Energy = new Chart(ctx, energy_line);
  energy_line_length = energy_line.data.datasets.length;
  ctx.ondblclick = ondblClick;
  div_plot['can_mean_energy'] = LineGraph_Energy;

  ctx = document.getElementById('can_histo_energy');
  BarGraph_Energy = new Chart(ctx, energy_bar);
  ctx.ondblclick = ondblClick;
  div_plot['can_histo_energy'] = BarGraph_Energy;
  
  data_length = power_line_length - 1 + voltage_line_length + energy_line_length + 1;
  
    // Select the current month
  let date = new Date();
  document.getElementById("mois").options[date.getMonth()].selected = 'selected';
  
  // Select the current year
  let start_year = 2023;
  var option_annee = document.getElementById("annee");
  for (let i = start_year; i <= date.getFullYear(); i++){
    var opt = document.createElement('option');
    opt.value = i;
    opt.innerHTML = i;
    option_annee.appendChild(opt);
  }  
  document.getElementById("annee").options[date.getFullYear()-start_year].selected = 'selected';
  
  // Création des tableaux energie
  for (let i = start_year; i <= date.getFullYear(); i++){
    energy_array.push(i.toString());
    energy_max.push(i.toString());    
  }

  var rz = resizilla(resizedivSplitter, 10, true);
  
  // For test
//  updateGraph(data_graphe, false);
  
//  downloadCSV(LineGraph_Power);
  
}
