"use strict";

var xmlHttp = createXmlHttpObject();
var loadingdiv = null;        // le div d'attente pour l'upload
var request_busy = false;
var pending_request = null;
var first_init = true;        // Premier affichage de la page, on rafraichit les champs constants
var first_graphe = true;      // Initialisation du graphe

// Relais, Alarm
class relay {
  constructor() {
    this.actif = false;
    this.begin0 = '';
    this.end0 = '';
    this.begin1 = '';
    this.end1 = '';
    this.forced = false;
  }
};

const relais_count = 3;
var relais = Array.from({ length: relais_count }, () => new relay());
var current_RelayID = 0;

// web events
function createXmlHttpObject() {
  if (window.XMLHttpRequest) {
    xmlHttp = new XMLHttpRequest();
  } else {
    xmlHttp = new ActiveXObject('Microsoft.XMLHTTP');
  }
  xmlHttp.onerror = onError;
  return xmlHttp;
}

function onError(event) {
  console.error("Une erreur " + event.target.status + " s'est produite au cours de la réception du document.");
  // On annule la requete et on poursuit
  if (event.target.status != 0)
  {
    request_busy = false;
    xmlHttp.onreadystatechange = null;
    process();
  }
}

// Test if the server can accept a new request
function serverIsReady(server) {
  return ((!request_busy) && (server.readyState == 0 || server.readyState == 4));
}

// Test if we have received the response
function requestIsOK(server) {
//  console.log('readyState: ', request.readyState);
//  console.log('status: ', request.status);
//  console.log('****');
  return (server.readyState == 4 && server.status == 200);
}

function ESP_Request(send_request, params) {
  // Le server n'est pas prêt, on met la requête en attente
  if (!serverIsReady(xmlHttp)) {
    pending_request = {"request": send_request, "params": params};
    return;
  }

  request_busy = true;
  if (send_request === "getfile")
  {
    xmlHttp.open("POST", "/getfile", true);
    xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlHttp.onreadystatechange = function() {
      if (requestIsOK(this)) {

        var blob = new Blob([this.responseText],
                    { type: "text/plain; charset=utf-8" });

        // Save the file with FileSaver.js
        saveAs(blob, params[1]);
      }
      wait_Upload(false);
      request_busy = false;
    }
    xmlHttp.send("FILE=" + params[0]);
    wait_Upload(true);
    return;
  }

  if (send_request === "delfile")
  {
    xmlHttp.open("POST", "/delfile", true);
    xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlHttp.onreadystatechange = function() {
      if (this.status == 204) {
        document.getElementById("delfile").value = "";
      }
  //          else alert("Not found");
      request_busy = false;
    }
    xmlHttp.send("FILE=" + params[0]);
    return;
  }

  if (send_request === "listfile")
  {
    xmlHttp.open("GET","/listfile?DIR=" + params[0],true);
    xmlHttp.onreadystatechange = function() {
      if (requestIsOK(this)) {
        var xmlResponse = xmlHttp.responseText;
        if (xmlResponse === null) return;
        document.getElementById("data_json").innerHTML = xmlResponse;
      }
      request_busy = false;
    }
    xmlHttp.send(null);
    return;
  }

  if (send_request === "resetESP")
  {
    xmlHttp.open("PUT","/resetESP",true);
    xmlHttp.onreadystatechange = null;
    xmlHttp.send(null);
    request_busy = false;
    return;
  }

  if (send_request === "setTime")
  {
    xmlHttp.open("PUT","/setTime",true);
    xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlHttp.onreadystatechange = null;
    xmlHttp.send(params[0]);  //  + "&UART=1" to send to UART
    request_busy = false;
    return;
  }

  if (send_request === "getCirrus")
  {
    xmlHttp.open("PUT","/getCirrus",true);
    xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlHttp.onreadystatechange = handleServer_getRegister;
    xmlHttp.send(params[0]);
    return;
  }

  if (send_request === "Update_CSV")
  {
    xmlHttp.open("POST", "/getfile", true);
    xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlHttp.onreadystatechange = function()
    {
      if (requestIsOK(this)) {
        if (params[1] === "data")
        {
          if (this.responseText != "")
          {
            var data = parseCSV(this.responseText, data_length);
            updateGraph(data, false);
          }
        }
        else
        {
          // transfert data
          update_energy(this.responseText);
        }
      }
      if (this.status == 204) {
        alert("Pas de fichier");
      }
      loadingdiv.style.visibility = "hidden";
      request_busy = false;
    }
    xmlHttp.send("FILE=" + params[0] + "&DATA_PART=1"); // File dans la partition data
    loadingdiv.style.visibility = "visible";
    return;
  }

  // Opération par défaut : send_request is the param
//  alert(send_request);
  xmlHttp.open("PUT","/operation",true);
  xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xmlHttp.onreadystatechange = null;
  xmlHttp.send(send_request);
  request_busy = false;
}

function process() {
  if (!serverIsReady(xmlHttp))
  {
    setTimeout('process()', 1000);
    return;
  }

  // On a une requête en attente
  if (pending_request != null)
  {
    ESP_Request(pending_request.request, pending_request.params);
    pending_request = null;
    setTimeout('process()', 1000);
    return;
  }

  // Les opérations de base qu'on doit répéter
  request_busy = true;

  // On demande toutes les dernières données
  if (first_init)
  {
    first_init = false;
    xmlHttp.open("GET","/initialisation",true);
    xmlHttp.onreadystatechange = handleServerInitialization;
    xmlHttp.send(null);
  }
  else 
    if (first_graphe)
    {
      first_graphe = false;
      request_busy = false;
      ESP_Request("Update_CSV", ["/data.csv", 'data']);
    }    
    else
      if (energy_request)
      {
        energy_request = false;
        request_busy = false;
        ESP_Request("Update_CSV", ["/energy_"+energy_year+".csv", 'energy']);
      }
      else
        {
          xmlHttp.open("GET","/getLastData",true);
          xmlHttp.onreadystatechange = handleServerResponse;
          xmlHttp.send(null);
        }
  setTimeout('process()', 1000);
}

function handleServer_getTime() {
  if (requestIsOK(xmlHttp))
  {
    var xmlResponse = xmlHttp.responseText;
    request_busy = false;

    if (xmlResponse === null) return;

    document.getElementById("time").innerHTML = xmlResponse;
  }
}

function handleServer_getUARTData() {
  if (requestIsOK(xmlHttp))
  {
    var xmlResponse = xmlHttp.responseText;
    request_busy = false;

    if (xmlResponse === null) return;

    document.getElementById("data_uart").innerHTML = xmlResponse;
  }
}

function handleServerInitialization() {
  if (requestIsOK(xmlHttp))
  {
    var xmlResponse = xmlHttp.responseText;
    request_busy = false;

    if (xmlResponse === null) return;

//    console.log(xmlResponse);

    // On suppose que les infos sont séparées par #
    // SSRType#P_CE#Phase_CE#Percent#T_SSR#T_Relais#T_Clavier
    var values = xmlResponse.split('#');

    if (values.length >= 1)
    {
      // SSR part
      let i = 0;
      let action = values[i++];
      if (action === "1")
      {
        document.getElementById("percent").checked = "checked";
        document.getElementById("powerCE").style.display = "none";
        document.getElementById("rangePercent").style.display = "inline";
      }
      else
      {
        if (action === "2")
          document.getElementById("zero").checked = "checked";
        else
          document.getElementById("fullpower").checked = "checked";
        document.getElementById("powerCE").style.display = "inline";
        document.getElementById("rangePercent").style.display = "none";
      }

      document.getElementById("powerSSR").value = values[i++];
      document.getElementById("CEPhase").value = values[i++];
      document.getElementById("targetSSR").value = values[i++];
      let pcent = values[i++];
      document.getElementById('Pourcent').value = pcent;
      document.getElementById('amount').value = parseInt(pcent).toString() + "%";
      if (values[i++] === "ON")
        document.getElementById("label_SSR").innerHTML = "SSR ON";
      else
        document.getElementById("label_SSR").innerHTML = "SSR OFF";
      
      // Relais part
      InitializeAlarm(values[i++]);
    }
  }
}

var ID_Data_Page = ["time", "_U_Ph1", "_P_Ph1", "_E_Ph1", "_U_Ph2", "_P_Ph2", "_E_Ph2",
                   "_U_Ph3", "_P_Ph3", "_E_Ph3", "_P_Prod", "_E_Prod", "_E_Surplus",
                   "_T_CS", "_T_DS_int", "_T_DS_ext", "_SSR"];

var Unit_Data_Page = ["", " V", " W", " Wh", " V", " W", " Wh", 
                      " V", " W", " Wh", " W", " Wh", " Wh", "°C", "°C", "°C", ""];

var ID_Data_Page_Length = ID_Data_Page.length;

function handleServerResponse() {
  if (requestIsOK(xmlHttp))
  {
    var xmlResponse = xmlHttp.responseText;
    request_busy = false;

    if (xmlResponse === null) return;

//    console.log(xmlResponse);

    // On suppose que les infos sont séparées par #
    var values = xmlResponse.split('#');

    //Time#P_Ch1#U#E_conso#E_surplus#PF#P_Ch2#E_Prod#TI#T_cirrus#TDS1#T_DS2
    if (values.length >= 1)
    {
      // Actualisation page données. Tous les éléments sauf le dernier (état SSR).
      var i;
      for (i=0; i<ID_Data_Page_Length-1; i++)
      {
        document.getElementById(ID_Data_Page[i]).innerHTML = values[i] + Unit_Data_Page[i];
      }
      
      // Actualisation état SSR
      let SSR_State = document.getElementById("_SSR");
      let SSR_label = document.getElementById("label_SSR");
      // Etat du SSR
      if (values[i] === "SSR=0")
      {
        SSR_State.style.display = "none";
        SSR_label.innerHTML = "SSR OFF";
      }
      else
      {
        SSR_label.innerHTML = "SSR ON";
        SSR_State.style.display = "block";
        if (values[i] === "SSR=1")
          SSR_State.style.color = "green";
        else
          SSR_State.style.color = "red";
      }
        
      // Extra data for graphe : p conso, Pprod, tension, températures, énergies
      if ((values.length > ID_Data_Page_Length) &&
          (! document.getElementsByName("cbdateGraph")[0].checked))
      {
        let thedate = new Date();
        let theUnixtime = Math.round(thedate.getTime()/1000) - thedate.getTimezoneOffset() * 60;

        let data = [theUnixtime];
        i++;
        for (; i<values.length; i++) {
          data.push(values[i]);
        }
        // On rajoute les deux températures (attention au point décimal)
//        data.push(values[ID_Data_Page.indexOf("_T_DS_int")].replace(',', '.'));
//        data.push(values[ID_Data_Page.indexOf("_T_DS_ext")].replace(',', '.'));
        // On termine par les énergies
//        data.push(values[ID_Data_Page.indexOf("_E_Ph1")].replace(',', '.'));
//        data.push(values[ID_Data_Page.indexOf("_E_Surplus")].replace(',', '.'));
//        data.push(values[ID_Data_Page.indexOf("_E_Prod")].replace(',', '.'));
        updateGraph(data, true);
      }
    }
  }
}

function wait_Upload(visible) {
  if (visible === true)
  loadingdiv.style.visibility = "visible";
  else
    loadingdiv.style.visibility = "hidden";
  return true;
}

// ***************************
// Time function
// ***************************
function createDateTime() {
  var date = new Date();

  var day = date.getDate();
  var month = date.getMonth() + 1;
  var year = date.getFullYear()-2000;  //   getYear
  var hours = date.getHours();
  var minutes = date.getMinutes();
  var seconds = date.getSeconds();
  var unix = Math.round(date.getTime()/1000) - date.getTimezoneOffset() * 60; // UTC time soit GMT+00:00

  if (day < 10) day = "0" + day;
  if (month < 10) month = "0" + month;
  if (hours < 10) hours = "0" + hours;
  if (minutes < 10) minutes = "0" + minutes;
  if (seconds < 10) seconds = "0" + seconds;

  var today = "TIME=" + [day, month, year].join('-') + "H" + [hours, minutes, seconds].join('-')+ "U" + unix;

//  alert(today);

  return today;
}

function sendDateTime() {
  if (window.confirm("Etes-vous sûr de vouloir changer l'heure ?")) {
    ESP_Request("setTime", [createDateTime()]);
  }
}

// ***************************
// Get the data from ESP
// ***************************

function loadLOG() {
  ESP_Request("getfile", ["/log.txt", "log.txt"]);
}

function deleteLOG() {
  if (window.confirm("Etes-vous sûr de vouloir supprimer le fichier log ?")) {
    ESP_Request("delfile", ["log.txt"]);
  }
}

// ***************************
// Divers
// ***************************

function listDir() {
  ESP_Request("listfile", ["/"]);
}

function resetESP() {
  if (window.confirm("Etes-vous sûr de vouloir faire un RESET ?")) {
    ESP_Request("resetESP");
  }
}

function doToggle(obj) {
  if (obj === "Oled")
  {
    ESP_Request("Toggle_Oled=1");
    return;
  }

  if (obj === "SSR")
  {
    ESP_Request("Toggle_SSR=1");
    let label = document.getElementById("label_SSR");
    if (label.innerHTML === "SSR ON")
      label.innerHTML = "SSR OFF";
    else label.innerHTML = "SSR ON";
    return;
  }

  if (obj === "Relay")
  {
    if (window.confirm("Confirmation du changement ?")) {    
      var result = document.getElementById('ToggleRelay').checked ? '1' : '0';
      relais[current_RelayID].forced = result;
      ESP_Request("Toggle_Relay=" + current_RelayID + "&State=" + result);
    }
    return;
  }
}

// ***************************
// Pourcent SSR
// ***************************

function doSSRAction(action) {
  ESP_Request("SSRAction=" + action);
  if (action === "percent")
  {
    document.getElementById("powerCE").style.display = "none";
    document.getElementById("rangePercent").style.display = "inline";
  }
  else
  {
    document.getElementById("powerCE").style.display = "inline";
    document.getElementById("rangePercent").style.display = "none";
  }
  // Le changement de mode éteint le SSR
  let label = document.getElementById("label_SSR");
  label.innerHTML = "SSR OFF";
  return;
}

// ***************************
// Dimmer SSR
// ***************************
function sendCEPower() {
  let power = document.getElementById("powerSSR").value;
  let target = document.getElementById("targetSSR").value;
  ESP_Request("CEPower=" + power + "&SSRTarget=" + target);
}

function sendCEPhase() {
  let phase = document.getElementById("CEPhase").value;
  ESP_Request("CEPhase=" + phase);
}

function checkLoadPower() {
  ESP_Request("CheckPower=");
}

function setPourcent() {
  if (document.getElementById("percent").checked)
  {
    let pcent = document.getElementById('Pourcent');
    ESP_Request("Pourcent=" + pcent.value);
  }
  else
    alert("Seulement avec pourcentage.");
}

// ***************************
// Relais
// ***************************

// Les heures d'alarme sont séparées par une virgule
function InitializeAlarm(init) {
  var values = init.split(',');

  if (values.length > 0) {
    let j = 0;
    for (let i = 0; i < relais_count; i++) {
      relais[i].forced = (values[j++] == 'ON');
      relais[i].begin0 = values[j++];
      relais[i].end0 = values[j++];
      relais[i].begin1 = values[j++];
      relais[i].end1 = values[j++];
    }
  }
  current_RelayID = 0;
  doRelayAction(current_RelayID);
}

function doRelayAction(id) {
  if (id < relais_count) {
    document.getElementById("Alarm_1_D").value = relais[id].begin0;
    document.getElementById("Alarm_1_F").value = relais[id].end0;
    document.getElementById("Alarm_2_D").value = relais[id].begin1;
    document.getElementById("Alarm_2_F").value = relais[id].end1;
    document.getElementById("ToggleRelay").checked = relais[id].forced;
    current_RelayID = id;
  }
}

function dec2int(value) {
  var result = 0;
  var values = (value + ".").split('.');
  if (values.length > 0) {
    result += parseInt("0" + values[0]) * 60;
    result += parseInt("0" + values[1]);
    if (result == 0)
      result = -1;
  }
  else
    result = -1;
  
  return result;
}

function sendAlarm() {
  if (window.confirm("Confirmation du changement ?")) {
    var result = "AlarmID=" + current_RelayID;
    var tmpD = (document.getElementById('Alarm_1_D').value).trim();
    var tmpF = (document.getElementById('Alarm_1_F').value).trim();
    relais[current_RelayID].begin0 = tmpD;
    relais[current_RelayID].end0 = tmpF;
    result += "&Alarm1D=" + dec2int(tmpD) + "&Alarm1F=" + dec2int(tmpF);

    tmpD = (document.getElementById('Alarm_2_D').value).trim();      
    tmpF = (document.getElementById('Alarm_2_F').value).trim();
    result += "&Alarm2D=" + dec2int(tmpD) + "&Alarm2F=" + dec2int(tmpF);
    relais[current_RelayID].begin1 = tmpD;
    relais[current_RelayID].end1 = tmpF;
    
//    console.log(result);
    
    ESP_Request(result);
  }
}

// ***************************
// Window onload event
// ***************************
function openPage(pageName, elmnt, color) {
  var i, tabcontent, tablinks;
  // Hide all the pages
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  // remove tab color
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].style.backgroundColor = "";
    tablinks[i].style.cursor = 'pointer';
  }
  // Display the new page
  let CurrentPage = document.getElementById(pageName);
  CurrentPage.style.display = "block";
  elmnt.style.backgroundColor = color;
  elmnt.style.cursor = 'default';
  
  DoSplitterAction(pageName);
}

window.onload = function() {
  loadingdiv = document.getElementById("loading");

  // Initialise le graphe
  initializeGraphe();

  // Get the element with id="defaultOpen" and click on it
  document.getElementById("defaultOpen").click();

  setTimeout('process()', 2000);
}
