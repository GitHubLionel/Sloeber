"use strict";

var plot;
var ID_Run;

var bGraphe = null;
var action_graphe = [];
var oscillo = false;
var data_graphe = [[], [], [], []];  // Time, U_rms, P_rms, Temp


var loop = 1e2;

//let data_graphe = [
//    Array(loop),
//    Array(loop),
//    Array(loop),
//    Array(loop),
//];

//for (var i = 0; i < loop; i++) {
//    let x = 2 * Math.PI * i / loop;
//    let y = Math.sin(x);
//  
//    data_graphe[0][i] = Math.round((new Date()).getTime()/1000)+i;
//    data_graphe[1][i] = x;
//    data_graphe[2][i] = y;
//    data_graphe[3][i] = y*y;
//}

function getSize() {
  return {
      "width": window.innerWidth - 50,
      "height": window.innerHeight - 250
  };
}

const fmtDate = uPlot.fmtDate("{DD}/{MM}/{YYYY} {H}:{mm}");
const tzDate = ts => uPlot.tzDate(new Date(ts * 1e3));
function fmtValue(val, prec, unit) {
  return Number(val).toFixed(prec) + unit;
}

// column-highlights the hovered x index
function columnHighlightPlugin({ className, style = {backgroundColor: "rgba(51,204,255,0.3)"} } = {}) {
    let underEl, overEl, highlightEl, currIdx;

    function init(u) {
      underEl = u.under; // u.root.querySelector(".u-under");
      overEl = u.over; // u.root.querySelector(".u-over");

      highlightEl = document.createElement("div");

      className && highlightEl.classList.add(className);

      uPlot.assign(highlightEl.style, {
          pointerEvents: "none",
          display: "none",
          position: "absolute",
          left: 0,
          top: 0,
          height: "100%",
          ...style
      });

      underEl.appendChild(highlightEl);

      // show/hide highlight on enter/exit
      overEl.addEventListener("mouseenter", () => {highlightEl.style.display = null;});
      overEl.addEventListener("mouseleave", () => {highlightEl.style.display = "none";});
    }
  
    function update(u) {
      if ((u.cursor.idx !== null) && (currIdx !== u.cursor.idx)) {
        currIdx = u.cursor.idx;

        let [iMin, iMax] = u.series[0].idxs;

        const dx    = iMax - iMin;
        if (dx != 0) {
          const width = (u.bbox.width / dx) / devicePixelRatio;
          const xVal  = u.scales.x.distr == 2 ? currIdx : u.data[0][currIdx];
          const left  = u.valToPos(xVal, "x") - width / 2;

          highlightEl.style.transform = "translateX(" + Math.round(left) + "px)";
          highlightEl.style.width = Math.round(width) + "px";
        }
      }
    }  

    return {
        opts: (u, opts) => {
            uPlot.assign(opts, {
                cursor: {
                    x: true,
                    y: true,
                }
            });
        },
        hooks: {
            init: init,
            setCursor: update,
        }
    };
}

const opts = {
  id: "chart",
  class: "my-chart",  
//  width: 800,
//  height: 300,
  plugins: [
    columnHighlightPlugin(),
  ],
  ...getSize(),
  title: "Tension, puissance et température",
  
//  tzDate: ts => uPlot.tzDate(new Date(ts * 1e3)),
  tzDate: ts => uPlot.tzDate(new Date(ts * 1e3), 'Europe/Paris'),
  
  // Options des séries
  series: [
    {
      label: "Date ",
      value: (u, ts) => fmtDate(tzDate(ts))
    },
    {
      label: "Tension ",
      stroke: "green",
      scale: "T",
      width: 2,
      value: (u, v) => fmtValue(v, 2, " V"),
    },
    {
      show: true,
      spanGaps: false,

      // in-legend display
      label: "Puissance ",
      value: (u, v) => fmtValue(v, 2, " W"),

      // series style
      stroke: "blue",
      scale: "P",    
      width: 1,
      fill: "rgba(0, 0, 255, 0.2)",
      dash: [10, 5],
    },
    {
      label: "Temp Cirrus ",
      stroke: "red",
      scale: "Q",
      width: 2,
      value: (u, v) => fmtValue(v, 2, "°C"),
    }
  ],
  
  // Options des axes. Le premier est l'axe des abscisses (temps).
  axes: [      
    {
      space: 40,
      incrs: [
         // minute divisors (# of secs)
         1,
         5,
         10,
         15,
         30,
         // hour divisors
         60,
         60 * 5,
         60 * 10,
         60 * 15,
         60 * 30,
         // day divisors
         3600,
         3600 * 5,
         3600 * 10,
         3600 * 15,
         // month divisors
         3600 * 24,
         3600 * 24 * 5,
         3600 * 24 * 10      
      // ...
      ],
      // [0]:   minimum num secs in found axis split (tick incr)
      // [1]:   default tick format
      // [2-7]: rollover tick formats
      // [8]:   mode: 0: replace [1] -> [2-7], 1: concat [1] + [2-7]
      values: [
      // tick incr          default           year                             month    day                        hour     min                sec       mode
        [3600 * 24 * 365,   "{YYYY}",         null,                            null,    null,                      null,    null,              null,        1],
        [3600 * 24 * 28,    "{MMM}",          "\n{YYYY}",                      null,    null,                      null,    null,              null,        1],
        [3600 * 24,         "{D}/{M}",        "\n{YYYY}",                      null,    null,                      null,    null,              null,        1],
        [3600,              "{H}:00",         "\n{D}/{M}/{YY}",                null,    "\n{D}/{M}",               null,    null,              null,        1],
        [60,                "{H}:{mm}",       "\n{D}/{M}/{YY}",                null,    "\n{D}/{M}",               null,    null,              null,        1],
        [1,                 ":{ss}",          "\n{D}/{M}/{YY} {H}:{mm}",       null,    "\n{D}/{M} {H}:{mm}",      null,    "\n{H}:{mm}",      null,        1],
        [0.001,             ":{ss}.{fff}",    "\n{D}/{M}/{YY} {H}:{mm}",       null,    "\n{D}/{M} {H}:{mm}",      null,    "\n{H}:{mm}",      null,        1],
      ],
//      label: "Date"
      //  splits:
    },    

    {
      scale: "T",
      values: (u, vals) => vals.map(v => v.toFixed(2)),
      label: "Volt",
      side: 1,
      grid: {show: false},
    },
    {
      scale: "P",
      values: (u, vals) => vals.map(v => v.toFixed(1)),
      label: "Watt"
    },
    {
      scale: "Q",
      values: (u, vals) => vals.map(v => v.toFixed(1)),
      label: "°C",
      side: 1,
    },     
  ],
  legend : {
    show: true,
    live: false
  },
  tooltip : {
    show: true
  }
};

function makeGrapheAction() {
  
  let action_array = [];
  
  action_array.push({"function": getGrapheAction, "page": PAGE16, "registre": 7, "params": {"GrapheID": 1}}); // Urms
  
//  action_array.push({"function": getGrapheAction, "page": PAGE16, "registre": 6, "params": {}}); // Irms
  
  action_array.push({"function": getGrapheAction, "page": PAGE16, "registre": 5, "params": {"GrapheID": 2}}); // Active Power
  
  action_array.push({"function": getGrapheAction, "page": PAGE16, "registre": 27, "params": {"GrapheID": 3}}); // Temp
  
  return action_array;
}

function makeGrapheActionMulti() {
  
  let action_array = [];
  
  action_array.push({"function": getGrapheActionMulti, "registers": [{"page": PAGE16, "registre": 7}, {"page": PAGE16, "registre": 5}, {"page": PAGE16, "registre": 27}], "params": {"GrapheID": 1}}); // Urms, Active Power, Temp
  
  return action_array;  
}

function getGrapheActionMulti(aRegisters, aParams) {
  
  var command = [];
  var params = [];
  aRegisters.forEach(reg => {    
    command.push(makeGetCommand(reg.page, reg.registre));
    params.push(GetPageRegister(reg.page, reg.registre));
  });

  var cirrus_request = "REG_MULTI=" + command.join("#");
  
  xmlHttp.Params = params;
  xmlHttp.open("PUT","/getCirrus",true);
  xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xmlHttp.onreadystatechange = function() {
    if (requestIsOK(xmlHttp)) 
    {
      var xmlResponse = xmlHttp.responseText;

      Cirrus_request_busy = false; 
      if ((xmlResponse === null) || (current_register === null)) 
      {
        delete xmlHttp.Params;
        return;
      }
      
      let values = xmlResponse.split("#");
      for (var i = 0; i < values.length; i++) {
        current_register = xmlHttp.Params[i];
        data_graphe[i+1].push(Number(convertToFloat(values[i])));
        if (oscillo && (data_graphe[i+1].length > 100))
          data_graphe[i+1].shift();          
      }    
      delete xmlHttp.Params;
      
      // Do the next action
      if (current_action.status !== "none")
      {
        current_action.id++;
        if (current_action.id < current_action.action.length)
        {
          let the_action = current_action.action[current_action.id];
          the_action.function(the_action.page, the_action.registre, the_action.params); 
        }
        else 
          {
            current_action.status = "none";
            plot.setData(data_graphe);
          }
      }        
    }
  }
  xmlHttp.send(cirrus_request);
  Cirrus_request_busy = true;
}

function getGrapheAction(aPage, aRegister, aParams) {
  current_register = GetPageRegister(aPage, aRegister);
  if (current_register != null)
  { 
    var cirrus_request = "REG=" + makeGetCommand(aPage, aRegister); 
    
    xmlHttp.Params = aParams;
    xmlHttp.open("PUT","/getCirrus",true);
    xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlHttp.onreadystatechange = function() {
      if (requestIsOK(xmlHttp)) 
      {
        var xmlResponse = xmlHttp.responseText;

        Cirrus_request_busy = false; 
        if ((xmlResponse === null) || (current_register === null)) 
        {
          delete xmlHttp.Params;
          return;
        }
        
        let id = xmlHttp.Params.GrapheID;
        data_graphe[id].push(Number(convertToFloat(xmlResponse)));
        if (oscillo && (data_graphe[id].length > 100))
          data_graphe[id].shift();
        delete xmlHttp.Params;

        // Do the next action
        if (current_action.status !== "none")
        {
          current_action.id++;
          if (current_action.id < current_action.action.length)
          {
            let the_action = current_action.action[current_action.id];
            the_action.function(the_action.page, the_action.registre, the_action.params); 
          }
          else 
            {
              current_action.status = "none";
              plot.setData(data_graphe);
            }
        }        
      }
    }
    xmlHttp.send(cirrus_request);
    Cirrus_request_busy = true;
  }
}

function DoStartGraphe() {
  
  // the time
  data_graphe[0].push(Math.round((new Date()).getTime()/1000));
  if (oscillo && (data_graphe[0].length > 100))
    data_graphe[0].shift();
  
  // On pointe sur le tableau mesure
  current_action.action = action_graphe;
  current_action.id = 0;
  current_action.status = "graphe";
  
  // Do the first action
  let the_action = current_action.action[0];
//  the_action.function(the_action.page, the_action.registre, the_action.params);
  the_action.function(the_action.registers, the_action.params);
}

function doRunGraphe() {
  let delay = Number(document.getElementById("FPSGraphe").value) * 1000;
  oscillo = document.getElementById("OsciGraphe").checked;
    
  if (bGraphe.textContent == "▶ Run") {
    bGraphe.textContent = "■ Stop";
    ID_Run = setInterval(function() {
      if (current_action.status == "none")
        DoStartGraphe();
    }, delay);    
  }
  else
    {
      current_action.status = "none";
      bGraphe.textContent = "▶ Run";
      clearInterval(ID_Run);
    }
}

function doRunGraphe1() {
  let delay = Number(document.getElementById("FPSGraphe").value) * 1000;
  oscillo = document.getElementById("OsciGraphe").checked;
  
  if (bGraphe.textContent == "▶ Run") {
    bGraphe.textContent = "■ Stop";
    ID_Run = setInterval(function() {
      loop++;
      let x = 2 * Math.PI * loop / 100;
      let y = Math.sin(x);

      data_graphe[0].push(Math.round((new Date()).getTime()/1000)+loop);
      data_graphe[1].push(x);
      data_graphe[2].push(y);
      data_graphe[3].push(y*y);
      if (oscillo && (data_graphe[0].length > 100)) {
        data_graphe[0].shift();
        data_graphe[1].shift();
        data_graphe[2].shift();
        data_graphe[3].shift();
      }  
      plot.setData(data_graphe);
    }, delay);    
  }
  else
    {
      bGraphe.textContent = "▶ Run";
      clearInterval(ID_Run);
    }
}

function doClearGraphe() {
  for (var i = 0; i < data_graphe.length; i++) {
    data_graphe[i] = [];
  }
  plot.setData(data_graphe);
}

function doExportGraphe() {
  
  var data_csv = "";
  for (var i = 0; i < data_graphe[0].length; i++) {
    // Convert unix datetime to readable date
    let dateObject = new Date(data_graphe[0][i] * 1000);
    let str = dateObject.toLocaleString();
    for (var j = 1; j < data_graphe.length; j++) {
      str += "\t" + (data_graphe[j][i]).toString().replace(".", ",");
    }
    data_csv += str + "\r\n";
  }
  
  var blob = new Blob([data_csv],
          { type: "text/plain; charset=utf-8" });      

  // Save the file with FileSaver.js
  saveAs(blob, "graphe.csv"); 
}

function ToolTipGrapheChange() {
  plot.tooltip.show = document.getElementById("ToolTipGraphe").checked;
}

function initializeGraphe() {
  
  // Create list action
  action_graphe = makeGrapheActionMulti();
  
  bGraphe = document.getElementById("bRunGraphe");  

  plot = new uPlot(opts, data_graphe, document.getElementById("chart"));
  
  window.addEventListener("resize", e => {
      plot.setSize(getSize());
  });
}


