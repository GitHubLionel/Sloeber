"use strict";

// The handle of the setInterval function
var ID_Run;

// The run button in the document
var bGraphe = null;
// If true, get all the data in one request. Else do one request for each data.
var ModeMulti = true;
// The list of action. Each action contains the parameters of the request
var action_graphe = [];
// Mode oscillo for the graphe
var oscillo = false;

// Graphe variables
var cirrus_line, LineGraph_Cirrus, cirrus_line_length;

// Time array
var data_date_formated = new Array();

// To get chart from div. For undo zoom, export
var div_plot = {};

// ***************************
// Time functions
// ***************************

function newDate() {
  let thedate = new Date();
  let new_time = Math.round(thedate.getTime()/1000) - thedate.getTimezoneOffset() * 60;
  return ((new_time - 3600) * 1000);
}

function makeGrapheAction() {
  let action_array = [];
  
  action_array.push({"function": getGrapheAction, "page": PAGE16, "registre": 7, "params": {"GrapheID": 0}}); // Urms
  
//  action_array.push({"function": getGrapheAction, "page": PAGE16, "registre": 6, "params": {}}); // Irms
  
  action_array.push({"function": getGrapheAction, "page": PAGE16, "registre": 5, "params": {"GrapheID": 1}}); // Active Power
  
  action_array.push({"function": getGrapheAction, "page": PAGE16, "registre": 27, "params": {"GrapheID": 2}}); // Temp
  
  return action_array;
}

function makeGrapheActionMulti() {
  let action_array = [];
  
  action_array.push({
    "function": getGrapheActionMulti, 
    "registers": [
      {"page": PAGE16, "registre": 7}, 
      {"page": PAGE16, "registre": 5}, 
      {"page": PAGE16, "registre": 27}], 
    "params": {"GrapheID": 0}}); // Urms, Active Power, Temp
  
  return action_array;  
}

// Check if there is a new action to do. If no, refresh graphe.
function checkNextAction() {
  if (current_action.status !== "none")
  {
    current_action.id++;
    if (current_action.id < current_action.action.length)
    {
      let the_action = current_action.action[current_action.id];
      the_action.function(the_action.page, the_action.registre, the_action.params); 
    }
    else 
      {
        current_action.status = "none";
        // No more action, update graphe
        if (oscillo)
          doShiftData(100);
        LineGraph_Cirrus.update();
      }
  }
}

// Shift data for oscillo mode
function doShiftData(lenMax) {
  if (data_date_formated.length > lenMax) {
    data_date_formated.shift();
    for (let i = 0; i < cirrus_line.data.datasets.length; i++) {
      cirrus_line.data.datasets[i].data.shift();
    }
  }
}

function getGrapheActionMulti(aRegisters, aParams) {
  var command = [];
  var params = [];
  aRegisters.forEach(reg => {    
    command.push(makeGetCommand(reg.page, reg.registre));
    params.push(GetPageRegister(reg.page, reg.registre));
  });

  var cirrus_request = "REG_MULTI=" + command.join("#");
  
  xmlHttp.Params = params;
  xmlHttp.open("PUT","/getCirrus",true);
  xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xmlHttp.onreadystatechange = function() {
    if (requestIsOK(xmlHttp)) 
    {
      var xmlResponse = xmlHttp.responseText;

      Cirrus_request_busy = false; 
      if ((xmlResponse === null) || (current_register === null)) 
      {
        delete xmlHttp.Params;
        return;
      }
      
      let values = xmlResponse.split("#");
      for (var i = 0; i < values.length; i++) {
        current_register = xmlHttp.Params[i];
        cirrus_line.data.datasets[i].data.push(Number(convertToFloat(values[i])));         
      }
      delete xmlHttp.Params;
      
      // Do the next action
      checkNextAction();       
    }
  }
  xmlHttp.send(cirrus_request);
  Cirrus_request_busy = true;
}

function getGrapheAction(aPage, aRegister, aParams) {
  current_register = GetPageRegister(aPage, aRegister);
  if (current_register != null)
  { 
    var cirrus_request = "REG=" + makeGetCommand(aPage, aRegister); 
    
    xmlHttp.Params = aParams;
    xmlHttp.open("PUT","/getCirrus",true);
    xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlHttp.onreadystatechange = function() {
      if (requestIsOK(xmlHttp)) 
      {
        var xmlResponse = xmlHttp.responseText;

        Cirrus_request_busy = false; 
        if ((xmlResponse === null) || (current_register === null)) 
        {
          delete xmlHttp.Params;
          return;
        }
        
        let id = xmlHttp.Params.GrapheID;
        cirrus_line.data.datasets[id].data.push(Number(convertToFloat(xmlResponse)));
        delete xmlHttp.Params;

        // Do the next action
        checkNextAction();        
      }
    }
    xmlHttp.send(cirrus_request);
    Cirrus_request_busy = true;
  }
}

// This function is called by setInterval each Nb of second
function DoStartGraphe() {
  // the time
  data_date_formated.push(newDate());
  
  // On pointe sur le tableau mesure
  current_action.action = action_graphe;
  current_action.id = 0;
  current_action.status = "graphe";
  
  // Do the first action
  let the_action = current_action.action[0];
  if (ModeMulti)
    the_action.function(the_action.registers, the_action.params);
  else
    the_action.function(the_action.page, the_action.registre, the_action.params);
}

function doRunGraphe() {
  let delay = Number(document.getElementById("FPSGraphe").value) * 1000;
  oscillo = document.getElementById("OsciGraphe").checked;
    
  if (bGraphe.textContent == "▶ Run") {
    bGraphe.textContent = "■ Stop";
    ID_Run = setInterval(function() {
      if (current_action.status == "none")
        DoStartGraphe();
    }, delay);    
  }
  else
    {
      current_action.status = "none";
      bGraphe.textContent = "▶ Run";
      clearInterval(ID_Run);
    }
}

// pour test
var loop = 1e2;
function doRunGraphe1() {
  let delay = Number(document.getElementById("FPSGraphe").value) * 1000;
  oscillo = document.getElementById("OsciGraphe").checked;

  if (bGraphe.textContent == "▶ Run") {
    bGraphe.textContent = "■ Stop";
    ID_Run = setInterval(function() {
      loop++;
      let x = 2 * Math.PI * loop / 100;
      let y = Math.sin(x);

      data_date_formated.push(newDate());
      cirrus_line.data.datasets[0].data.push(x);
      cirrus_line.data.datasets[1].data.push(y);
      cirrus_line.data.datasets[2].data.push(y*y);
      if (oscillo)
        doShiftData(10);
      LineGraph_Cirrus.update();
    }, delay);    
  }
  else
    {
      bGraphe.textContent = "▶ Run";
      clearInterval(ID_Run);
    }
}

function doClearGraphe() {
  // date
  data_date_formated.length = 0;
  // Power, Voltage, Temp
  for (var i = 0; i < cirrus_line_length; i++) {
    cirrus_line.data.datasets[i].data.length = 0;
  }
  LineGraph_Cirrus.update();
}

function ToolTipGrapheChange() {
  Chart.defaults.plugins.tooltip.enabled = document.getElementById("ToolTipGraphe").checked;
  LineGraph_Cirrus.update();
}

// ***************************
// Export function
// ***************************

/**
* Convert graphe data to csv
* args class params :
* data: the data property of the chart class (Chart.data)
* label: the label text of labels of the chart class
* columnDelimiter: the column delimiter character (default \t)
* lineDelimiter: the line delimiter character (default \r\n)
*/
function convertChartDataToCSV(args) {
  let result, columnDelimiter, lineDelimiter, labels, datas;

  datas = args.data.datasets || null;
  if (datas == null || !datas.length) {
    return null;
  }

  labels = args.data.labels || null;
  if (labels == null || !labels.length) {
    return null;
  }

  columnDelimiter = args.columnDelimiter || '\t';
  lineDelimiter = args.lineDelimiter || '\r\n';

  result = '';
  
  // Title of the columns
  result += args.label;
  result += columnDelimiter;
  for (var j = 0; j < datas.length; j++) {
    result += datas[j].label;
    result += columnDelimiter;
  }
  result += lineDelimiter;
  
  // We suppose that every datasets have the same length of labels
  for (var i = 0; i < labels.length; i++) {
    // Convert unix datetime to human readable date
    let dateObject = new Date(labels[i]);
    result += dateObject.toLocaleString();
    result += columnDelimiter;
    for (var j = 0; j < datas.length; j++) {
      result += (datas[j].data[i]).toString().replace(".", ",");
      result += columnDelimiter;
    }
    result += lineDelimiter;
  }

  return result;
}

function exportCSV(can_plot) {
  var theChart = div_plot[can_plot];
  var data_csv = convertChartDataToCSV({
      data: theChart.data,
      label: 'Date'
  });
  
  if (data_csv == null) return;
//  console.log(data_csv);
  
  var blob = new Blob([data_csv],
          { type: "text/plain; charset=utf-8" });

  // Save the file with FileSaver.js
  saveAs(blob, "graphe.csv");
}

// Export graphic to PNG
function exportPNG(chart, name) {
  const imageLink = document.createElement('a');
  const canvas = document.getElementById(chart);
  imageLink.download = name;
  imageLink.href = canvas.toDataURL("image/png", 1);
  imageLink.click();
}

// ***************************
// Plot create functions
// https://www.chartjs.org/docs/latest/
// ***************************

var timeFormat = 'HH:mm:ss';  // "HH:mm"; DD T
var dateFormat = 'DD MM YYYY HH:mm:ss';

var dragOptions = {
    borderColor: 'rgba(225,225,225,0.3)',
    borderWidth: 5,
    backgroundColor: 'rgb(225,225,225)',
    animationDuration: 500  
};

const axisID = {y: "W", y1: "V", y2: "°C", y3: "A"};

// List of scales
var cirrus_line_scale = {
  x: {
    type: 'time',
    time: {
      tooltipFormat: timeFormat,
      displayFormats: {
        second: timeFormat,
      },
      round: 'second',
      unit: 'second'
    },
    title: {
      display: true,
      text: 'Heure'
    }
  },
  y: { // Power axis
      type: 'linear',
      position: 'left',
      title: {
        display: true,
        text: 'W'
      },
      grid: {
        display: true,
        color: '#888'
      }
  },
  y1: { // Voltage axis
      type: 'linear',
      position: 'right',
      title: {
        display: true,
        text: 'V'
      },
      grid: {
        display: false,
      }
  },
  y2: { // Temp axis
      type: 'linear',
      position: 'right',
      title: {
        display: true,
        text: '°C'
      },
      grid: {
        display: true,
        color: '#ddd'
      }
  },
  y3: { // Current axis
      type: 'linear',
      position: 'right',
      display: false,
      title: {
        display: true,
        text: 'A'
      },
      grid: {
        display: false,
      }
  },
};

const zoomOptions = {
//  limits: {
//    x: {min: -200, max: 200, minRange: 50},
//    y: {min: -200, max: 200, minRange: 50}
//  },
  pan: {
    enabled: true,
    mode: 'x',
  },
  zoom: {
    wheel: {
      enabled: true,
    },
    drag: {
      enabled: true
    },
    pinch: {
      enabled: true
    },
    mode: 'x',
    onZoomComplete({chart}) {
      // This update is needed to display up to date zoom level in the title.
      // Without this, previous zoom level is displayed.
      // The reason is: title uses the same beforeUpdate hook, and is evaluated before zoom.
      chart.update('none');
    }
  }
};

// For background
const plugin = {
  id: 'customCanvasBackgroundColor',
  beforeDraw: (chart, args, options) => {
    const {ctx} = chart;
    ctx.save();
    ctx.globalCompositeOperation = 'destination-over';
    ctx.fillStyle = options.color || '#ffffff';
    ctx.fillRect(0, 0, chart.width, chart.height);
    ctx.restore();
  }
};

// ***************************
// Data Plot line functions
// ***************************

var chartColors = {
  red: 'rgb(255, 0, 0)',
  pink: 'rgb(255, 99, 132)',
  orange: 'rgb(255, 159, 64)',
  yellow: 'rgb(255, 205, 86)',
  green: 'rgb(0, 255, 0)',
  lightgreen: 'rgb(75, 192, 192)',
  blue: 'rgb(0, 0, 255)',
  lightblue: 'rgb(54, 162, 235)',
  purple: 'rgb(153, 102, 255)',
  grey: 'rgb(201, 203, 207)'
};

var chartColors_alpha = {
  red: 'rgba(255, 0, 0, 0.2)',
  pink: 'rgba(255, 99, 132, 0.2)',
  orange: 'rgba(255, 159, 64, 0.2)',
  yellow: 'rgba(255, 205, 86, 0.2)',
  green: 'rgba(0, 255, 0, 0.2)',
  lightgreen: 'rgba(75, 192, 192, 0.2)',
  blue: 'rgba(0, 0, 255, 0.2)',
  lightblue: 'rgba(54, 162, 235, 0.2)',
  purple: 'rgba(153, 102, 255, 0.2)',
  grey: 'rgba(201, 203, 207, 0.2)'
};

var data_line_cirrus = [
    {
      label: 'Tension',
      backgroundColor: chartColors.green,
      borderColor: chartColors.green,
      fill: false,
      data: new Array(),
      borderWidth: 2,
      yAxisID: 'y1', // voltage-axis
      pointRadius: 2
    }, {
      label: 'Puissance',
      backgroundColor: chartColors_alpha.blue,
      borderColor: chartColors.blue,
      fill: true,
      data: new Array(),
      borderWidth: 1,
      yAxisID: 'y', // power-axis
      pointRadius: 2
    }, {
      label: 'Temp Cirrus',
      backgroundColor: chartColors.red,
      borderColor: chartColors.red,
      fill: false,
      data: new Array(),
      borderWidth: 2,
      yAxisID: 'y2',
      pointRadius: 2
    }
];

function create_Line(data_label, data_line, opt_title, opt_scale) {
  return {
    type: 'line',
    data: {
      // data_label.slice() si on veut individualiser les dates
      labels: data_label,
      datasets: data_line
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      normalized: true,
      animation: false,
      
      parsing: {
        parsing: false,
      },

      plugins: {
        zoom: zoomOptions,
        title: {
          display: true,
          text: opt_title
        },
        legend: {
          position: 'top',
          onClick: function (event, legendItem) {
            let dataset = event.chart.data.datasets[legendItem.datasetIndex];
            let scaleAxis = event.chart.options.scales[dataset.yAxisID];
            scaleAxis.display = !scaleAxis.display;
            dataset.hidden = !dataset.hidden;
            event.chart.update();
          }
        },
        tooltip: {
          titleColor: '#000',
          bodyColor: '#000',
          backgroundColor: 'rgba(255, 249, 196, 0.92)',
          borderColor: 'rgb(0, 0, 255)',
          borderWidth: 1,
          position: 'nearest',
          callbacks: {
            afterTitle: function(context) {
              return "-----------";
            },
            label: function(context) {
              // console.log(context);
              let scaleID = context.dataset.yAxisID;
              return '  ' + context.dataset.label + ': ' + context.raw + ' ' + axisID[scaleID];
            }
          }
        },
        customCanvasBackgroundColor: {
          color: 'white',
        },
      },
      interaction: {
 //       axis: 'x',
        mode: 'index',  // index nearest  point dataset x
        intersect: false
      },
      scales: opt_scale,

//      onClick: (event, array) => { LineGraph_Cirrus.resetZoom();}    //chartClickEvent
    },
    plugins: [plugin],
  };
}

// ***************************
// Undo zoom
// ***************************

function undoZoom(can_plot) {
  div_plot[can_plot].resetZoom();
}

function ondblClick(evt) {
//  console.log(evt);
  let can = evt.target;
  undoZoom(can.id);
}

function getSize() {
  return {
      "width": window.innerWidth,
      "height": window.innerHeight
  };
}

function setGrapheHeight() {
  let offsets = document.getElementById('divGraphe').getBoundingClientRect();
  let h = getSize().height - (offsets.bottom + 35);
  document.getElementById('divCanvas').style.height = '' + h + 'px';  
}

// ***************************
// Initialization
// ***************************

Chart.defaults.font.size = 14;
Chart.defaults.font.family = "'Times New Roman', Times, serif";  // "'Arial', sans-serif"
//Chart.defaults.font.weight = 400;

Chart.defaults.backgroundColor = '#9BD0F5';
Chart.defaults.borderColor = '#aaa'; // #36A2EB
Chart.defaults.color = '#000';

Chart.defaults.plugins.title.font.size = 20;

function initializeGraphe() {
  // Create list action
  if (ModeMulti)
    action_graphe = makeGrapheActionMulti(); 
  else
    action_graphe = makeGrapheAction();

  // The Run button
  bGraphe = document.getElementById("bRunGraphe");  

  // Power, Voltage, Temp
  cirrus_line = create_Line(data_date_formated, data_line_cirrus, 'Tension, puissance et température', cirrus_line_scale);
  let ctx = document.getElementById('can_mean_cirrus');
  LineGraph_Cirrus = new Chart(ctx, cirrus_line);
  cirrus_line_length = cirrus_line.data.datasets.length;
  ctx.ondblclick = ondblClick;
  div_plot['can_mean_cirrus'] = LineGraph_Cirrus;
}

  window.addEventListener("resize", e => {
    setGrapheHeight();
  });

